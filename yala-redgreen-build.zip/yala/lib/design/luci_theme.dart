// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:dynamic_color/dynamic_color.dart';
import 'package:flutter/cupertino.dart' show CupertinoPageTransitionsBuilder;
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:google_fonts/google_fonts.dart';

/// Available curated color palettes for Yet Another LuCI App (YALA).
enum AppThemePalette {
  redGreen,
  aurora,
  ocean,
  emerald,
  rose,
  amber,
  dynamicTheme;

  String get label => switch (this) {
    AppThemePalette.redGreen => 'Red & Green',
    AppThemePalette.aurora => 'Aurora',
    AppThemePalette.ocean => 'Ocean',
    AppThemePalette.emerald => 'Emerald',
    AppThemePalette.rose => 'Rose',
    AppThemePalette.amber => 'YALA Amber',
    AppThemePalette.dynamicTheme => 'Material You',
  };

  String get subtitle => switch (this) {
    AppThemePalette.redGreen => 'Bold crimson with fresh green accents',
    AppThemePalette.aurora => 'Indigo glow with cyan accents',
    AppThemePalette.ocean => 'Deep sky blue & teal',
    AppThemePalette.emerald => 'Fresh green & mint',
    AppThemePalette.rose => 'Warm rose & violet',
    AppThemePalette.amber => 'Warm terracotta & rich amber',
    AppThemePalette.dynamicTheme => 'Wallpaper extracted palette',
  };

  IconData get icon => switch (this) {
    AppThemePalette.redGreen => Icons.contrast_rounded,
    AppThemePalette.aurora => Icons.auto_awesome_motion_rounded,
    AppThemePalette.ocean => Icons.water_rounded,
    AppThemePalette.emerald => Icons.eco_rounded,
    AppThemePalette.rose => Icons.local_florist_rounded,
    AppThemePalette.amber => Icons.palette_rounded,
    AppThemePalette.dynamicTheme => Icons.auto_awesome_rounded,
  };

  Color swatchColor(bool isDark) => switch (this) {
    AppThemePalette.redGreen =>
      isDark ? LuciTheme.redGreenDark : LuciTheme.redGreenLight,
    AppThemePalette.aurora => isDark ? LuciTheme.auroraDark : LuciTheme.auroraLight,
    AppThemePalette.ocean => isDark ? LuciTheme.oceanDark : LuciTheme.oceanLight,
    AppThemePalette.emerald =>
      isDark ? LuciTheme.emeraldDark : LuciTheme.emeraldLight,
    AppThemePalette.rose => isDark ? LuciTheme.roseDark : LuciTheme.roseLight,
    AppThemePalette.amber =>
      isDark ? LuciTheme.amberPrimaryDark : LuciTheme.amberPrimaryLight,
    AppThemePalette.dynamicTheme => const Color(0xFF3B82F6),
  };
}

/// Raw colour recipe for one curated palette (light + dark).
class _PaletteSpec {
  const _PaletteSpec({
    required this.primaryLight,
    required this.primaryDark,
    required this.secondaryLight,
    required this.secondaryDark,
    required this.tertiaryLight,
    required this.tertiaryDark,
    required this.scaffoldLight,
    required this.scaffoldDark,
    required this.cardDark,
  });

  final Color primaryLight;
  final Color primaryDark;
  final Color secondaryLight;
  final Color secondaryDark;
  final Color tertiaryLight;
  final Color tertiaryDark;
  final Color scaffoldLight;
  final Color scaffoldDark;
  final Color cardDark;
}

/// Centralized theme provider for Yet Another LuCI App (YALA).
///
/// "Aurora" redesign: soft tinted backgrounds, large rounded surfaces,
/// pill-shaped controls and a tonal (borderless) look. Supports six palettes
/// including Material You, in light and dark.
class LuciTheme {
  LuciTheme._();

  // ── Palette anchors ───────────────────────────────────────────────────────
  static const Color redGreenLight = Color(0xFFC62828);
  static const Color redGreenDark = Color(0xFFFF6B6B);
  static const Color auroraLight = Color(0xFF4F46E5);
  static const Color auroraDark = Color(0xFFA5B4FC);
  static const Color oceanLight = Color(0xFF0369A1);
  static const Color oceanDark = Color(0xFF7DD3FC);
  static const Color emeraldLight = Color(0xFF047857);
  static const Color emeraldDark = Color(0xFF6EE7B7);
  static const Color roseLight = Color(0xFFBE123C);
  static const Color roseDark = Color(0xFFFDA4AF);

  // YALA Amber (legacy signature palette, kept for existing users)
  static const Color amberPrimaryLight = Color(0xFFC2410C);
  static const Color amberSecondaryLight = Color(0xFFB45309);
  static const Color amberPrimaryDark = Color(0xFFFB923C);
  static const Color amberSecondaryDark = Color(0xFFFBBF24);

  // Backward compatibility brand aliases
  static const Color orangePrimary = Color(0xFFF97316);
  static const Color orangeSecondary = Color(0xFFFB923C);

  static const Map<AppThemePalette, _PaletteSpec> _specs = {
    AppThemePalette.redGreen: _PaletteSpec(
      primaryLight: redGreenLight,
      primaryDark: redGreenDark,
      secondaryLight: Color(0xFF15803D),
      secondaryDark: Color(0xFF4ADE80),
      tertiaryLight: Color(0xFFB45309),
      tertiaryDark: Color(0xFFFCD34D),
      scaffoldLight: Color(0xFFFBF3F2),
      scaffoldDark: Color(0xFF120A0A),
      cardDark: Color(0xFF1E1314),
    ),
    AppThemePalette.aurora: _PaletteSpec(
      primaryLight: auroraLight,
      primaryDark: auroraDark,
      secondaryLight: Color(0xFF0891B2),
      secondaryDark: Color(0xFF67E8F9),
      tertiaryLight: Color(0xFFDB2777),
      tertiaryDark: Color(0xFFF9A8D4),
      scaffoldLight: Color(0xFFF3F4FB),
      scaffoldDark: Color(0xFF0A0C16),
      cardDark: Color(0xFF141829),
    ),
    AppThemePalette.ocean: _PaletteSpec(
      primaryLight: oceanLight,
      primaryDark: oceanDark,
      secondaryLight: Color(0xFF0F766E),
      secondaryDark: Color(0xFF5EEAD4),
      tertiaryLight: Color(0xFF7C3AED),
      tertiaryDark: Color(0xFFC4B5FD),
      scaffoldLight: Color(0xFFEFF6FA),
      scaffoldDark: Color(0xFF07101A),
      cardDark: Color(0xFF0E1B2B),
    ),
    AppThemePalette.emerald: _PaletteSpec(
      primaryLight: emeraldLight,
      primaryDark: emeraldDark,
      secondaryLight: Color(0xFF0D9488),
      secondaryDark: Color(0xFF5EEAD4),
      tertiaryLight: Color(0xFFCA8A04),
      tertiaryDark: Color(0xFFFDE047),
      scaffoldLight: Color(0xFFF0F7F3),
      scaffoldDark: Color(0xFF07120D),
      cardDark: Color(0xFF0F1F18),
    ),
    AppThemePalette.rose: _PaletteSpec(
      primaryLight: roseLight,
      primaryDark: roseDark,
      secondaryLight: Color(0xFFC2410C),
      secondaryDark: Color(0xFFFDBA74),
      tertiaryLight: Color(0xFF7E22CE),
      tertiaryDark: Color(0xFFD8B4FE),
      scaffoldLight: Color(0xFFFBF2F4),
      scaffoldDark: Color(0xFF130A0E),
      cardDark: Color(0xFF211217),
    ),
    AppThemePalette.amber: _PaletteSpec(
      primaryLight: amberPrimaryLight,
      primaryDark: amberPrimaryDark,
      secondaryLight: amberSecondaryLight,
      secondaryDark: amberSecondaryDark,
      tertiaryLight: Color(0xFF0F766E),
      tertiaryDark: Color(0xFF5EEAD4),
      scaffoldLight: Color(0xFFF8F6F3),
      scaffoldDark: Color(0xFF111318),
      cardDark: Color(0xFF1A1C23),
    ),
  };

  /// Fallback dynamic palette for platforms or test environments where
  /// wallpaper color extraction is unavailable.
  static final ColorScheme fallbackDynamicLight = ColorScheme.fromSeed(
    seedColor: const Color(0xFF3B82F6),
    brightness: Brightness.light,
  );

  /// Fallback dynamic dark palette for platforms or test environments where
  /// wallpaper color extraction is unavailable.
  static final ColorScheme fallbackDynamicDark = ColorScheme.fromSeed(
    seedColor: const Color(0xFF3B82F6),
    brightness: Brightness.dark,
  );

  // ── Colour helpers ────────────────────────────────────────────────────────
  static Color _tint(Color base, Color tint, double alpha) =>
      Color.alphaBlend(tint.withValues(alpha: alpha), base);

  static Color _withLightness(Color c, double lightness) =>
      HSLColor.fromColor(c).withLightness(lightness).toColor();

  /// Builds a full [ColorScheme] for a curated palette.
  static ColorScheme _buildPaletteColorScheme(
    Brightness brightness,
    AppThemePalette palette,
  ) {
    if (palette == AppThemePalette.dynamicTheme) {
      return brightness == Brightness.dark
          ? fallbackDynamicDark
          : fallbackDynamicLight;
    }
    final spec = _specs[palette] ?? _specs[AppThemePalette.redGreen]!;
    final isDark = brightness == Brightness.dark;

    final primary = isDark ? spec.primaryDark : spec.primaryLight;
    final secondary = isDark ? spec.secondaryDark : spec.secondaryLight;
    final tertiary = isDark ? spec.tertiaryDark : spec.tertiaryLight;
    final scaffold = isDark ? spec.scaffoldDark : spec.scaffoldLight;
    final card = isDark ? spec.cardDark : Colors.white;
    final onPrimary = isDark ? const Color(0xFF0B0D17) : Colors.white;

    if (isDark) {
      return ColorScheme(
        brightness: Brightness.dark,
        primary: primary,
        onPrimary: onPrimary,
        primaryContainer: _tint(card, primary, 0.26),
        onPrimaryContainer: _withLightness(primary, 0.9),
        secondary: secondary,
        onSecondary: onPrimary,
        secondaryContainer: _tint(card, secondary, 0.22),
        onSecondaryContainer: _withLightness(secondary, 0.9),
        tertiary: tertiary,
        onTertiary: onPrimary,
        tertiaryContainer: _tint(card, tertiary, 0.22),
        onTertiaryContainer: _withLightness(tertiary, 0.9),
        error: const Color(0xFFF87171),
        onError: const Color(0xFF450A0A),
        errorContainer: _tint(card, const Color(0xFFF87171), 0.22),
        onErrorContainer: const Color(0xFFFECACA),
        surface: card,
        onSurface: const Color(0xFFE9EBF5),
        surfaceContainerLowest: scaffold,
        surfaceContainerLow: card,
        surfaceContainer: _tint(card, primary, 0.05),
        surfaceContainerHigh: _tint(card, primary, 0.09),
        surfaceContainerHighest: _tint(card, primary, 0.13),
        onSurfaceVariant: const Color(0xFF9AA0B5),
        outline: _tint(card, const Color(0xFFE9EBF5), 0.28),
        outlineVariant: _tint(card, const Color(0xFFE9EBF5), 0.12),
        inverseSurface: const Color(0xFFF1F2F9),
        onInverseSurface: const Color(0xFF12141F),
        inversePrimary: spec.primaryLight,
      );
    }
    return ColorScheme(
      brightness: Brightness.light,
      primary: primary,
      onPrimary: onPrimary,
      primaryContainer: _tint(Colors.white, primary, 0.14),
      onPrimaryContainer: _withLightness(primary, 0.16),
      secondary: secondary,
      onSecondary: Colors.white,
      secondaryContainer: _tint(Colors.white, secondary, 0.14),
      onSecondaryContainer: _withLightness(secondary, 0.16),
      tertiary: tertiary,
      onTertiary: Colors.white,
      tertiaryContainer: _tint(Colors.white, tertiary, 0.14),
      onTertiaryContainer: _withLightness(tertiary, 0.16),
      error: const Color(0xFFDC2626),
      onError: Colors.white,
      errorContainer: const Color(0xFFFEE2E2),
      onErrorContainer: const Color(0xFF991B1B),
      surface: card,
      onSurface: const Color(0xFF12141F),
      surfaceContainerLowest: Colors.white,
      surfaceContainerLow: _tint(scaffold, primary, 0.02),
      surfaceContainer: _tint(scaffold, primary, 0.06),
      surfaceContainerHigh: _tint(scaffold, primary, 0.10),
      surfaceContainerHighest: _tint(scaffold, primary, 0.14),
      onSurfaceVariant: const Color(0xFF565B6E),
      outline: const Color(0xFFA3A8B8),
      outlineVariant: _tint(scaffold, const Color(0xFF12141F), 0.10),
      inverseSurface: const Color(0xFF1B1E2B),
      onInverseSurface: const Color(0xFFF1F2F9),
      inversePrimary: spec.primaryDark,
    );
  }

  /// Builds the light [ThemeData].
  ///
  /// If [dynamicColorScheme] is provided, applies a Material You dynamic scheme
  /// with harmonized surfaces. Otherwise applies the selected [palette].
  static ThemeData buildLightTheme({
    ColorScheme? dynamicColorScheme,
    AppThemePalette palette = AppThemePalette.redGreen,
  }) {
    final isDynamic =
        dynamicColorScheme != null || palette == AppThemePalette.dynamicTheme;
    final colorScheme = dynamicColorScheme != null
        ? dynamicColorScheme.harmonized()
        : _buildPaletteColorScheme(Brightness.light, palette);
    final spec = _specs[palette] ?? _specs[AppThemePalette.redGreen]!;
    return _buildTheme(
      brightness: Brightness.light,
      greenToggles: palette == AppThemePalette.redGreen && !isDynamic,
      colorScheme: colorScheme,
      scaffold: isDynamic
          ? colorScheme.surfaceContainerLowest
          : spec.scaffoldLight,
      card: isDynamic ? colorScheme.surface : Colors.white,
    );
  }

  /// Builds the dark [ThemeData].
  static ThemeData buildDarkTheme({
    ColorScheme? dynamicColorScheme,
    AppThemePalette palette = AppThemePalette.redGreen,
  }) {
    final isDynamic =
        dynamicColorScheme != null || palette == AppThemePalette.dynamicTheme;
    final colorScheme = dynamicColorScheme != null
        ? dynamicColorScheme.harmonized()
        : _buildPaletteColorScheme(Brightness.dark, palette);
    final spec = _specs[palette] ?? _specs[AppThemePalette.redGreen]!;
    return _buildTheme(
      brightness: Brightness.dark,
      greenToggles: palette == AppThemePalette.redGreen && !isDynamic,
      colorScheme: colorScheme,
      scaffold: isDynamic
          ? colorScheme.surfaceContainerLowest
          : spec.scaffoldDark,
      card: isDynamic ? colorScheme.surfaceContainer : spec.cardDark,
    );
  }

  // ── Shared builder ────────────────────────────────────────────────────────
  static ThemeData _buildTheme({
    required bool greenToggles,
    required Brightness brightness,
    required ColorScheme colorScheme,
    required Color scaffold,
    required Color card,
  }) {
    final isDark = brightness == Brightness.dark;
    final cs = colorScheme;

    final baseText = GoogleFonts.geistTextTheme(
      ThemeData(brightness: brightness).textTheme,
    ).apply(bodyColor: cs.onSurface, displayColor: cs.onSurface);
    final textTheme = baseText.copyWith(
      headlineMedium: baseText.headlineMedium?.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: -0.6,
      ),
      headlineSmall: baseText.headlineSmall?.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: -0.4,
      ),
      titleLarge: baseText.titleLarge?.copyWith(
        fontWeight: FontWeight.w700,
        letterSpacing: -0.3,
      ),
      titleMedium: baseText.titleMedium?.copyWith(
        fontWeight: FontWeight.w600,
        letterSpacing: -0.1,
      ),
      titleSmall: baseText.titleSmall?.copyWith(fontWeight: FontWeight.w600),
      labelLarge: baseText.labelLarge?.copyWith(fontWeight: FontWeight.w600),
    );

    const stadium = StadiumBorder();
    final hairline = cs.outlineVariant.withValues(alpha: isDark ? 0.7 : 0.8);
    final fieldFill = isDark ? cs.surfaceContainer : cs.surfaceContainerLow;

    OutlineInputBorder fieldBorder(Color color, double width) =>
        OutlineInputBorder(
          borderRadius: BorderRadius.circular(16),
          borderSide: BorderSide(color: color, width: width),
        );

    return ThemeData(
      useMaterial3: true,
      brightness: brightness,
      colorScheme: cs,
      textTheme: textTheme,
      scaffoldBackgroundColor: scaffold,
      canvasColor: scaffold,
      focusColor: Colors.transparent,
      highlightColor: Colors.transparent,
      hoverColor: Colors.transparent,
      splashFactory: InkRipple.splashFactory,
      dividerTheme: DividerThemeData(color: hairline, thickness: 1, space: 1),
      appBarTheme: AppBarTheme(
        backgroundColor: Colors.transparent,
        surfaceTintColor: Colors.transparent,
        foregroundColor: cs.onSurface,
        elevation: 0,
        scrolledUnderElevation: 0,
        centerTitle: false,
        systemOverlayStyle: SystemUiOverlayStyle(
          statusBarColor: Colors.transparent,
          statusBarIconBrightness: isDark ? Brightness.light : Brightness.dark,
          statusBarBrightness: isDark ? Brightness.dark : Brightness.light,
          systemNavigationBarColor: Colors.transparent,
          systemNavigationBarIconBrightness: isDark
              ? Brightness.light
              : Brightness.dark,
          systemNavigationBarContrastEnforced: false,
        ),
        titleTextStyle: GoogleFonts.geist(
          fontSize: 22,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.4,
          color: cs.onSurface,
        ),
      ),
      cardTheme: CardThemeData(
        elevation: 0,
        color: card,
        surfaceTintColor: Colors.transparent,
        shadowColor: Colors.black.withValues(alpha: 0.12),
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(24),
          side: BorderSide(color: hairline, width: 1),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size(64, 48),
          padding: const EdgeInsets.symmetric(horizontal: 22),
          shape: stadium,
          textStyle: GoogleFonts.geist(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      elevatedButtonTheme: ElevatedButtonThemeData(
        style: ElevatedButton.styleFrom(
          elevation: 0,
          backgroundColor: cs.primary,
          foregroundColor: cs.onPrimary,
          minimumSize: const Size(64, 48),
          padding: const EdgeInsets.symmetric(horizontal: 22),
          shape: stadium,
          textStyle: GoogleFonts.geist(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      outlinedButtonTheme: OutlinedButtonThemeData(
        style: OutlinedButton.styleFrom(
          minimumSize: const Size(64, 48),
          padding: const EdgeInsets.symmetric(horizontal: 22),
          shape: stadium,
          side: BorderSide(color: cs.outline.withValues(alpha: 0.6)),
          textStyle: GoogleFonts.geist(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      textButtonTheme: TextButtonThemeData(
        style: TextButton.styleFrom(
          shape: stadium,
          padding: const EdgeInsets.symmetric(horizontal: 16),
          textStyle: GoogleFonts.geist(
            fontSize: 14,
            fontWeight: FontWeight.w600,
          ),
        ),
      ),
      floatingActionButtonTheme: FloatingActionButtonThemeData(
        backgroundColor: cs.primary,
        foregroundColor: cs.onPrimary,
        elevation: 3,
        focusElevation: 3,
        hoverElevation: 3,
        highlightElevation: 3,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(20)),
        extendedTextStyle: GoogleFonts.geist(
          fontSize: 14,
          fontWeight: FontWeight.w600,
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: fieldFill,
        contentPadding: const EdgeInsets.symmetric(
          horizontal: 16,
          vertical: 14,
        ),
        border: fieldBorder(hairline, 1),
        enabledBorder: fieldBorder(hairline, 1),
        disabledBorder: fieldBorder(hairline.withValues(alpha: 0.4), 1),
        focusedBorder: fieldBorder(cs.primary, 1.8),
        errorBorder: fieldBorder(cs.error, 1.2),
        focusedErrorBorder: fieldBorder(cs.error, 1.8),
      ),
      switchTheme: SwitchThemeData(
        thumbColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return greenToggles ? cs.onSecondary : cs.onPrimary;
          }
          return cs.outline;
        }),
        trackColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return greenToggles ? cs.secondary : cs.primary;
          }
          return cs.surfaceContainerHighest;
        }),
        trackOutlineColor: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) return Colors.transparent;
          return cs.outline.withValues(alpha: 0.5);
        }),
      ),
      checkboxTheme: CheckboxThemeData(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(6)),
      ),
      chipTheme: ChipThemeData(
        backgroundColor: cs.surfaceContainerHigh,
        selectedColor: cs.primaryContainer,
        checkmarkColor: cs.onPrimaryContainer,
        labelStyle: GoogleFonts.geist(
          fontSize: 12.5,
          fontWeight: FontWeight.w600,
          color: cs.onSurface,
        ),
        shape: stadium,
        side: BorderSide(color: hairline),
      ),
      tabBarTheme: TabBarThemeData(
        dividerColor: hairline,
        indicatorSize: TabBarIndicatorSize.label,
        indicator: UnderlineTabIndicator(
          borderSide: BorderSide(width: 3.5, color: cs.secondary),
          borderRadius: const BorderRadius.vertical(top: Radius.circular(4)),
          insets: const EdgeInsets.symmetric(horizontal: 2),
        ),
        labelColor: cs.onSurface,
        unselectedLabelColor: cs.onSurfaceVariant,
        overlayColor: WidgetStateProperty.all(Colors.transparent),
        labelStyle: GoogleFonts.geist(
          fontSize: 14,
          fontWeight: FontWeight.w700,
        ),
        unselectedLabelStyle: GoogleFonts.geist(
          fontSize: 14,
          fontWeight: FontWeight.w500,
        ),
      ),
      progressIndicatorTheme: ProgressIndicatorThemeData(
        color: cs.primary,
        linearTrackColor: cs.primaryContainer,
        linearMinHeight: 6,
      ),
      popupMenuTheme: PopupMenuThemeData(
        color: cs.surfaceContainerHigh,
        surfaceTintColor: Colors.transparent,
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
      ),
      navigationBarTheme: NavigationBarThemeData(
        height: 68,
        backgroundColor: cs.surfaceContainer,
        surfaceTintColor: Colors.transparent,
        indicatorColor: cs.primaryContainer,
        indicatorShape: stadium,
        iconTheme: WidgetStateProperty.resolveWith((states) {
          if (states.contains(WidgetState.selected)) {
            return IconThemeData(color: cs.onPrimaryContainer);
          }
          return IconThemeData(color: cs.onSurfaceVariant);
        }),
        labelTextStyle: WidgetStateProperty.resolveWith((states) {
          final selected = states.contains(WidgetState.selected);
          return GoogleFonts.geist(
            fontSize: 12,
            fontWeight: selected ? FontWeight.w700 : FontWeight.w500,
            color: selected ? cs.onSurface : cs.onSurfaceVariant,
          );
        }),
      ),
      navigationRailTheme: NavigationRailThemeData(
        backgroundColor: scaffold,
        indicatorColor: cs.primaryContainer,
        indicatorShape: stadium,
        useIndicator: true,
      ),
      snackBarTheme: SnackBarThemeData(
        backgroundColor: cs.inverseSurface,
        contentTextStyle: GoogleFonts.geist(
          fontSize: 14,
          color: cs.onInverseSurface,
        ),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
        behavior: SnackBarBehavior.floating,
      ),
      pageTransitionsTheme: const PageTransitionsTheme(
        builders: {
          TargetPlatform.android: PredictiveBackPageTransitionsBuilder(),
          TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
          TargetPlatform.macOS: CupertinoPageTransitionsBuilder(),
        },
      ),
      expansionTileTheme: const ExpansionTileThemeData(
        shape: Border(),
        collapsedShape: Border(),
      ),
      dialogTheme: DialogThemeData(
        backgroundColor: isDark ? cs.surfaceContainerHigh : card,
        surfaceTintColor: Colors.transparent,
        elevation: 6,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(28)),
        titleTextStyle: GoogleFonts.geist(
          fontSize: 20,
          fontWeight: FontWeight.w700,
          letterSpacing: -0.3,
          color: cs.onSurface,
        ),
        contentTextStyle: GoogleFonts.geist(
          fontSize: 14,
          height: 1.4,
          color: cs.onSurfaceVariant,
        ),
        actionsPadding: const EdgeInsets.symmetric(
          horizontal: 20,
          vertical: 14,
        ),
      ),
      bottomSheetTheme: BottomSheetThemeData(
        backgroundColor: isDark ? cs.surfaceContainer : card,
        surfaceTintColor: Colors.transparent,
        elevation: 8,
        constraints: const BoxConstraints(maxWidth: 640),
        shape: const RoundedRectangleBorder(
          borderRadius: BorderRadius.vertical(top: Radius.circular(28)),
        ),
      ),
    );
  }
}
