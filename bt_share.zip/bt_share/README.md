# BT Share Connect (Flutter, Android mobile)

Minimal helper app: scan a device's QR code (or type its Bluetooth address),
pair with it using Android's own pairing dialog, then jump straight to
Android's Bluetooth tethering settings screen.

What it does NOT do: it cannot flip "Bluetooth tethering" on by itself -
no third-party app can, that switch is Android's own, under the person's
control - and it does not include any vendor-specific device-wake or
provisioning protocol. It only uses public Android APIs (BluetoothAdapter,
BluetoothDevice.createBond(), the system Tethering settings screen).

- Zero servers, zero analytics, zero ads.
- QR/MAC parsing is pure Dart (`lib/mac.dart`), unit-tested in `test/mac_test.dart`.
- One dependency: `mobile_scanner` (camera QR scanning).
- `android/` is NOT stored: CI runs `flutter create` then `tools/patch_manifest.py`,
  which also writes `MainActivity.kt` from `tools/MainActivity.kt.template`.
- applicationId: `com.maraj.bt_share`. Keep `pubspec.yaml` version and `kVersion`
  in `lib/legal.dart` equal.
- Fill `kContactName` / `kContactEmail` in `lib/legal.dart` before publishing.

## QR code format accepted
- A bare MAC address: `AA:BB:CC:DD:EE:FF`
- JSON: `{"mac":"AA:BB:CC:DD:EE:FF","name":"My Device"}` (also accepts
  `address`, `bt_mac`, `bssid` for the MAC key)
- Any text/URL that contains a MAC-shaped substring, e.g.
  `https://example.com/pair?mac=AA:BB:CC:DD:EE:FF&name=CPE-1`
