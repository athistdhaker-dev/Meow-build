// App identity and legal text. Edit the placeholders here, in one place.

const String kAppName = 'BT Share Connect';
const String kVersion = '1.0.0'; // keep in sync with pubspec.yaml
const String kLastUpdated = '7 October 2026';

// TODO: fill these in before publishing to any store.
const String kContactName = '<your name>';
const String kContactEmail = '<your email>';

const String kPrivacyPolicy = '''
Privacy Policy (last updated $kLastUpdated)

$kAppName helps you pair a nearby Bluetooth device (by scanning a QR code or
typing its address) and open Android's own Bluetooth tethering settings. It
does not have its own server and does not send your data anywhere.

Camera access is used only to scan a QR code on-screen; no photos or video
are stored or uploaded. Bluetooth and nearby-device permissions are used only
to find and pair the device you scan. Nothing is collected, stored or shared
beyond what Android itself keeps for a normal Bluetooth pairing.

Contact: $kContactName, $kContactEmail
''';

const String kTerms = '''
Terms & Conditions (last updated $kLastUpdated)

This app is provided "as is", without warranty of any kind. It is a thin,
convenience layer over Android's standard Bluetooth pairing and tethering
settings, not a replacement for your device's own companion app. Use it only
with devices you own or are authorised to connect to.

Contact: $kContactName, $kContactEmail
''';

const String kHowToPlay = '''
How to use

1. Grant Bluetooth and camera permissions when asked.
2. Scan the device's QR code (or type its Bluetooth address).
3. Accept the pairing request that Android shows.
4. Once paired, tap "Open tethering settings" and turn on Bluetooth
   tethering from there.

This app does not turn tethering on by itself - that switch always stays in
Android's own settings, under your control.
''';
