import 'dart:async';
import 'dart:ui' show ImageFilter;

import 'package:flutter/material.dart';

const Color kPurple = Color(0xFF7B2FF7);
const Color kPink = Color(0xFFEC5678);
const Color kBlue = Color(0xFF2FA8F7);
const Color kTeal = Color(0xFF2ED3B7);

class OrbBackground extends StatelessWidget {
  const OrbBackground({super.key});

  @override
  Widget build(BuildContext context) {
    return const DecoratedBox(
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topCenter,
          end: Alignment.bottomCenter,
          colors: <Color>[Color(0xFF16102E), Color(0xFF0A0A18)],
        ),
      ),
      child: Stack(
        fit: StackFit.expand,
        children: <Widget>[
          _Orb(alignment: Alignment(-1.0, -0.85), color: kPurple, size: 380),
          _Orb(alignment: Alignment(1.1, -0.2), color: kBlue, size: 320),
          _Orb(alignment: Alignment(-0.9, 0.8), color: kTeal, size: 300),
        ],
      ),
    );
  }
}

class _Orb extends StatelessWidget {
  const _Orb({required this.alignment, required this.color, required this.size});

  final Alignment alignment;
  final Color color;
  final double size;

  @override
  Widget build(BuildContext context) {
    return Align(
      alignment: alignment,
      child: IgnorePointer(
        child: Container(
          width: size,
          height: size,
          decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(colors: <Color>[color.withAlpha(120), color.withAlpha(0)]),
          ),
        ),
      ),
    );
  }
}

class RimPainter extends CustomPainter {
  const RimPainter({required this.radius, this.strong = false});

  final double radius;
  final bool strong;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    final rrect = RRect.fromRectAndRadius(rect.deflate(0.6), Radius.circular(radius));
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = strong ? 1.8 : 1.2
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: <Color>[
          Color(strong ? 0xEEFFFFFF : 0x99FFFFFF),
          const Color(0x14FFFFFF),
          const Color(0x0AFFFFFF),
          const Color(0x55FFFFFF),
        ],
        stops: const <double>[0, 0.35, 0.65, 1],
      ).createShader(rect);
    canvas.drawRRect(rrect, rim);
  }

  @override
  bool shouldRepaint(RimPainter old) => old.radius != radius || old.strong != strong;
}

class GlassPanel extends StatelessWidget {
  const GlassPanel({
    super.key,
    required this.child,
    this.radius = 24,
    this.padding = EdgeInsets.zero,
    this.blur = 16,
  });

  final Widget child;
  final double radius;
  final EdgeInsetsGeometry padding;
  final double blur;

  @override
  Widget build(BuildContext context) {
    final fill = DecoratedBox(
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[Color(0x33FFFFFF), Color(0x0FFFFFFF)],
        ),
      ),
      child: CustomPaint(
        foregroundPainter: RimPainter(radius: radius),
        child: Padding(padding: padding, child: child),
      ),
    );
    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: blur > 0
          ? BackdropFilter(filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur), child: fill)
          : fill,
    );
  }
}

class GlassButton extends StatefulWidget {
  const GlassButton({
    super.key,
    required this.onPressed,
    required this.child,
    this.width,
    this.height = 52,
    this.radius = 26,
    this.enabled = true,
    this.active = false,
  });

  final VoidCallback onPressed;
  final Widget child;
  final double? width;
  final double height;
  final double radius;
  final bool enabled;
  final bool active;

  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      behavior: HitTestBehavior.opaque,
      onTapDown: widget.enabled ? (_) => setState(() => _down = true) : null,
      onTapUp: widget.enabled
          ? (_) {
              setState(() => _down = false);
              widget.onPressed();
            }
          : null,
      onTapCancel: () => setState(() => _down = false),
      child: Opacity(
        opacity: widget.enabled ? 1 : 0.4,
        child: AnimatedScale(
          scale: _down ? 0.96 : 1,
          duration: const Duration(milliseconds: 90),
          child: ConstrainedBox(
            constraints: BoxConstraints(
              minWidth: widget.width ?? 48,
              maxWidth: widget.width ?? double.infinity,
              minHeight: widget.height,
            ),
            child: DecoratedBox(
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(widget.radius),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: _down || widget.active
                      ? const <Color>[Color(0x66FFFFFF), Color(0x26FFFFFF)]
                      : const <Color>[Color(0x2EFFFFFF), Color(0x0EFFFFFF)],
                ),
              ),
              child: CustomPaint(
                foregroundPainter: RimPainter(radius: widget.radius, strong: _down || widget.active),
                child: Center(child: widget.child),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class GlassTextButton extends StatelessWidget {
  const GlassTextButton({
    super.key,
    required this.label,
    required this.onPressed,
    this.icon,
    this.primary = false,
    this.enabled = true,
  });

  final String label;
  final VoidCallback onPressed;
  final IconData? icon;
  final bool primary;
  final bool enabled;

  @override
  Widget build(BuildContext context) {
    return GlassButton(
      onPressed: onPressed,
      active: primary,
      enabled: enabled,
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 20),
        child: Row(
          mainAxisSize: MainAxisSize.min,
          children: <Widget>[
            if (icon != null) ...<Widget>[Icon(icon, color: Colors.white, size: 20), const SizedBox(width: 8)],
            Text(label, style: const TextStyle(color: Colors.white, fontSize: 16, fontWeight: FontWeight.w700)),
          ],
        ),
      ),
    );
  }
}

const TextStyle kTitleStyle = TextStyle(
  fontSize: 28,
  fontWeight: FontWeight.w800,
  letterSpacing: 0.2,
  color: Colors.white,
);

const TextStyle kBodyStyle = TextStyle(fontSize: 15, height: 1.4, color: Color(0xDDFFFFFF));

class GradientTitle extends StatelessWidget {
  const GradientTitle(this.text, {super.key});

  final String text;

  @override
  Widget build(BuildContext context) {
    return ShaderMask(
      blendMode: BlendMode.srcIn,
      shaderCallback: (Rect r) => const LinearGradient(colors: <Color>[kBlue, kTeal]).createShader(r),
      child: Text(text, style: kTitleStyle),
    );
  }
}
