import 'package:flutter/material.dart';
import 'package:mobile_scanner/mobile_scanner.dart';

import 'core.dart';
import 'glass.dart';
import 'legal.dart';
import 'pages.dart';

class HomeShell extends StatefulWidget {
  const HomeShell({super.key});

  @override
  State<HomeShell> createState() => _HomeShellState();
}

class _HomeShellState extends State<HomeShell> {
  late final ShareController _c = ShareController();

  @override
  void initState() {
    super.initState();
    _c.init();
  }

  @override
  void dispose() {
    _c.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        const OrbBackground(),
        Scaffold(
          backgroundColor: Colors.transparent,
          body: SafeArea(
            child: ListenableBuilder(
              listenable: _c,
              builder: (context, _) => _Body(controller: _c),
            ),
          ),
        ),
      ],
    );
  }
}

class _Body extends StatelessWidget {
  const _Body({required this.controller});

  final ShareController controller;

  @override
  Widget build(BuildContext context) {
    return Column(
      children: <Widget>[
        Padding(
          padding: const EdgeInsets.fromLTRB(20, 16, 20, 8),
          child: Row(
            children: <Widget>[
              const Expanded(child: GradientTitle(kAppName)),
              GlassButton(
                width: 44,
                height: 44,
                radius: 22,
                onPressed: () => Navigator.of(context).push(
                  MaterialPageRoute<void>(builder: (_) => const AboutPage()),
                ),
                child: const Icon(Icons.info_outline_rounded, color: Colors.white, size: 20),
              ),
            ],
          ),
        ),
        if (controller.error != null)
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 20),
            child: GlassPanel(
              radius: 16,
              padding: const EdgeInsets.all(12),
              blur: 0,
              child: Row(
                children: <Widget>[
                  const Icon(Icons.warning_amber_rounded, color: Color(0xFFFFB86B), size: 20),
                  const SizedBox(width: 10),
                  Expanded(child: Text(controller.error!, style: kBodyStyle)),
                ],
              ),
            ),
          ),
        Expanded(child: _StepView(controller: controller)),
      ],
    );
  }
}

class _StepView extends StatelessWidget {
  const _StepView({required this.controller});

  final ShareController controller;

  @override
  Widget build(BuildContext context) {
    switch (controller.step) {
      case Step.permissions:
        return _PermissionsStep(controller: controller);
      case Step.scan:
        return _ScanStep(controller: controller);
      case Step.pairing:
        return _PairingStep(controller: controller);
      case Step.tether:
      case Step.done:
        return _TetherStep(controller: controller);
    }
  }
}

class _PermissionsStep extends StatelessWidget {
  const _PermissionsStep({required this.controller});

  final ShareController controller;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: GlassPanel(
          radius: 28,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const Icon(Icons.bluetooth_rounded, color: kBlue, size: 44),
              const SizedBox(height: 12),
              const Text(
                'Permissions chahiye',
                style: TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w800),
              ),
              const SizedBox(height: 8),
              const Text(
                'Nearby device dhoondhne, pair karne aur QR scan karne ke liye Bluetooth, '
                'nearby-devices aur camera permission chahiye.',
                textAlign: TextAlign.center,
                style: kBodyStyle,
              ),
              const SizedBox(height: 20),
              GlassTextButton(
                label: 'Allow karein',
                icon: Icons.check_rounded,
                primary: true,
                onPressed: controller.ensureReady,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class _ScanStep extends StatefulWidget {
  const _ScanStep({required this.controller});

  final ShareController controller;

  @override
  State<_ScanStep> createState() => _ScanStepState();
}

class _ScanStepState extends State<_ScanStep> {
  final MobileScannerController _cam = MobileScannerController();
  bool _handled = false;
  final TextEditingController _manual = TextEditingController();

  @override
  void dispose() {
    _cam.dispose();
    _manual.dispose();
    super.dispose();
  }

  void _onDetect(BarcodeCapture capture) {
    if (_handled) return;
    for (final b in capture.barcodes) {
      final raw = b.rawValue;
      if (raw == null || raw.isEmpty) continue;
      _handled = true;
      widget.controller.onCodeScanned(raw);
      break;
    }
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(20, 8, 20, 20),
      child: Column(
        children: <Widget>[
          Expanded(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: Stack(
                fit: StackFit.expand,
                children: <Widget>[
                  MobileScanner(controller: _cam, onDetect: _onDetect),
                  IgnorePointer(
                    child: Center(
                      child: Container(
                        width: 220,
                        height: 220,
                        decoration: BoxDecoration(
                          border: Border.all(color: Colors.white70, width: 2),
                          borderRadius: BorderRadius.circular(20),
                        ),
                      ),
                    ),
                  ),
                  Align(
                    alignment: Alignment.bottomCenter,
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Text(
                        'Device ka QR code frame ke andar rakho',
                        style: kBodyStyle.copyWith(
                          shadows: const <Shadow>[Shadow(blurRadius: 8, color: Colors.black)],
                        ),
                      ),
                    ),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          GlassPanel(
            radius: 22,
            padding: const EdgeInsets.all(14),
            child: Row(
              children: <Widget>[
                Expanded(
                  child: TextField(
                    controller: _manual,
                    style: const TextStyle(color: Colors.white),
                    decoration: const InputDecoration(
                      border: InputBorder.none,
                      hintText: 'Ya MAC address type karo: AA:BB:CC:DD:EE:FF',
                      hintStyle: TextStyle(color: Color(0x99FFFFFF)),
                    ),
                  ),
                ),
                GlassButton(
                  width: 44,
                  height: 44,
                  radius: 16,
                  onPressed: () {
                    final v = _manual.text.trim();
                    if (v.isEmpty) return;
                    widget.controller.setManualMac(v);
                  },
                  child: const Icon(Icons.arrow_forward_rounded, color: Colors.white),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class _PairingStep extends StatelessWidget {
  const _PairingStep({required this.controller});

  final ShareController controller;

  @override
  Widget build(BuildContext context) {
    final d = controller.device;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: GlassPanel(
          radius: 28,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              const SizedBox(
                width: 44,
                height: 44,
                child: CircularProgressIndicator(strokeWidth: 3, color: kBlue),
              ),
              const SizedBox(height: 16),
              Text(
                d?.name ?? d?.mac ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              const Text('Pairing ho rahi hai - phone par popup accept karo', textAlign: TextAlign.center, style: kBodyStyle),
              const SizedBox(height: 20),
              GlassTextButton(label: 'Cancel', icon: Icons.close_rounded, onPressed: controller.reset),
            ],
          ),
        ),
      ),
    );
  }
}

class _TetherStep extends StatelessWidget {
  const _TetherStep({required this.controller});

  final ShareController controller;

  @override
  Widget build(BuildContext context) {
    final d = controller.device;
    final done = controller.step == Step.done;
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(24),
        child: GlassPanel(
          radius: 28,
          padding: const EdgeInsets.all(24),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Icon(
                done ? Icons.wifi_tethering_rounded : Icons.bluetooth_connected_rounded,
                color: kTeal,
                size: 44,
              ),
              const SizedBox(height: 12),
              Text(
                d?.name ?? d?.mac ?? '',
                style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
              ),
              const SizedBox(height: 6),
              Text(
                done
                    ? 'Tethering settings khul gayi. Wahan "Bluetooth tethering" on karo.'
                    : 'Paired! Ab Bluetooth tethering on karne ke liye Android settings kholo.',
                textAlign: TextAlign.center,
                style: kBodyStyle,
              ),
              const SizedBox(height: 20),
              GlassTextButton(
                label: 'Tethering settings kholo',
                icon: Icons.settings_rounded,
                primary: true,
                onPressed: () async {
                  await Native.openTetherSettings();
                  controller.goDone();
                },
              ),
              const SizedBox(height: 10),
              GlassTextButton(label: 'Doosra device', icon: Icons.refresh_rounded, onPressed: controller.reset),
            ],
          ),
        ),
      ),
    );
  }
}
