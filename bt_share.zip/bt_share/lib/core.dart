import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';

import 'mac.dart';

/// Bond states mirrored from android.bluetooth.BluetoothDevice.
enum BondState { none, bonding, bonded, unknown }

BondState bondStateFromInt(int? v) {
  switch (v) {
    case 10:
      return BondState.none;
    case 11:
      return BondState.bonding;
    case 12:
      return BondState.bonded;
    default:
      return BondState.unknown;
  }
}

/// Thin bridge to MainActivity.kt. Every call is defensive: failures surface
/// as a false/empty result rather than throwing into the UI.
class Native {
  static const MethodChannel _ch = MethodChannel('app/native');
  static const EventChannel _bondEvents = EventChannel('app/native/bond_state');

  static Future<bool> isBluetoothSupported() async {
    try {
      return (await _ch.invokeMethod<bool>('isBluetoothSupported')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> isBluetoothOn() async {
    try {
      return (await _ch.invokeMethod<bool>('isBluetoothOn')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> requestEnableBluetooth() async {
    try {
      return (await _ch.invokeMethod<bool>('requestEnableBluetooth')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> hasPermissions() async {
    try {
      return (await _ch.invokeMethod<bool>('hasPermissions')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> requestPermissions() async {
    try {
      return (await _ch.invokeMethod<bool>('requestPermissions')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<BondState> bondState(String mac) async {
    try {
      final v = await _ch.invokeMethod<int>('bondState', <String, dynamic>{'mac': mac});
      return bondStateFromInt(v);
    } catch (_) {
      return BondState.unknown;
    }
  }

  static Future<String?> deviceName(String mac) async {
    try {
      return await _ch.invokeMethod<String>('deviceName', <String, dynamic>{'mac': mac});
    } catch (_) {
      return null;
    }
  }

  /// Starts pairing. Returns false immediately if the OS call could not even
  /// be dispatched (bad MAC, adapter off, ...). The actual outcome arrives
  /// via [bondStateEvents].
  static Future<bool> createBond(String mac) async {
    try {
      return (await _ch.invokeMethod<bool>('createBond', <String, dynamic>{'mac': mac})) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Stream of (mac, BondState) as Android reports bond-state changes.
  static Stream<(String, BondState)> bondStateEvents() {
    return _bondEvents.receiveBroadcastStream().map((event) {
      final map = Map<Object?, Object?>.from(event as Map);
      final mac = map['mac'] as String? ?? '';
      final state = bondStateFromInt(map['state'] as int?);
      return (mac, state);
    });
  }

  static Future<bool> openTetherSettings() async {
    try {
      return (await _ch.invokeMethod<bool>('openTetherSettings')) ?? false;
    } catch (_) {
      return false;
    }
  }

  static Future<bool> openBluetoothSettings() async {
    try {
      return (await _ch.invokeMethod<bool>('openBluetoothSettings')) ?? false;
    } catch (_) {
      return false;
    }
  }
}

enum Step { permissions, scan, pairing, tether, done }

/// Whole-screen workflow state: scanned device -> pairing -> tethering.
class ShareController extends ChangeNotifier {
  ShareController() {
    _sub = Native.bondStateEvents().listen(_onBondEvent);
  }

  StreamSubscription<(String, BondState)>? _sub;

  Step step = Step.permissions;
  bool hasPermissions = false;
  bool bluetoothOn = false;
  ParsedDevice? device;
  BondState bondState = BondState.unknown;
  String? error;

  Future<void> init() async {
    hasPermissions = await Native.hasPermissions();
    bluetoothOn = await Native.isBluetoothOn();
    step = hasPermissions && bluetoothOn ? Step.scan : Step.permissions;
    notifyListeners();
  }

  Future<void> ensureReady() async {
    error = null;
    if (!hasPermissions) {
      hasPermissions = await Native.requestPermissions();
    }
    if (hasPermissions && !bluetoothOn) {
      bluetoothOn = await Native.requestEnableBluetooth();
    }
    if (hasPermissions && bluetoothOn) {
      step = Step.scan;
    } else if (!hasPermissions) {
      error = 'Bluetooth aur nearby-device permission zaroori hai.';
    } else {
      error = 'Bluetooth on karo.';
    }
    notifyListeners();
  }

  Future<void> onCodeScanned(String raw) async {
    final d = parseScannedText(raw);
    if (d == null) {
      error = 'Ye QR code kisi device ka MAC address nahi de raha.';
      notifyListeners();
      return;
    }
    error = null;
    device = d;
    final liveName = await Native.deviceName(d.mac);
    if (liveName != null && liveName.isNotEmpty) {
      device = ParsedDevice(mac: d.mac, name: liveName);
    }
    bondState = await Native.bondState(d.mac);
    if (bondState == BondState.bonded) {
      step = Step.tether;
    } else {
      step = Step.pairing;
      final started = await Native.createBond(d.mac);
      if (!started && bondState != BondState.bonding) {
        error = 'Pairing shuru nahi ho payi. Device paas me hai aur on hai, check karo.';
      }
    }
    notifyListeners();
  }

  void setManualMac(String mac) {
    device = ParsedDevice(mac: mac);
    onCodeScanned(mac);
  }

  void _onBondEvent((String, BondState) event) {
    final (mac, state) = event;
    if (device == null || mac != device!.mac) return;
    bondState = state;
    if (state == BondState.bonded) {
      step = Step.tether;
    } else if (state == BondState.none && step == Step.pairing) {
      error = 'Pairing cancel ho gayi ya fail ho gayi.';
    }
    notifyListeners();
  }

  void reset() {
    device = null;
    bondState = BondState.unknown;
    error = null;
    step = Step.scan;
    notifyListeners();
  }

  void goDone() {
    step = Step.done;
    notifyListeners();
  }

  @override
  void dispose() {
    _sub?.cancel();
    super.dispose();
  }
}
