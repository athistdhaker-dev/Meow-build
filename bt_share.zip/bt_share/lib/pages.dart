import 'package:flutter/material.dart';

import 'glass.dart';
import 'legal.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  void _showText(BuildContext context, String title, String body) {
    showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text(title),
        content: SingleChildScrollView(child: Text(body)),
        actions: <Widget>[
          TextButton(onPressed: () => Navigator.of(ctx).pop(), child: const Text('Close')),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        const OrbBackground(),
        Scaffold(
          backgroundColor: Colors.transparent,
          appBar: AppBar(backgroundColor: Colors.transparent, elevation: 0, title: const Text('About')),
          body: ListView(
            padding: const EdgeInsets.fromLTRB(20, 4, 20, 24),
            children: <Widget>[
              Text('$kAppName  v$kVersion', style: kBodyStyle),
              const SizedBox(height: 16),
              GlassPanel(padding: const EdgeInsets.all(18), child: Text(kHowToPlay, style: kBodyStyle)),
              const SizedBox(height: 16),
              GlassTextButton(
                label: 'Privacy Policy',
                icon: Icons.privacy_tip_outlined,
                onPressed: () => _showText(context, 'Privacy Policy', kPrivacyPolicy),
              ),
              const SizedBox(height: 10),
              GlassTextButton(
                label: 'Terms & Conditions',
                icon: Icons.gavel_outlined,
                onPressed: () => _showText(context, 'Terms & Conditions', kTerms),
              ),
              const SizedBox(height: 10),
              GlassTextButton(
                label: 'Open-source licenses',
                icon: Icons.article_outlined,
                onPressed: () => showLicensePage(context: context, applicationName: kAppName, applicationVersion: kVersion),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
