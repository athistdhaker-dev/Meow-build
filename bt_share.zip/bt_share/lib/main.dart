import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'glass.dart';
import 'legal.dart';
import 'mobile.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(
    const SystemUiOverlayStyle(statusBarColor: Colors.transparent, systemNavigationBarColor: Colors.transparent),
  );
  SystemChrome.setEnabledSystemUIMode(SystemUiMode.edgeToEdge);
  runApp(const BtShareApp());
}

class BtShareApp extends StatelessWidget {
  const BtShareApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: kAppName,
      debugShowCheckedModeBanner: false,
      theme: ThemeData(
        useMaterial3: true,
        brightness: Brightness.dark,
        colorScheme: ColorScheme.fromSeed(seedColor: kPurple, brightness: Brightness.dark),
      ),
      home: const HomeShell(),
    );
  }
}
