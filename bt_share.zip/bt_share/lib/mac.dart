// Pure Dart: find and validate a Bluetooth MAC address from whatever a QR
// code (or manual entry) contains. No Flutter imports, so it is unit-testable.

import 'dart:convert' show jsonDecode;

final RegExp _macPattern = RegExp(r'([0-9A-Fa-f]{2}(?:[:\-]){5}[0-9A-Fa-f]{2})');

/// Normalises a MAC to AA:BB:CC:DD:EE:FF (upper-case, colon-separated).
String normalizeMac(String raw) => raw.toUpperCase().replaceAll('-', ':');

bool isValidMac(String raw) {
  final m = _macPattern.firstMatch(raw.trim());
  return m != null && m.start == 0 && m.end == raw.trim().length;
}

/// Result of parsing scanned/typed text.
class ParsedDevice {
  const ParsedDevice({required this.mac, this.name});

  final String mac;
  final String? name;
}

/// Tries, in order:
///  1. The whole string is a bare MAC ("AA:BB:CC:DD:EE:FF").
///  2. JSON with a mac-ish key ("mac", "address", "bt_mac", "btMac", "bssid")
///     and an optional "name"/"deviceName" key.
///  3. Any MAC-shaped substring found anywhere in the text (e.g. a URL like
///     ".../pair?mac=AA:BB:CC:DD:EE:FF&name=CPE-1234").
/// Returns null if no MAC could be found.
ParsedDevice? parseScannedText(String text) {
  final trimmed = text.trim();
  if (trimmed.isEmpty) return null;

  if (isValidMac(trimmed)) {
    return ParsedDevice(mac: normalizeMac(trimmed));
  }

  final asJson = _tryParseJsonMac(trimmed);
  if (asJson != null) return asJson;

  final m = _macPattern.firstMatch(trimmed);
  if (m != null) {
    final name = _nameNear(trimmed, m.end);
    return ParsedDevice(mac: normalizeMac(m.group(1)!), name: name);
  }
  return null;
}

const List<String> _macKeys = <String>['mac', 'address', 'bt_mac', 'btmac', 'bssid', 'bdaddr'];
const List<String> _nameKeys = <String>['name', 'devicename', 'device_name', 'label'];

ParsedDevice? _tryParseJsonMac(String text) {
  if (!text.startsWith('{')) return null;
  Map<String, dynamic>? map;
  try {
    map = _miniJsonDecode(text);
  } catch (_) {
    return null;
  }
  if (map == null) return null;
  final lower = <String, dynamic>{for (final e in map.entries) e.key.toLowerCase(): e.value};
  for (final k in _macKeys) {
    final v = lower[k];
    if (v is String && isValidMac(v.trim())) {
      String? name;
      for (final nk in _nameKeys) {
        final nv = lower[nk];
        if (nv is String && nv.trim().isNotEmpty) {
          name = nv.trim();
          break;
        }
      }
      return ParsedDevice(mac: normalizeMac(v.trim()), name: name);
    }
  }
  return null;
}

/// Picks up a short "name=..." / "name: ..." hint right after the MAC, if any.
String? _nameNear(String text, int afterIndex) {
  final tail = text.substring(afterIndex);
  final m = RegExp(r'''[?&]?name["']?\s*[:=]\s*["']?([^&"'\s,}]{1,40})''', caseSensitive: false)
      .firstMatch(tail);
  return m?.group(1);
}

Map<String, dynamic>? _miniJsonDecode(String text) {
  final decoded = jsonDecode(text);
  if (decoded is Map<String, dynamic>) return decoded;
  return null;
}
