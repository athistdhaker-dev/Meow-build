import 'package:flutter_test/flutter_test.dart';
import 'package:bt_share/mac.dart';

void main() {
  group('isValidMac / normalizeMac', () {
    test('accepts colon and dash separated MACs', () {
      expect(isValidMac('AA:BB:CC:DD:EE:FF'), isTrue);
      expect(isValidMac('aa-bb-cc-dd-ee-ff'), isTrue);
      expect(normalizeMac('aa-bb-cc-dd-ee-ff'), 'AA:BB:CC:DD:EE:FF');
    });

    test('rejects garbage', () {
      expect(isValidMac('not a mac'), isFalse);
      expect(isValidMac('AA:BB:CC:DD:EE'), isFalse);
      expect(isValidMac('AA:BB:CC:DD:EE:FF:00'), isFalse);
      expect(isValidMac(''), isFalse);
    });
  });

  group('parseScannedText', () {
    test('bare MAC', () {
      final d = parseScannedText('  aa:bb:cc:dd:ee:ff  ');
      expect(d, isNotNull);
      expect(d!.mac, 'AA:BB:CC:DD:EE:FF');
      expect(d.name, isNull);
    });

    test('JSON with mac + name', () {
      final d = parseScannedText('{"mac":"aa:bb:cc:dd:ee:ff","name":"CPE-1234"}');
      expect(d, isNotNull);
      expect(d!.mac, 'AA:BB:CC:DD:EE:FF');
      expect(d.name, 'CPE-1234');
    });

    test('JSON with alternate key names', () {
      expect(parseScannedText('{"address":"11:22:33:44:55:66"}')!.mac, '11:22:33:44:55:66');
      expect(parseScannedText('{"bt_mac":"11:22:33:44:55:66"}')!.mac, '11:22:33:44:55:66');
      expect(parseScannedText('{"BSSID":"11:22:33:44:55:66"}')!.mac, '11:22:33:44:55:66');
    });

    test('MAC inside a URL with a name query param', () {
      final d = parseScannedText('https://example.com/pair?mac=AA:BB:CC:DD:EE:FF&name=CPE-9');
      expect(d, isNotNull);
      expect(d!.mac, 'AA:BB:CC:DD:EE:FF');
      expect(d.name, 'CPE-9');
    });

    test('MAC inside free text without name', () {
      final d = parseScannedText('Device MAC: AA:BB:CC:DD:EE:FF please pair');
      expect(d!.mac, 'AA:BB:CC:DD:EE:FF');
    });

    test('invalid JSON falls through to regex scan', () {
      final d = parseScannedText('{not json} AA:BB:CC:DD:EE:FF');
      expect(d!.mac, 'AA:BB:CC:DD:EE:FF');
    });

    test('nothing found returns null', () {
      expect(parseScannedText('hello world'), isNull);
      expect(parseScannedText(''), isNull);
    });
  });
}
