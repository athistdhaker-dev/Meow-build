#!/usr/bin/env python3
"""Patch the flutter-created android/ folder for BT Share Connect (mobile).

Run from the project root AFTER `flutter create`:   python3 tools/patch_manifest.py

 * restarts from AndroidManifest.xml.orig (safe to run repeatedly)
 * sets android:label
 * copies launcher icons into android/app/src/main/res
 * writes MainActivity.kt from tools/MainActivity.kt.template
"""
import glob
import os
import re
import shutil
import sys

APP_LABEL = "BT Share Connect"
PACKAGE = "com.maraj.bt_share"

ROOT = os.getcwd()
MAIN = os.path.join(ROOT, "android", "app", "src", "main")
MANIFEST = os.path.join(MAIN, "AndroidManifest.xml")
ORIG = MANIFEST + ".orig"
ICONS = os.path.join(ROOT, "assets", "android_icons")
TEMPLATE = os.path.join(ROOT, "tools", "MainActivity.kt.template")


def main():
    if not os.path.isfile(MANIFEST) and not os.path.isfile(ORIG):
        sys.exit("android/ not found - run `flutter create` first")

    if not os.path.isfile(ORIG):
        shutil.copyfile(MANIFEST, ORIG)
    with open(ORIG, encoding="utf-8") as f:
        xml = f.read()

    xml, n = re.subn(r'android:label="[^"]*"', 'android:label="%s"' % APP_LABEL, xml, count=1)
    if n != 1:
        sys.exit("could not find android:label in the manifest")

    perms = "\n".join(
        '    <uses-permission android:name="%s"/>' % p
        for p in [
            "android.permission.BLUETOOTH",
            "android.permission.BLUETOOTH_ADMIN",
            "android.permission.BLUETOOTH_CONNECT",
            "android.permission.BLUETOOTH_SCAN",
            "android.permission.ACCESS_FINE_LOCATION",
            "android.permission.CAMERA",
        ]
    )
    xml, n = re.subn(r"(<manifest[^>]*>)", r"\1\n" + perms, xml, count=1)
    if n != 1:
        sys.exit("could not find <manifest> tag")

    with open(MANIFEST, "w", encoding="utf-8") as f:
        f.write(xml)

    res = os.path.join(MAIN, "res")
    for d in sorted(glob.glob(os.path.join(ICONS, "mipmap-*"))):
        dst = os.path.join(res, os.path.basename(d))
        os.makedirs(dst, exist_ok=True)
        for png in glob.glob(os.path.join(d, "*.png")):
            shutil.copy(png, dst)
    for p in glob.glob(os.path.join(res, "mipmap-anydpi*", "ic_launcher*.xml")):
        os.remove(p)

    for p in glob.glob(os.path.join(MAIN, "**", "MainActivity.*"), recursive=True):
        os.remove(p)
    kt_dir = os.path.join(MAIN, "kotlin", *PACKAGE.split("."))
    os.makedirs(kt_dir, exist_ok=True)
    with open(TEMPLATE, encoding="utf-8") as f:
        kt = f.read().replace("__PACKAGE__", PACKAGE)
    with open(os.path.join(kt_dir, "MainActivity.kt"), "w", encoding="utf-8") as f:
        f.write(kt)

    print("patched: label=%s package=%s" % (APP_LABEL, PACKAGE))


if __name__ == "__main__":
    main()
