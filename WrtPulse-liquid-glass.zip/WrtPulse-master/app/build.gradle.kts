import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.ksp)
}

// Release signing comes from the environment (CI) or an untracked keystore.properties on a
// workstation. With neither, the release build is simply unsigned — fine for a compile check —
// and `fastlane android release` refuses up front instead of producing something unshippable.
val keystoreProps = Properties().apply {
    rootProject.file("keystore.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}
fun secret(name: String): String? = System.getenv(name)?.takeIf { it.isNotBlank() } ?: keystoreProps.getProperty(name)
val releaseStoreFile = secret("KEYSTORE_FILE")

android {
    namespace = "com.vivekkaushik.wrtpulse"
    compileSdk {
        version = release(36) {
            minorApiLevel = 1
        }
    }

    defaultConfig {
        applicationId = "com.vivekkaushik.wrtpulse"
        minSdk = 28
        targetSdk = 36
        versionCode = 10
        versionName = "1.8"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"

        // The About screen lists the libraries the app ships with. Their versions are read
        // from gradle/libs.versions.toml here rather than typed into Kotlin, so a bump in the
        // catalog is a bump on the screen and the two cannot disagree.
        buildConfigField("String", "LIB_KOTLIN", "\"${libs.versions.kotlin.get()}\"")
        buildConfigField("String", "LIB_COROUTINES", "\"${libs.versions.coroutines.get()}\"")
        buildConfigField("String", "LIB_COMPOSE_BOM", "\"${libs.versions.composeBom.get()}\"")
        buildConfigField("String", "LIB_ACTIVITY_COMPOSE", "\"${libs.versions.activityCompose.get()}\"")
        buildConfigField("String", "LIB_CORE_KTX", "\"${libs.versions.coreKtx.get()}\"")
        buildConfigField("String", "LIB_LIFECYCLE", "\"${libs.versions.lifecycleRuntimeKtx.get()}\"")
        buildConfigField("String", "LIB_ROOM", "\"${libs.versions.room.get()}\"")
        buildConfigField("String", "LIB_BIOMETRIC", "\"${libs.versions.biometric.get()}\"")
        buildConfigField("String", "LIB_JSCH", "\"${libs.versions.jsch.get()}\"")
        buildConfigField("String", "LIB_BOUNCYCASTLE", "\"${libs.versions.bouncycastle.get()}\"")
    }

    signingConfigs {
        if (releaseStoreFile != null) {
            create("release") {
                storeFile = rootProject.file(releaseStoreFile)
                storePassword = secret("KEYSTORE_PASSWORD")
                keyAlias = secret("KEY_ALIAS")
                keyPassword = secret("KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        release {
            signingConfig = signingConfigs.findByName("release")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }
    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_11
        targetCompatibility = JavaVersion.VERSION_11
    }
    buildFeatures {
        compose = true
        // Off by default under AGP 9; on for VERSION_NAME and the LIB_* fields above.
        buildConfig = true
    }
}

dependencies {
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.activity.compose)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.ui.graphics)
    implementation(libs.androidx.compose.ui.tooling.preview)
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.lifecycle.runtime.ktx)
    implementation(libs.jsch)
    implementation(libs.bouncycastle)
    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)
    implementation(libs.androidx.biometric)
    implementation(libs.androidx.fragment.ktx)
    implementation(libs.androidx.lifecycle.runtime.compose)
    testImplementation(libs.junit)
    testImplementation(libs.kotlinx.coroutines.test)
    // Android stubs org.json in JVM tests; use the real implementation for parser tests.
    testImplementation(libs.org.json)
    androidTestImplementation(platform(libs.androidx.compose.bom))
    androidTestImplementation(libs.androidx.compose.ui.test.junit4)
    androidTestImplementation(libs.androidx.espresso.core)
    androidTestImplementation(libs.androidx.junit)
    debugImplementation(libs.androidx.compose.ui.test.manifest)
    debugImplementation(libs.androidx.compose.ui.tooling)
}