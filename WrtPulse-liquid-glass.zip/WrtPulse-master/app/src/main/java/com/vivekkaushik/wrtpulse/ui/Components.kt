package com.vivekkaushik.wrtpulse.ui

import androidx.compose.animation.core.LinearEasing
import com.vivekkaushik.wrtpulse.net.ConnectionState
import com.vivekkaushik.wrtpulse.data.Telemetry
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.compositionLocalOf
import kotlinx.coroutines.currentCoroutineContext
import kotlinx.coroutines.isActive
import androidx.compose.ui.platform.LocalContext
import android.provider.Settings
import android.os.VibratorManager
import android.os.Vibrator
import android.os.VibrationEffect
import android.os.Build
import android.content.Context
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.graphics.drawscope.clipRect
import androidx.compose.animation.core.Animatable
import androidx.compose.foundation.gestures.detectTapGestures
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.BoxScope
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.RowScope
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.pulltorefresh.PullToRefreshBox
import androidx.compose.material3.pulltorefresh.PullToRefreshDefaults
import androidx.compose.material3.pulltorefresh.rememberPullToRefreshState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.StrokeJoin
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.TextUnit.Companion.Unspecified
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.repeatOnLifecycle
import com.vivekkaushik.wrtpulse.data.Refreshable
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.em
import androidx.compose.ui.unit.sp
import com.vivekkaushik.wrtpulse.ui.theme.MonoFamily
import com.vivekkaushik.wrtpulse.ui.theme.SansFamily
import com.vivekkaushik.wrtpulse.ui.theme.Wrt
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxHeight
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.width
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.draw.clip
import androidx.compose.ui.layout.layout
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.IntOffset
import kotlin.math.roundToInt

// ---------- text style helpers ----------

fun sans(
    size: Float,
    weight: Int = 400,
    color: Color = Wrt.TextPrimary,
    lineHeight: TextUnit = Unspecified,
    letterSpacing: TextUnit = Unspecified,
) = TextStyle(
    fontFamily = SansFamily,
    fontWeight = FontWeight(weight),
    fontSize = size.sp,
    color = color,
    lineHeight = lineHeight,
    letterSpacing = letterSpacing,
)

fun mono(
    size: Float,
    weight: Int = 500,
    color: Color = Wrt.TextPrimary,
    lineHeight: TextUnit = Unspecified,
    letterSpacing: TextUnit = Unspecified,
) = TextStyle(
    fontFamily = MonoFamily,
    fontWeight = FontWeight(weight),
    fontSize = size.sp,
    color = color,
    lineHeight = lineHeight,
    letterSpacing = letterSpacing,
)

/** Mono section label, e.g. "HOST" / "MAINTENANCE". */
@Composable
fun SectionLabel(
    text: String,
    color: Color = Wrt.TextDim,
    size: Float = 10f,
    tracking: Double = 0.12,
    modifier: Modifier = Modifier,
) {
    Text(text, style = mono(size, 600, color, letterSpacing = tracking.em), modifier = modifier)
}

// ---------- surfaces ----------

@Composable
fun WCard(
    modifier: Modifier = Modifier,
    border: Color = Wrt.BorderCard,
    background: Color = Wrt.BgCard,
    radius: Dp = 13.dp,
    body: @Composable () -> Unit,
) {
    val shape = RoundedCornerShape(radius)
    Box(
        modifier
            // The default border is the glass rim; a caller that passes its own colour
            // (a warning outline, say) keeps exactly that.
            .let { if (border == Wrt.BorderCard) it.glassBorder(shape) else it.border(1.dp, border, shape) }
            .glassBg(shape, background)
    ) { body() }
}

// ---------- small atoms ----------

/** Status dot with the design's ring-pulse (2.4 s teal/green, 1.6 s amber). Static when [pulse] is false. */
@Composable
fun StatusDot(color: Color, size: Dp = 8.dp, pulse: Boolean = false, periodMs: Int = 2400) {
    if (!pulse) {
        Box(Modifier.size(size).background(color, CircleShape))
        return
    }
    val t by rememberInfiniteTransition(label = "pulse").animateFloat(
        0f, 1f,
        infiniteRepeatable(tween(periodMs, easing = LinearEasing), RepeatMode.Restart),
        label = "pulseT",
    )
    Canvas(Modifier.size(size)) {
        val r = this.size.minDimension / 2f
        // ring expands to +7dp over the first 70% of the period while fading out
        val phase = (t / 0.7f).coerceAtMost(1f)
        val ringR = r + 7.dp.toPx() * phase
        val alpha = (1f - phase) * 0.45f
        if (alpha > 0.01f) drawCircle(color.copy(alpha = alpha), radius = ringR)
        drawCircle(color, radius = r)
    }
}

/** 34x19 toggle from the design. */
@Composable
fun WToggle(checked: Boolean, onToggle: (() -> Unit)? = null) {
    val track = if (checked) Wrt.Accent.copy(alpha = 0.16f) else Wrt.TrackOff
    val borderC = if (checked) Wrt.Accent.copy(alpha = 0.5f) else Wrt.TrackOffBorder
    val knob = if (checked) Wrt.Accent else Wrt.KnobOff
    Box(
        Modifier
            .size(34.dp, 19.dp)
            .border(1.dp, borderC, RoundedCornerShape(10.dp))
            .background(track, RoundedCornerShape(10.dp))
            .let { if (onToggle != null) it.clickable { onToggle() } else it }
    ) {
        Box(
            Modifier
                .align(if (checked) Alignment.CenterEnd else Alignment.CenterStart)
                .padding(2.dp)
                .size(13.dp)
                .background(knob, CircleShape)
        )
    }
}

/** Rounded filter chip: filled accent when selected, hairline outline otherwise. */
@Composable
fun FilterChip(
    text: String,
    selected: Boolean,
    size: Float = 12f,
    padH: Dp = 13.dp,
    padV: Dp = 6.dp,
    mono: Boolean = false,
    selectedColor: Color = Wrt.Accent,
    onClick: (() -> Unit)? = null,
) {
    val style = if (mono) mono(size, if (selected) 600 else 500) else sans(size, if (selected) 600 else 500)
    val shape = RoundedCornerShape(50)
    Box(
        Modifier
            .let {
                if (selected) it.background(selectedColor, shape)
                else it.border(1.dp, Wrt.BorderCard, shape)
            }
            .let { if (onClick != null) it.clickable(onClick = onClick) else it }
            .padding(horizontal = padH, vertical = padV)
    ) {
        Text(text, style = style.copy(color = if (selected) Wrt.OnAccent else Wrt.TextSecondary))
    }
}

/**
 * The hub-card chip from design screen 20 — `192.168.1.1/24`, `● DHCP active`, `12 clients`.
 *
 * One shape whether or not it carries a dot. The cards used to mix this with [MonoTag], which
 * is a size smaller in every dimension, so "Connected" and the address beside it came out
 * different heights and read as a mistake.
 */
@Composable
fun InfoChip(
    text: String,
    color: Color = Wrt.TextTertiary,
    border: Color = Wrt.BorderInput,
    dot: Color? = null,
) {
    Row(
        Modifier
            .border(1.dp, border, RoundedCornerShape(5.dp))
            .padding(horizontal = 7.dp, vertical = 3.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(5.dp),
    ) {
        if (dot != null) StatusDot(dot, 5.dp)
        Text(text, style = mono(10f, 500, color), maxLines = 1)
    }
}

/** Tiny bordered mono tag, e.g. "HOME", "WPA3-SAE", "Casa · 5G". */
@Composable
fun MonoTag(text: String, color: Color = Wrt.TextTertiary, border: Color = Wrt.BorderInput, size: Float = 9f) {
    Box(
        Modifier
            .border(1.dp, border, RoundedCornerShape(4.dp))
            .padding(horizontal = 5.dp, vertical = 2.dp)
    ) {
        Text(text, style = mono(size, 600, color, letterSpacing = 0.08.em))
    }
}

/** Wireless signal bars (heights 5/8/11/14, 3dp wide). [bars] of 4 are lit. */
@Composable
fun SignalBars(bars: Int, color: Color = Wrt.Green) {
    Row(verticalAlignment = Alignment.Bottom, horizontalArrangement = Arrangement.spacedBy(2.dp)) {
        listOf(5, 8, 11, 14).forEachIndexed { i, h ->
            Box(
                Modifier
                    .size(3.dp, h.dp)
                    .background(if (i < bars) color else Wrt.SparkDim, RoundedCornerShape(1.dp))
            )
        }
    }
}

/** Router front-panel glyph (the 2c icon): body outline, two antennas, LED row. */
@Composable
fun RouterGlyph(
    size: Dp,
    bodyColor: Color = Wrt.TextTertiary,
    antennaColor: Color = Wrt.DotOff,
    leds: List<Color> = listOf(Wrt.Green, Wrt.Accent),
    strokeDp: Float = 1.4f,
) {
    Canvas(Modifier.size(size)) {
        val s = this.size.width / 24f
        val stroke = Stroke(width = strokeDp.dp.toPx(), cap = StrokeCap.Round, join = StrokeJoin.Round)
        // antennas: M7 13V6  M17 13V6
        drawLine(antennaColor, androidx.compose.ui.geometry.Offset(7f * s, 13f * s), androidx.compose.ui.geometry.Offset(7f * s, 6f * s), stroke.width, StrokeCap.Round)
        drawLine(antennaColor, androidx.compose.ui.geometry.Offset(17f * s, 13f * s), androidx.compose.ui.geometry.Offset(17f * s, 6f * s), stroke.width, StrokeCap.Round)
        // body: rect x3 y13 w18 h7 rx2
        drawRoundRect(
            bodyColor,
            topLeft = androidx.compose.ui.geometry.Offset(3f * s, 13f * s),
            size = androidx.compose.ui.geometry.Size(18f * s, 7f * s),
            cornerRadius = androidx.compose.ui.geometry.CornerRadius(2f * s),
            style = stroke,
        )
        // LEDs at (6.8,16.5) (10,16.5) ...
        leds.forEachIndexed { i, c ->
            drawCircle(c, radius = 0.9f * s, center = androidx.compose.ui.geometry.Offset((6.8f + i * 3.2f) * s, 16.5f * s))
        }
    }
}

/** Small square icon tile used for router avatars. */
@Composable
fun RouterTile(size: Dp = 42.dp, ledColor: Color = Wrt.Accent, dim: Boolean = false) {
    Box(
        Modifier
            .size(size)
            .glassBorder(RoundedCornerShape(11.dp))
            .background(Wrt.BgDeep, RoundedCornerShape(11.dp)),
        contentAlignment = Alignment.Center,
    ) {
        RouterGlyph(
            size = size * 26f / 42f,
            bodyColor = if (dim) Wrt.TextDim else Wrt.TextTertiary,
            antennaColor = if (dim) Wrt.TextDim else Wrt.DotOff,
            leds = listOf(ledColor),
        )
    }
}

// ---------- charts ----------

/** Static sparkline from a fixed point list (design's CPU/RAM mini charts). */
@Composable
fun Sparkline(
    points: List<Float>,
    color: Color,
    modifier: Modifier = Modifier,
    /** The value that reaches the top. Zero or less auto-scales to the series' own peak. */
    maxY: Float = 18f,
) {
    Canvas(modifier) {
        if (points.size < 2) return@Canvas
        val ceiling = if (maxY > 0f) maxY else (points.maxOrNull() ?: 1f).coerceAtLeast(1f)
        val w = size.width
        val h = size.height
        val step = w / (points.size - 1)
        val p = Path()
        points.forEachIndexed { i, v ->
            val x = i * step
            val y = sparkY(v, ceiling, h)
            if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
        }
        drawPath(p, color, alpha = 0.75f, style = Stroke(1.4.dp.toPx(), cap = StrokeCap.Round))
    }
}

/**
 * Where one sparkline point sits, in canvas coordinates — where y grows DOWNWARD.
 *
 * This used to be `v / maxY * h`, which put zero at the top and the peak at the bottom: every
 * sparkline in the app was drawn upside down, so rising CPU sloped downhill. Values past the
 * ceiling clamp to the edges instead of drawing outside the box.
 */
internal fun sparkY(value: Float, maxY: Float, height: Float): Float =
    height - (value / maxY).coerceIn(0f, 1f) * height

/**
 * Live WAN throughput chart: teal down series with area fill, blue up line, three hairline
 * gridlines. New points append on the right.
 *
 * The series arrive in whatever units the caller holds and are scaled here against whichever
 * of the two peaked. That used to be the caller's job, silently — a chart that wanted 0..100
 * is a chart someone hands Mbps to, and the WAN card's line duly sat flat along the bottom.
 */
@Composable
fun ThroughputChart(down: List<Float>, up: List<Float>, modifier: Modifier = Modifier) {
    val (scaledDown, scaledUp) =
        com.vivekkaushik.wrtpulse.data.Telemetry.normalize(down, up)
    ThroughputChartScaled(scaledDown, scaledUp, modifier)
}

@Composable
private fun ThroughputChartScaled(down: List<Float>, up: List<Float>, modifier: Modifier = Modifier) {
    Canvas(modifier) {
        val w = size.width
        val h = size.height
        // gridlines at 25/50/75%
        for (f in listOf(0.25f, 0.5f, 0.75f)) {
            drawLine(Wrt.BorderRow, androidx.compose.ui.geometry.Offset(0f, h * f), androidx.compose.ui.geometry.Offset(w, h * f), 1.dp.toPx())
        }
        fun linePath(arr: List<Float>): Path {
            val p = Path()
            val step = w / (arr.size - 1)
            arr.forEachIndexed { i, v ->
                val x = i * step
                val y = h - 4.dp.toPx() - (v / 100f) * (h - 10.dp.toPx())
                if (i == 0) p.moveTo(x, y) else p.lineTo(x, y)
            }
            return p
        }
        val downPath = linePath(down)
        val area = Path().apply {
            addPath(downPath)
            lineTo(w, h); lineTo(0f, h); close()
        }
        drawPath(area, Wrt.Accent.copy(alpha = 0.13f))
        drawPath(downPath, Wrt.Accent, style = Stroke(1.6.dp.toPx()))
        drawPath(linePath(up), Wrt.Blue, alpha = 0.85f, style = Stroke(1.2.dp.toPx()))
    }
}

// ---------- buttons ----------

@Composable
fun PrimaryButton(text: String, modifier: Modifier = Modifier, color: Color = Wrt.Accent, textColor: Color = Wrt.OnAccent, onClick: () -> Unit) {
    Box(
        modifier
            .fillMaxWidth()
            .height(48.dp)
            .background(color, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = sans(14.5f, 650, textColor))
    }
}

@Composable
fun GhostButton(
    text: String,
    modifier: Modifier = Modifier,
    border: Color = Wrt.BorderCard,
    textColor: Color = Wrt.TextSecondary,
    onClick: () -> Unit,
) {
    Box(
        modifier
            .fillMaxWidth()
            .height(44.dp)
            .border(1.dp, border, RoundedCornerShape(12.dp))
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Text(text, style = sans(13.5f, 600, textColor))
    }
}

// ---------- app chrome ----------

/** Connected-router top bar: pulsing dot, router name, chevron, live latency chip, trailing icon. */
/** Above this, the poll is worth showing next to the latency it was being mistaken for. */
const val SLOW_POLL_MS = 250

/**
 * The live poll of the router in hand, provided once over the main screens so the bar on
 * every one of them can show a lost link without each screen being told. Null where there
 * is no live router — the design-time list.
 */
val LocalLiveTelemetry = compositionLocalOf<Telemetry?> { null }

@Composable
fun ConnectionTopBar(
    routerName: String,
    latencyMs: Int,
    /**
     * What the batched poll costs the router. Shown beside the latency only when it is slow
     * enough to matter, because that is the number people were reading AS latency — on a
     * single-core router it runs 10-20x the round trip, and seeing both makes it obvious
     * that the router is busy rather than far away.
     */
    pollMs: Int? = null,
    pulse: Boolean = true,
    trailing: (@Composable () -> Unit)? = null,
    onRouterTap: (() -> Unit)? = null,
    chevronUp: Boolean = false,
) {
    // A dead router used to look exactly like a live one here: a pulsing green dot and the
    // last latency figure, both frozen. Liveness comes from the poll — replies stopped after
    // they had been arriving — and the bar says so instead.
    val live = LocalLiveTelemetry.current
    val lostAt = live?.lostAtMillis
    val state = live?.let { it.connection.collectAsState().value }
    // Once the router has answered, the session dialling again IS the outage — and it is the
    // part that lasts longest, so it cannot wait for a poll to give up before it shows.
    val redialing = live?.everLoaded == true &&
        (state is ConnectionState.Connecting || state is ConnectionState.Reconnecting || state is ConnectionState.Failed)
    val lost = lostAt != null || redialing
    var now by remember { mutableStateOf(System.currentTimeMillis()) }
    LaunchedEffect(lost) { while (lost) { now = System.currentTimeMillis(); delay(1_000) } }
    Row(
        Modifier
            .fillMaxWidth()
            .height(52.dp)
            .glassBar()
            .padding(horizontal = 14.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(8.dp),
    ) {
        Row(
            Modifier.let { if (onRouterTap != null) it.clickable(onClick = onRouterTap) else it },
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            StatusDot(if (lost) Wrt.Amber else Wrt.Accent, 8.dp, pulse = pulse && !lost)
            Text(routerName, style = sans(14.5f, 650))
            Icon(
                if (chevronUp) WrtIcons.ChevronUp else WrtIcons.ChevronDown,
                null,
                Modifier.size(13.dp),
                tint = Wrt.TextDim,
            )
        }
        Box(Modifier.weight(1f))
        Box(
            Modifier
                .border(1.dp, if (lost) Wrt.Amber.copy(alpha = 0.45f) else Wrt.BorderCard, RoundedCornerShape(6.dp))
                .padding(horizontal = 8.dp, vertical = 3.dp)
        ) {
            // A figure from before the link died would be a lie; say what is actually known.
            Text(
                if (lost) "no reply" else "$latencyMs ms",
                style = mono(10.5f, 500, if (lost) Wrt.Amber else Wrt.TextTertiary),
            )
        }
        pollMs?.takeIf { it >= SLOW_POLL_MS }?.let {
            Box(
                Modifier
                    .border(1.dp, Wrt.Amber.copy(alpha = 0.45f), RoundedCornerShape(6.dp))
                    .padding(horizontal = 8.dp, vertical = 3.dp)
            ) {
                Text("poll $it ms", style = mono(10.5f, 500, Wrt.Amber))
            }
        }
        trailing?.invoke()
    }
    HorizontalHairline()
    if (lost) {
        // The strip stays until a reply lands again. Amber, not red: the poll keeps trying
        // on its own, and the router is very often just rebooting.
        val silentFor = lostAt?.let { ((now - it) / 1_000).coerceAtLeast(0) }
        Row(
            Modifier
                .fillMaxWidth()
                .background(Wrt.Amber.copy(alpha = 0.08f))
                .let { if (onRouterTap != null) it.clickable(onClick = onRouterTap) else it }
                .padding(horizontal = 14.dp, vertical = 8.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp),
        ) {
            Icon(WrtIcons.Warning, null, Modifier.size(14.dp), tint = Wrt.Amber)
            Text(
                when {
                    state is ConnectionState.Reconnecting ->
                        "Reconnecting to $routerName — attempt ${state.attempt} of ${state.maxAttempts}"
                    state is ConnectionState.Connecting -> "Reconnecting to $routerName…"
                    silentFor != null -> "No reply from $routerName for $silentFor s — retrying"
                    else -> "No reply from $routerName — retrying"
                },
                style = sans(11.5f, 500, Wrt.AmberText),
                modifier = Modifier.weight(1f),
            )
            if (onRouterTap != null) Text("Switch", style = sans(11.5f, 650, Wrt.Amber))
        }
        HorizontalHairline(Wrt.Amber.copy(alpha = 0.3f))
    }
}

/** One button in a [SwipeToReveal] panel. */
data class RevealAction(
    val label: String,
    val icon: ImageVector,
    val tint: Color,
    val onAction: () -> Unit,
)

/**
 * A row that slides aside to reveal one or more actions, per design screen 3e's 78px panel.
 *
 * Shared because several screens need it — wireless interfaces and the saved-router list —
 * and the first hand-rolled copy had already drifted before the second one existed.
 * [content] is handed the modifier that carries the offset and the drag, so the caller keeps
 * its own border, background and click handling.
 *
 * The panel is laid out end-aligned, so the LAST action sits at the screen edge: put the
 * destructive one there, which is what a full swipe reaches.
 */
@Composable
fun SwipeToReveal(
    actions: List<RevealAction>,
    /** Changing this snaps the row shut — pass the row's identity so a list reshuffle
     *  cannot leave a different item held open. */
    resetKey: Any? = null,
    /** Width of ONE action; the reveal is this times the number of actions. */
    revealWidth: Dp = 78.dp,
    corner: Dp = 13.dp,
    behind: Color = Wrt.BgCardDim,
    /** Kept for callers; glass rows are never painted over, see the clip on the actions. */
    @Suppress("UNUSED_PARAMETER")
    base: Color = Wrt.BgSolid,
    content: @Composable (Modifier) -> Unit,
) {
    if (actions.isEmpty()) {
        content(Modifier)
        return
    }
    val revealPx = with(LocalDensity.current) { (revealWidth * actions.size).toPx() }
    var target by remember(resetKey) { mutableFloatStateOf(0f) }
    val offset by animateFloatAsState(target, label = "reveal")
    Box(Modifier.fillMaxWidth().clip(RoundedCornerShape(corner))) {
        Row(
            Modifier
                .matchParentSize()
                // Glass rows are translucent, so actions parked behind them would show through
                // an untouched row. Only the strip the row has slid off is ever painted.
                .drawWithContent {
                    clipRect(left = (size.width + offset).coerceIn(0f, size.width)) {
                        this@drawWithContent.drawContent()
                    }
                }
                .background(behind),
            horizontalArrangement = Arrangement.End,
        ) {
            actions.forEach { action ->
                Column(
                    Modifier
                        .width(revealWidth)
                        .fillMaxHeight()
                        .background(action.tint.copy(alpha = 0.2f))
                        .clickable { action.onAction(); target = 0f },
                    verticalArrangement = Arrangement.Center,
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Icon(action.icon, null, Modifier.size(15.dp), tint = action.tint)
                    Spacer(Modifier.height(3.dp))
                    Text(action.label, style = sans(9f, 600, action.tint))
                }
            }
        }
        content(
            Modifier
                .offset { IntOffset(offset.roundToInt(), 0) }
                .draggable(
                    orientation = Orientation.Horizontal,
                    state = rememberDraggableState { delta ->
                        target = (target + delta).coerceIn(-revealPx, 0f)
                    },
                    onDragStopped = { target = if (target < -revealPx / 2f) -revealPx else 0f },
                )
        )
    }
}

@Composable
fun HorizontalHairline(color: Color = Wrt.BorderHair) {
    Box(Modifier.fillMaxWidth().height(1.dp).background(color))
}

enum class MainTab(val label: String) {
    Dashboard("Dashboard"), Network("Network"), Clients("Clients"), Terminal("Terminal"), System("System")
}

fun tabIcon(tab: MainTab): ImageVector = when (tab) {
    MainTab.Dashboard -> WrtIcons.Dashboard
    MainTab.Network -> WrtIcons.Network
    MainTab.Clients -> WrtIcons.Clients
    MainTab.Terminal -> WrtIcons.Terminal
    MainTab.System -> WrtIcons.System
}

/** Height of [WrtBottomNav] including its hairline, for screens that budget their own height. */
val WrtBottomNavHeight = 63.dp

@Composable
fun WrtBottomNav(current: MainTab, onSelect: (MainTab) -> Unit) {
    Column(Modifier.glassBar()) {
        HorizontalHairline()
        Row(Modifier.fillMaxWidth().height(WrtBottomNavHeight - 1.dp)) {
            MainTab.entries.forEach { tab ->
                val active = tab == current
                val c = if (active) Wrt.Accent else Wrt.TextDim
                Column(
                    Modifier
                        .weight(1f)
                        .clickable { onSelect(tab) }
                        .padding(top = 9.dp),
                    horizontalAlignment = Alignment.CenterHorizontally,
                    verticalArrangement = Arrangement.spacedBy(3.dp),
                ) {
                    Icon(tabIcon(tab), tab.label, Modifier.size(21.dp), tint = c)
                    Text(tab.label, style = sans(9.5f, if (active) 600 else 500, c))
                }
            }
        }
    }
}

/** Convenience row spacer. */
@Composable
fun RowScope.FlexSpacer() = Box(Modifier.weight(1f))


/**
 * Keeps a store current for as long as the caller is on screen and the app is in the
 * foreground: one read on arrival, then another every [intervalMs].
 *
 * Reading on arrival rather than only when `!loaded` is deliberate — a page left open while
 * the phone slept should not spend a whole interval showing the past when it wakes. The loop
 * stays out of the way of a write in flight (that has its own re-read) and of anything the
 * store says should pause it. Lifecycle-scoped the same way Telemetry is, so a backgrounded
 * app polls nothing.
 */
@Composable
fun LiveRefresh(store: Refreshable?, intervalMs: Long) {
    val lifecycle = LocalLifecycleOwner.current.lifecycle
    LaunchedEffect(store) {
        if (store == null) return@LaunchedEffect
        lifecycle.repeatOnLifecycle(Lifecycle.State.STARTED) {
            if (!store.applying && !store.refreshPaused) store.load()
            while (true) {
                delay(intervalMs)
                if (!store.applying && !store.refreshPaused) store.load()
            }
        }
    }
}

/**
 * Pull down to re-read the router.
 *
 * The stores already know how to re-read safely — a `load()` rebuilds the read-only base
 * and leaves staged edits alone — so this is only the gesture in front of it. The spinner
 * stays for as long as the read takes and not a moment less: one that vanished before the
 * router answered told the user nothing about whether anything was read. A second pull
 * while one is in flight is ignored rather than queued, since two reads of the same thing
 * answer the same question.
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PullToRefresh(
    modifier: Modifier = Modifier,
    /** False when there is nothing to read — a demo screen with no router behind it. */
    enabled: Boolean = true,
    onRefresh: suspend () -> Unit,
    content: @Composable BoxScope.() -> Unit,
) {
    if (!enabled) {
        Box(modifier, content = content)
        return
    }
    val scope = rememberCoroutineScope()
    var refreshing by remember { mutableStateOf(false) }
    val state = rememberPullToRefreshState()
    PullToRefreshBox(
        isRefreshing = refreshing,
        onRefresh = {
            if (!refreshing) {
                scope.launch {
                    refreshing = true
                    try {
                        onRefresh()
                    } finally {
                        refreshing = false
                    }
                }
            }
        },
        modifier = modifier,
        state = state,
        indicator = {
            PullToRefreshDefaults.Indicator(
                state = state,
                isRefreshing = refreshing,
                modifier = Modifier.align(Alignment.TopCenter),
                containerColor = Wrt.BgDialog,
                color = Wrt.Accent,
            )
        },
        content = content,
    )
}

/**
 * A button that has to be HELD for [holdMs] before it does anything — the confirm for an
 * action with no undo. A fill sweeps across while the finger is down; letting go early
 * drains it and nothing happens. It replaces the older tap-twice pattern, whose second tap
 * could land by accident right after the first.
 *
 * [holdLabel] shows while held, so it can carry the consequence ("Hold — the router
 * reboots"). [onHoldingChange] lets a screen show a longer note beside it while the hold
 * runs, the way a warning used to appear once a button was armed.
 *
 * It is felt as well as seen, the whole way: a train of pulses runs under the finger for as
 * long as the hold does, each one stronger and closer to the next as the fill nears the
 * end, so the approach to the threshold is in the hand and not only the eye. Reaching it
 * lands one firm confirm; letting go early stops the train with a soft end-pulse — the
 * signal that nothing happened. That feel is [HoldHaptics], shared with every other hold
 * control in the app, so a three-second hold feels the same wherever it is.
 */
@Composable
fun HoldButton(
    label: String,
    holdLabel: String,
    modifier: Modifier = Modifier,
    danger: Boolean = false,
    enabled: Boolean = true,
    holdMs: Int = 3_000,
    height: Dp = 44.dp,
    /**
     * For a hold standing inline beside text, in place of a chip: the parent measures and
     * aligns the button alone, and the caption hangs below it into room the parent keeps
     * free — so the row lines up on the button and stays the height it was.
     */
    captionHangs: Boolean = false,
    onHoldingChange: (Boolean) -> Unit = {},
    onConfirm: () -> Unit,
) {
    val progress = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val haptics = rememberHoldHaptics()
    var holding by remember { mutableStateOf(false) }
    fun setHolding(v: Boolean) { if (holding != v) { holding = v; onHoldingChange(v) } }
    val tone = if (danger) Wrt.Red else Wrt.Accent
    val shape = RoundedCornerShape(11.dp)
    // The button, and under it the one line that says how it works — the same line under
    // every hold in the app, so the gesture never has to be guessed at.
    Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Box(
        modifier
            .height(height)
            .clip(shape)
            .border(1.dp, if (holding) tone else if (enabled) tone.copy(alpha = 0.5f) else Wrt.BorderCard, shape)
            .drawBehind { drawRect(tone.copy(alpha = 0.22f), size = Size(size.width * progress.value, size.height)) }
            .pointerInput(enabled, holdMs) {
                if (!enabled) return@pointerInput
                detectTapGestures(onPress = {
                    setHolding(true)
                    val run = scope.launch {
                        progress.snapTo(0f)
                        // The feel runs as a child of the hold, so ending the hold ends it.
                        val train = launch { haptics.train { progress.value } }
                        progress.animateTo(1f, tween(holdMs, easing = LinearEasing))
                        train.cancel()
                        // Held the whole way: it happens now, finger still down, on one firm confirm.
                        setHolding(false)
                        haptics.confirm()
                        onConfirm()
                        progress.snapTo(0f)
                    }
                    tryAwaitRelease()
                    if (run.isActive) {
                        // Let go early: the train stops, nothing happens, and the fill drains away.
                        run.cancel()
                        setHolding(false)
                        haptics.release()
                        scope.launch { progress.animateTo(0f, tween(180)) }
                    }
                })
            }
            .padding(horizontal = 14.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            if (holding) holdLabel else label,
            style = sans(12.5f, 650, if (enabled) tone else Wrt.TextDim),
            maxLines = 1, overflow = TextOverflow.Ellipsis,
        )
    }
    Text(
        "Hold for ${holdMs / 1000} s",
        style = mono(9.5f, 500, Wrt.TextFaint),
        modifier = if (captionHangs) {
            // Measured as nothing and drawn in full, a little closer under a button this small.
            Modifier
                .layout { measurable, constraints ->
                    val caption = measurable.measure(constraints.copy(minHeight = 0, maxHeight = Constraints.Infinity))
                    layout(caption.width, 0) { caption.place(0, 0) }
                }
                .padding(top = 2.dp)
        } else {
            Modifier.padding(top = 5.dp)
        },
    )
    }
}

/**
 * The feel of a three-second hold, shared by every hold-to-confirm control in the app so
 * they all feel alike: a train of pulses that climbs with the fill — amplitude 60 → 255 of
 * 255, the gap closing 140 → 45 ms — one firm confirm when the hold lands, and a soft
 * end-pulse when it is let go early. The ramp needs amplitude control, which the fixed
 * patterns in Compose's haptic API do not offer, so it is drawn on the platform vibrator
 * directly; the system's touch-feedback setting still switches all of it off.
 */
class HoldHaptics internal constructor(private val vibrator: Vibrator?, private val on: Boolean) {
    /** Pulses until cancelled. Run it as a child of the hold, so ending the hold ends it. */
    suspend fun train(progress: () -> Float) {
        if (!on || vibrator == null) return
        while (currentCoroutineContext().isActive) {
            val p = progress()
            vibrator.pulse(22, (60 + 195 * p).toInt())
            delay((140 - 95 * p).toLong())
        }
    }

    /** The hold reached its end: one firm pulse as the action fires. */
    fun confirm() { if (on) vibrator?.pulse(80, 255) }

    /** Let go early: whatever is playing stops, and one soft pulse says nothing happened. */
    fun release() { vibrator?.cancel(); if (on) vibrator?.pulse(18, 50) }
}

@Composable
fun rememberHoldHaptics(): HoldHaptics {
    val context = LocalContext.current
    return remember(context) {
        HoldHaptics(
            vibratorOf(context),
            runCatching { Settings.System.getInt(context.contentResolver, Settings.System.HAPTIC_FEEDBACK_ENABLED, 1) == 1 }.getOrDefault(true),
        )
    }
}

/** The device's vibrator, or null where there is none. */
private fun vibratorOf(context: Context): Vibrator? = runCatching {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
        (context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager).defaultVibrator
    } else {
        @Suppress("DEPRECATION")
        context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
    }
}.getOrNull()?.takeIf { it.hasVibrator() }

/** One short pulse at [amplitude] (1–255); a motor without amplitude control just clicks. */
private fun Vibrator.pulse(ms: Long, amplitude: Int) {
    runCatching { vibrate(VibrationEffect.createOneShot(ms, amplitude.coerceIn(1, 255))) }
}
