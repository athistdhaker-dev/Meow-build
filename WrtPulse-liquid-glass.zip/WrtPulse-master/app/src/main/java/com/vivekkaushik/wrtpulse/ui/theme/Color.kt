package com.vivekkaushik.wrtpulse.ui.theme

import androidx.compose.runtime.Immutable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.setValue
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.lerp

/**
 * Every colour the UI paints with, for one theme.
 *
 * The screens never read this directly: they read [Wrt], whose properties forward to the
 * palette that is current. [Wrt.palette] is Compose state, so switching theme repaints whatever
 * read a colour, with no screen having to be told.
 *
 * All themes are "liquid glass": the surfaces are translucent whites (or inks, on the light
 * theme) laid over the aurora backdrop that [WrtPulseTheme] paints, so what shows through a card
 * is the theme's own colour. The solid `bgSolid`, `bgSheet` and `bgDialog` exist for the few
 * places that must not show what is behind them.
 */
@Immutable
class WrtPalette(
    val id: String,
    val label: String,
    val isLight: Boolean,
    val auroraTop: Color,
    val auroraBottom: Color,
    val blobA: Color,
    val blobB: Color,
    val blobC: Color,
    val bgScreen: Color,
    val bgSolid: Color,
    val bgBar: Color,
    val bgDeep: Color,
    val bgCard: Color,
    val bgCardDim: Color,
    val bgSheet: Color,
    val bgDialog: Color,
    val bgCode: Color,
    val bgPendingBar: Color,
    val glassEdgeHi: Color,
    val glassEdgeLo: Color,
    val glassSheen: Color,
    val scrim: Color,
    val borderHair: Color,
    val borderCard: Color,
    val borderInput: Color,
    val borderIcon: Color,
    val borderRow: Color,
    val borderFaint: Color,
    val textPrimary: Color,
    val textSecondary: Color,
    val textTertiary: Color,
    val textDim: Color,
    val textFaint: Color,
    val textLogToken: Color,
    val accent: Color,
    val onAccent: Color,
    val green: Color,
    val amber: Color,
    val amberText: Color,
    val red: Color,
    val blue: Color,
    val knobOff: Color,
    val trackOff: Color,
    val trackOffBorder: Color,
    val dotOff: Color,
    val progressTrack: Color,
    val sparkDim: Color,
    val termBg: Color,
    val termBarBg: Color,
    val termBorder: Color,
    val termText: Color,
    val termTabActive: Color,
    val termTabBorder: Color,
    val termKeyBg: Color,
    val termKeyAltBg: Color,
    val termExtraKeyBg: Color,
    val termExtraKeyBorder: Color,
    val termKeyText: Color,
    val termExtraKeyText: Color,
    val termRowBg: Color,
    val termRowBorder: Color,
    val dangerBg: Color,
    val dangerCode: Color,
    val dangerCodeBg: Color,
    val dangerCodeBorder: Color,
    val dangerText: Color,
    val dangerBody: Color,
    val dangerDim: Color,
    val dangerMono: Color,
    val dangerSub: Color,
    val dangerOutlineText: Color,
    val dangerLoss: Color,
    val accentBody: Color,
    val onRed: Color,
)

/** The colour the current theme paints with. Properties keep the names the screens already use. */
object Wrt {
    /** The current theme. State, so a change recomposes every reader. */
    var palette: WrtPalette by mutableStateOf(WrtThemes.Midnight)

    val AuroraTop: Color get() = palette.auroraTop
    val AuroraBottom: Color get() = palette.auroraBottom
    val BlobA: Color get() = palette.blobA
    val BlobB: Color get() = palette.blobB
    val BlobC: Color get() = palette.blobC
    val BgScreen: Color get() = palette.bgScreen
    val BgSolid: Color get() = palette.bgSolid
    val BgBar: Color get() = palette.bgBar
    val BgDeep: Color get() = palette.bgDeep
    val BgCard: Color get() = palette.bgCard
    val BgCardDim: Color get() = palette.bgCardDim
    val BgSheet: Color get() = palette.bgSheet
    val BgDialog: Color get() = palette.bgDialog
    val BgCode: Color get() = palette.bgCode
    val BgPendingBar: Color get() = palette.bgPendingBar
    val GlassEdgeHi: Color get() = palette.glassEdgeHi
    val GlassEdgeLo: Color get() = palette.glassEdgeLo
    val GlassSheen: Color get() = palette.glassSheen
    val Scrim: Color get() = palette.scrim
    val BorderHair: Color get() = palette.borderHair
    val BorderCard: Color get() = palette.borderCard
    val BorderInput: Color get() = palette.borderInput
    val BorderIcon: Color get() = palette.borderIcon
    val BorderRow: Color get() = palette.borderRow
    val BorderFaint: Color get() = palette.borderFaint
    val TextPrimary: Color get() = palette.textPrimary
    val TextSecondary: Color get() = palette.textSecondary
    val TextTertiary: Color get() = palette.textTertiary
    val TextDim: Color get() = palette.textDim
    val TextFaint: Color get() = palette.textFaint
    val TextLogToken: Color get() = palette.textLogToken
    val Accent: Color get() = palette.accent
    val OnAccent: Color get() = palette.onAccent
    val Green: Color get() = palette.green
    val Amber: Color get() = palette.amber
    val AmberText: Color get() = palette.amberText
    val Red: Color get() = palette.red
    val Blue: Color get() = palette.blue
    val KnobOff: Color get() = palette.knobOff
    val TrackOff: Color get() = palette.trackOff
    val TrackOffBorder: Color get() = palette.trackOffBorder
    val DotOff: Color get() = palette.dotOff
    val ProgressTrack: Color get() = palette.progressTrack
    val SparkDim: Color get() = palette.sparkDim
    val TermBg: Color get() = palette.termBg
    val TermBarBg: Color get() = palette.termBarBg
    val TermBorder: Color get() = palette.termBorder
    val TermText: Color get() = palette.termText
    val TermTabActive: Color get() = palette.termTabActive
    val TermTabBorder: Color get() = palette.termTabBorder
    val TermKeyBg: Color get() = palette.termKeyBg
    val TermKeyAltBg: Color get() = palette.termKeyAltBg
    val TermExtraKeyBg: Color get() = palette.termExtraKeyBg
    val TermExtraKeyBorder: Color get() = palette.termExtraKeyBorder
    val TermKeyText: Color get() = palette.termKeyText
    val TermExtraKeyText: Color get() = palette.termExtraKeyText
    val TermRowBg: Color get() = palette.termRowBg
    val TermRowBorder: Color get() = palette.termRowBorder
    val DangerBg: Color get() = palette.dangerBg
    val DangerCode: Color get() = palette.dangerCode
    val DangerCodeBg: Color get() = palette.dangerCodeBg
    val DangerCodeBorder: Color get() = palette.dangerCodeBorder
    val DangerText: Color get() = palette.dangerText
    val DangerBody: Color get() = palette.dangerBody
    val DangerDim: Color get() = palette.dangerDim
    val DangerMono: Color get() = palette.dangerMono
    val DangerSub: Color get() = palette.dangerSub
    val DangerOutlineText: Color get() = palette.dangerOutlineText
    val DangerLoss: Color get() = palette.dangerLoss
    val AccentBody: Color get() = palette.accentBody
    val OnRed: Color get() = palette.onRed
}

// ---- building a glass palette -------------------------------------------------------------

private val Ink = Color(0xFF0F1B2D)
private val White = Color.White
private val Black = Color.Black

/** What every dark theme shares; the terminal and the red zone stay dark in all of them. */
private fun darkGlass(
    id: String,
    label: String,
    accent: Color,
    onAccent: Color,
    top: Color,
    bottom: Color,
    blobA: Color,
    blobB: Color,
    blobC: Color,
    tint: Color,
): WrtPalette {
    val text = lerp(White, tint, 0.12f)
    val solid = lerp(top, bottom, 0.5f)
    return WrtPalette(
        id = id, label = label, isLight = false,
        auroraTop = top, auroraBottom = bottom, blobA = blobA, blobB = blobB, blobC = blobC,
        bgScreen = Color.Transparent,
        bgSolid = solid,
        bgBar = lerp(bottom, Black, 0.35f).copy(alpha = 0.62f),
        bgDeep = Black.copy(alpha = 0.26f),
        bgCard = White.copy(alpha = 0.075f),
        bgCardDim = White.copy(alpha = 0.04f),
        bgSheet = lerp(bottom, White, 0.07f).copy(alpha = 0.96f),
        bgDialog = lerp(bottom, White, 0.09f).copy(alpha = 0.97f),
        bgCode = Black.copy(alpha = 0.38f),
        bgPendingBar = accent.copy(alpha = 0.14f),
        glassEdgeHi = White.copy(alpha = 0.42f),
        glassEdgeLo = White.copy(alpha = 0.06f),
        glassSheen = White.copy(alpha = 0.10f),
        scrim = Color(0xB8040706),
        borderHair = White.copy(alpha = 0.09f),
        borderCard = White.copy(alpha = 0.16f),
        borderInput = White.copy(alpha = 0.22f),
        borderIcon = White.copy(alpha = 0.18f),
        borderRow = White.copy(alpha = 0.07f),
        borderFaint = White.copy(alpha = 0.14f),
        textPrimary = text,
        textSecondary = lerp(text, bottom, 0.34f),
        textTertiary = lerp(text, bottom, 0.42f),
        textDim = lerp(text, bottom, 0.58f),
        textFaint = lerp(text, bottom, 0.74f),
        textLogToken = lerp(text, White, 0.4f),
        accent = accent, onAccent = onAccent,
        green = Color(0xFF46D97E), amber = Color(0xFFF2B24C), amberText = Color(0xFFE8D9BD),
        red = Color(0xFFF26D5E), blue = Color(0xFF5CA9F2),
        knobOff = lerp(text, bottom, 0.58f),
        trackOff = White.copy(alpha = 0.10f),
        trackOffBorder = White.copy(alpha = 0.18f),
        dotOff = White.copy(alpha = 0.22f),
        progressTrack = White.copy(alpha = 0.10f),
        sparkDim = White.copy(alpha = 0.12f),
        termBg = Color(0xFF000000), termBarBg = Color(0xFF050505), termBorder = Color(0xFF161616),
        termText = Color(0xFFD7E4DE), termTabActive = Color(0xFF141D1A), termTabBorder = Color(0xFF1E1E1E),
        termKeyBg = Color(0xFF141414), termKeyAltBg = Color(0xFF1D1D1D), termExtraKeyBg = Color(0xFF151515),
        termExtraKeyBorder = Color(0xFF242424), termKeyText = Color(0xFF9DB0A8),
        termExtraKeyText = Color(0xFFC3D2CC), termRowBg = Color(0xFF0A0A0A), termRowBorder = Color(0xFF1C1C1C),
        dangerBg = Color(0xFF150D0B), dangerCode = Color(0xFF100B0A), dangerCodeBg = Color(0xFF0A0706),
        dangerCodeBorder = Color(0xFF241512), dangerText = Color(0xFFF0E4E1), dangerBody = Color(0xFFC9ACA6),
        dangerDim = Color(0xFF8A716B), dangerMono = Color(0xFFB9A29C), dangerSub = Color(0xFF9B7A74),
        dangerOutlineText = Color(0xFFD9938A), dangerLoss = Color(0xFFD9B8B2),
        accentBody = lerp(accent, White, 0.6f),
        onRed = Color(0xFF2A0C08),
    )
}

private fun lightGlass(
    id: String,
    label: String,
    accent: Color,
    top: Color,
    bottom: Color,
    blobA: Color,
    blobB: Color,
    blobC: Color,
): WrtPalette {
    val solid = lerp(top, bottom, 0.5f)
    return WrtPalette(
        id = id, label = label, isLight = true,
        auroraTop = top, auroraBottom = bottom, blobA = blobA, blobB = blobB, blobC = blobC,
        bgScreen = Color.Transparent,
        bgSolid = solid,
        bgBar = White.copy(alpha = 0.62f),
        bgDeep = Ink.copy(alpha = 0.06f),
        bgCard = White.copy(alpha = 0.58f),
        bgCardDim = White.copy(alpha = 0.36f),
        bgSheet = lerp(White, top, 0.25f).copy(alpha = 0.97f),
        bgDialog = lerp(White, top, 0.15f).copy(alpha = 0.98f),
        bgCode = Ink.copy(alpha = 0.07f),
        bgPendingBar = accent.copy(alpha = 0.16f),
        glassEdgeHi = White.copy(alpha = 0.95f),
        glassEdgeLo = Ink.copy(alpha = 0.08f),
        glassSheen = White.copy(alpha = 0.35f),
        scrim = Color(0x660F1B2D),
        borderHair = Ink.copy(alpha = 0.08f),
        borderCard = Ink.copy(alpha = 0.12f),
        borderInput = Ink.copy(alpha = 0.20f),
        borderIcon = Ink.copy(alpha = 0.16f),
        borderRow = Ink.copy(alpha = 0.07f),
        borderFaint = Ink.copy(alpha = 0.12f),
        textPrimary = Color(0xFF0F1B2D),
        textSecondary = Color(0xFF3F4F63),
        textTertiary = Color(0xFF4C5C71),
        textDim = Color(0xFF6C7B8F),
        textFaint = Color(0xFF93A1B3),
        textLogToken = Color(0xFF0F1B2D),
        accent = accent, onAccent = White,
        green = Color(0xFF16A34A), amber = Color(0xFFB7791F), amberText = Color(0xFF7A4B07),
        red = Color(0xFFD93A2B), blue = Color(0xFF2563EB),
        knobOff = Color(0xFF6C7B8F),
        trackOff = Ink.copy(alpha = 0.10f),
        trackOffBorder = Ink.copy(alpha = 0.18f),
        dotOff = Ink.copy(alpha = 0.22f),
        progressTrack = Ink.copy(alpha = 0.10f),
        sparkDim = Ink.copy(alpha = 0.12f),
        termBg = Color(0xFF000000), termBarBg = Color(0xFF050505), termBorder = Color(0xFF161616),
        termText = Color(0xFFD7E4DE), termTabActive = Color(0xFF141D1A), termTabBorder = Color(0xFF1E1E1E),
        termKeyBg = Color(0xFF141414), termKeyAltBg = Color(0xFF1D1D1D), termExtraKeyBg = Color(0xFF151515),
        termExtraKeyBorder = Color(0xFF242424), termKeyText = Color(0xFF9DB0A8),
        termExtraKeyText = Color(0xFFC3D2CC), termRowBg = Color(0xFF0A0A0A), termRowBorder = Color(0xFF1C1C1C),
        dangerBg = Color(0xFFFCEFEC), dangerCode = Color(0xFFF6DDD8), dangerCodeBg = Color(0xFFF3D3CD),
        dangerCodeBorder = Color(0xFFE5B3AA), dangerText = Color(0xFF3A1511), dangerBody = Color(0xFF6B3A33),
        dangerDim = Color(0xFF946A63), dangerMono = Color(0xFF7A4F48), dangerSub = Color(0xFF8A5A53),
        dangerOutlineText = Color(0xFFB2392B), dangerLoss = Color(0xFF6B3A33),
        accentBody = lerp(accent, Ink, 0.45f),
        onRed = White,
    )
}

/** The themes the user can pick from. Every one of them is liquid glass; they differ in colour. */
object WrtThemes {
    /** The original teal, now over a deep green-black aurora. */
    val Midnight = darkGlass(
        id = "midnight", label = "Midnight", accent = Color(0xFF2EE5C8), onAccent = Color(0xFF06231D),
        top = Color(0xFF0B1B1A), bottom = Color(0xFF070D10),
        blobA = Color(0x662EE5C8), blobB = Color(0x552563EB), blobC = Color(0x3346D97E),
        tint = Color(0xFF2EE5C8),
    )

    /** Pale glass over a soft sky-to-lilac wash. */
    val Daylight = lightGlass(
        id = "daylight", label = "Daylight", accent = Color(0xFF0B8F83),
        top = Color(0xFFDDEBFA), bottom = Color(0xFFF1E6FA),
        blobA = Color(0x663BC4D9), blobB = Color(0x55A78BFA), blobC = Color(0x44F9A8D4),
    )

    val Ocean = darkGlass(
        id = "ocean", label = "Ocean", accent = Color(0xFF4DB8FF), onAccent = Color(0xFF021A2E),
        top = Color(0xFF06223F), bottom = Color(0xFF040B1C),
        blobA = Color(0x7700A3FF), blobB = Color(0x5500E5D0), blobC = Color(0x445B5BFF),
        tint = Color(0xFF4DB8FF),
    )

    val Violet = darkGlass(
        id = "violet", label = "Violet", accent = Color(0xFFB794FF), onAccent = Color(0xFF1E0B3D),
        top = Color(0xFF1E0F3D), bottom = Color(0xFF0B0718),
        blobA = Color(0x778B5CF6), blobB = Color(0x55EC4899), blobC = Color(0x443B82F6),
        tint = Color(0xFFB794FF),
    )

    val Sunset = darkGlass(
        id = "sunset", label = "Sunset", accent = Color(0xFFFF9A5C), onAccent = Color(0xFF2E1202),
        top = Color(0xFF3A1226), bottom = Color(0xFF140A12),
        blobA = Color(0x77FF6B35), blobB = Color(0x55FF3D81), blobC = Color(0x44FFC53D),
        tint = Color(0xFFFF9A5C),
    )

    val Emerald = darkGlass(
        id = "emerald", label = "Emerald", accent = Color(0xFF3DDC84), onAccent = Color(0xFF032612),
        top = Color(0xFF07281E), bottom = Color(0xFF040E0B),
        blobA = Color(0x7710B981), blobB = Color(0x5584CC16), blobC = Color(0x4406B6D4),
        tint = Color(0xFF3DDC84),
    )

    val all: List<WrtPalette> = listOf(Midnight, Daylight, Ocean, Violet, Sunset, Emerald)

    fun byId(id: String?): WrtPalette = all.firstOrNull { it.id == id } ?: Midnight
}
