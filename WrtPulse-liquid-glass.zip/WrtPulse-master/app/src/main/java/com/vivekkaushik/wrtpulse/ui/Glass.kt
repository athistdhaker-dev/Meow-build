package com.vivekkaushik.wrtpulse.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Shape
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp
import com.vivekkaushik.wrtpulse.ui.theme.Wrt

// "Liquid glass" building blocks.
//
// A glass surface is three things stacked: a translucent fill that lets the theme's aurora
// backdrop show through, a soft sheen that is brightest at the top edge (light catching the
// curve of the glass), and a rim that is bright at the top-left and fades towards the
// bottom-right (the specular edge). All three read their colours from [Wrt], so every theme gets
// the same material in its own colour.

/** The glass fill with its top-edge sheen, clipped to [shape]. */
fun Modifier.glassBg(shape: Shape, fill: Color = Wrt.BgCard): Modifier =
    this
        .background(fill, shape)
        .background(
            Brush.verticalGradient(listOf(Wrt.GlassSheen, Wrt.GlassSheen.copy(alpha = 0f))),
            shape,
        )

/** The specular rim: bright where the light hits, nearly gone on the far side. */
fun Modifier.glassBorder(shape: Shape, width: Dp = 1.dp): Modifier =
    this.border(
        width,
        Brush.linearGradient(listOf(Wrt.GlassEdgeHi, Wrt.GlassEdgeLo, Wrt.GlassEdgeHi.copy(alpha = Wrt.GlassEdgeHi.alpha * 0.35f))),
        shape,
    )

/** Fill, sheen and rim in one — the default card. */
fun Modifier.glassPanel(shape: Shape, fill: Color = Wrt.BgCard): Modifier =
    this.glassBorder(shape).glassBg(shape, fill)

/** A full-width bar (top bar, tab bar): translucent fill and a sheen, no corners. */
fun Modifier.glassBar(): Modifier =
    this
        .background(Wrt.BgBar)
        .background(Brush.verticalGradient(listOf(Wrt.GlassSheen, Wrt.GlassSheen.copy(alpha = 0f))))
