package com.vivekkaushik.wrtpulse.data

import com.vivekkaushik.wrtpulse.net.RouterSession
import com.vivekkaushik.wrtpulse.net.SshAuth
import com.vivekkaushik.wrtpulse.net.SshClient
import com.vivekkaushik.wrtpulse.net.SshConnection
import com.vivekkaushik.wrtpulse.net.SshTarget
import com.vivekkaushik.wrtpulse.ops.MeshOps
import com.vivekkaushik.wrtpulse.ops.Parsers
import com.vivekkaushik.wrtpulse.ops.WifiNetwork
import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class WifiStoreTest {

    private val unusedClient = object : SshClient {
        override suspend fun probeHostKey(target: SshTarget) = error("unused")
        override suspend fun connect(target: SshTarget, auth: SshAuth, connectTimeoutMs: Long): SshConnection =
            error("unused")
    }

    private fun store() = WifiStore(RouterSession(SshTarget("t"), unusedClient, { error("unused") }))

    @Test
    fun `uci show wireless parses radios and ap networks`() {
        val uci = Parsers.uciShow(
            """
            wireless.radio0=wifi-device
            wireless.radio0.type='mac80211'
            wireless.radio0.band='2g'
            wireless.radio0.channel='11'
            wireless.radio0.htmode='HE40'
            wireless.radio1=wifi-device
            wireless.radio1.band='5g'
            wireless.radio1.htmode='HE80'
            wireless.default_radio0=wifi-iface
            wireless.default_radio0.device='radio0'
            wireless.default_radio0.mode='ap'
            wireless.default_radio0.ssid='Casa'
            wireless.default_radio0.encryption='sae'
            wireless.default_radio0.key='tr0ub4dor&3'
            wireless.@wifi-iface[1]=wifi-iface
            wireless.@wifi-iface[1].device='radio1'
            wireless.@wifi-iface[1].ssid='Casa-Guest'
            wireless.@wifi-iface[1].encryption='psk2'
            wireless.@wifi-iface[1].key='guestpass'
            wireless.@wifi-iface[1].disabled='1'
            wireless.mesh0=wifi-iface
            wireless.mesh0.device='radio1'
            wireless.mesh0.mode='mesh'
            wireless.mesh0.ssid='mesh-net'
            """.trimIndent()
        )
        val (radios, networks) = Parsers.wireless(uci)
        assertEquals(2, radios.size)
        val r0 = radios.first { it.section == "radio0" }
        assertEquals("2.4G", r0.band)
        assertEquals("11", r0.channel)
        assertEquals("HE40", r0.htmode)

        // The mesh point is kept now, as the backhaul row the Mesh page manages; its id is
        // where an AP's SSID would be.
        assertEquals(3, networks.size)
        val mesh = networks.first { it.section == "mesh0" }
        assertTrue(mesh.isMesh)
        val guest = networks.first { it.ssid == "Casa-Guest" }
        assertEquals("@wifi-iface[1]", guest.section)
        assertTrue(guest.disabled)
        assertEquals("psk2", guest.encryption)
    }

    @Test
    fun `fast roaming on a draft writes the hand-off options with hostapd's mobility domain`() {
        val s = store()
        s.radios.add(com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "5G", "36", "VHT80", disabled = false))
        s.addDraft(listOf("radio0"), "ap", "Casa", "psk2", "hunter22", ft = true)
        val ops = s.ops()
        assertTrue(ops.any { it.endsWith(".ieee80211r='1'") })
        assertTrue(ops.any { it.endsWith(".mobility_domain='1113'") })
        assertTrue(ops.any { it.endsWith(".ft_psk_generate_local='1'") })
        assertTrue(ops.any { it.endsWith(".bss_transition='1'") })
        // An open network cannot carry it, whatever the toggle said.
        val open = store()
        open.addDraft(listOf("radio0"), "ap", "Open", "none", "", ft = true)
        assertTrue(open.ops().none { it.contains("ieee80211r") })
    }

    @Test
    fun `fast roaming on a saved ap is six sets, and off is six deletes`() {
        val s = store()
        val net = WifiNetwork("home", "radio0", "Casa", "psk2", "hunter22", disabled = false, network = "lan")
        s.networks.add(net)
        s.stageFastTransition(net, on = true)
        assertEquals(6, s.ops().size)
        assertTrue(s.ops().contains("set wireless.home.mobility_domain='1113'"))
        s.revert()
        val on = net.copy(ieee80211r = true, mobilityDomain = "1113")
        s.networks.clear(); s.networks.add(on)
        s.stageFastTransition(on, on = false)
        assertTrue(s.ops().contains("delete wireless.home.ieee80211r"))
        assertTrue(s.ops().contains("delete wireless.home.mobility_domain"))
        assertTrue(s.ops().contains("delete wireless.home.bss_transition"))
        assertTrue(s.ops().none { it.startsWith("set ") })
    }

    /** What the nodes are told before this router changes: staged edits and drafts, minus deletions. */
    @Test
    fun `effective radios and networks are the config after apply`() {
        val s = store()
        s.radios.add(com.vivekkaushik.wrtpulse.ops.WifiRadio("radio1", "5G", "149", "VHT80", disabled = false, country = "IN"))
        val home = WifiNetwork("home", "radio1", "Casa", "psk2", "hunter22", disabled = false, network = "lan")
        val old = WifiNetwork("old", "radio1", "Legacy", "psk2", "hunter22", disabled = false, network = "lan")
        s.networks.addAll(listOf(home, old))
        s.stage("radio1", "channel", "149", "36")
        s.stage("home", "ssid", "Casa", "Casa2")
        s.stageDelete("old")
        s.addDraft(listOf("radio1"), "ap", "Casa-Work", "sae", "workpass1", ft = true)
        assertEquals("36", s.effectiveRadios().single().channel)
        val nets = s.effectiveNetworks()
        assertEquals(listOf("Casa2", "Casa-Work"), nets.map { it.ssid })
        assertTrue(nets.last().ieee80211r)
        assertEquals(com.vivekkaushik.wrtpulse.ops.MeshOps.mobilityDomain("Casa-Work"), nets.last().mobilityDomain)
    }

    /** The mesh point's empty SSID once blocked every apply on a primary. */
    @Test
    fun `a mesh point is not a network without a name`() {
        val s = store()
        s.networks.add(WifiNetwork("wrtpulse_mesh", "radio1", "", "sae", "meshkey-meshkey", disabled = false, mode = "mesh", network = "lan", meshId = "x-mesh"))
        assertTrue(s.problems().isEmpty())
    }

    @Test
    fun `staging the saved value back un-stages it`() {
        val s = store()
        s.stage("default_radio0", "ssid", "Casa", "Cabana")
        assertEquals(1, s.pendingCount)
        s.stage("default_radio0", "ssid", "Casa", "Casa")
        assertEquals(0, s.pendingCount)
    }

    @Test
    fun `ops are uci set commands with quoting`() {
        val s = store()
        s.stage("default_radio0", "key", "old", "it's a secret")
        s.stage("radio0", "channel", "6", "11")
        assertEquals(
            listOf(
                "set wireless.default_radio0.key='it'\\''s a secret'",
                "set wireless.radio0.channel='11'",
            ),
            s.ops(),
        )
    }

    @Test
    fun `diff masks password values`() {
        val s = store()
        s.stage("default_radio0", "key", "hunter22", "correcthorse")
        val lines = s.diffLines().map { it.first }
        assertEquals("- default_radio0.key='••••••••'", lines[0])
        assertTrue(lines[1].startsWith("+ default_radio0.key='c"))
        assertFalse(lines[1].contains("correcthorse"))
    }

    @Test
    fun `value returns staged over saved`() {
        val s = store()
        assertEquals("Casa", s.value("x", "ssid", "Casa"))
        s.stage("x", "ssid", "Casa", "Cabana")
        assertEquals("Cabana", s.value("x", "ssid", "Casa"))
        s.revert()
        assertEquals("Casa", s.value("x", "ssid", "Casa"))
        assertEquals(0, s.pendingCount)
    }

    // ---- editing networks ----

    /**
     * Switching a network to open has to remove the key, not blank it: an empty
     * `option key ''` line keeps the old value visible in config history and reads as
     * "there is a password" to anything parsing the file.
     */
    @Test
    fun `clearing a key deletes the option instead of setting it empty`() {
        val s = store()
        s.stage("default_radio0", "encryption", "psk2", "none")
        s.stage("default_radio0", "key", "hunter22", "")
        assertTrue(s.ops().contains("delete wireless.default_radio0.key"))
        assertFalse(s.ops().any { it.startsWith("set wireless.default_radio0.key") })
        // The diff shows the removal as a deletion, with no replacement line.
        val lines = s.diffLines().map { it.first }
        assertTrue(lines.contains("- default_radio0.key='••••••••'"))
        assertFalse(lines.any { it.startsWith("+ default_radio0.key") })
    }

    @Test
    fun `changedIn reports only the section that was touched`() {
        val s = store()
        s.stage("default_radio0", "ssid", "Casa", "Cabana")
        assertTrue(s.changedIn("default_radio0"))
        assertFalse(s.changedIn("default_radio1"))
        // Prefix match must not spill: radio0 and radio0_guest are different sections.
        assertFalse(s.changedIn("default_radio"))
    }

    @Test
    fun `hidden is read back from uci`() {
        val uci = Parsers.uciShow(
            """
            wireless.quiet=wifi-iface
            wireless.quiet.device='radio0'
            wireless.quiet.ssid='Quiet'
            wireless.quiet.hidden='1'
            """.trimIndent()
        )
        val (_, networks) = Parsers.wireless(uci)
        assertTrue(networks.single().hidden)
    }

    @Test
    fun `a too-short passphrase is reported and an open network is not`() {
        val s = store()
        s.networks.add(
            com.vivekkaushik.wrtpulse.ops.WifiNetwork(
                section = "default_radio0", device = "radio0", ssid = "Casa",
                encryption = "psk2", key = "hunter22", disabled = false,
            )
        )
        assertTrue(s.problems().isEmpty())

        s.stage("default_radio0", "key", "hunter22", "abc")
        assertEquals(1, s.problems().size)
        assertTrue(s.problems().single().startsWith("Casa: a WPA password"))

        // Going open drops the requirement along with the key.
        s.stage("default_radio0", "encryption", "psk2", "none")
        s.stage("default_radio0", "key", "hunter22", "")
        assertTrue(s.problems().isEmpty())
    }

    @Test
    fun `a blank ssid is reported`() {
        val s = store()
        s.networks.add(
            com.vivekkaushik.wrtpulse.ops.WifiNetwork(
                section = "default_radio0", device = "radio0", ssid = "Casa",
                encryption = "none", key = "", disabled = false,
            )
        )
        s.stage("default_radio0", "ssid", "Casa", "   ")
        assertEquals(1, s.problems().size)
        assertTrue(s.problems().single().contains("needs a name"))
    }

    // ---- creating networks ----

    @Test
    fun `an access point draft writes one named section`() {
        val s = store()
        s.addDraft(devices = listOf("radio0"), mode = "ap", ssid = "Guest", encryption = "psk2", key = "hunter22")
        assertEquals(
            listOf(
                "set wireless.wrtpulse_guest=wifi-iface",
                "set wireless.wrtpulse_guest.device='radio0'",
                "set wireless.wrtpulse_guest.mode='ap'",
                "set wireless.wrtpulse_guest.ssid='Guest'",
                "set wireless.wrtpulse_guest.encryption='psk2'",
                "set wireless.wrtpulse_guest.key='hunter22'",
                "set wireless.wrtpulse_guest.network='lan'",
            ),
            s.ops(),
        )
        // An AP is bridged to a network that already exists — nothing else to configure.
        assertTrue(s.networkOps().isEmpty())
        assertTrue(s.firewallLines().isEmpty())
        assertEquals(1, s.pendingCount)
    }

    /**
     * Two additions in one batch is exactly where `@wifi-iface[-1]` stops being usable:
     * both would answer to it. Named sections keep them apart.
     */
    @Test
    fun `two drafts in one batch address different sections`() {
        val s = store()
        s.addDraft(listOf("radio0"), "ap", "Guest", "psk2", "hunter22")
        s.addDraft(listOf("radio1"), "ap", "Guest", "psk2", "hunter22")
        val created = s.ops().filter { it.endsWith("=wifi-iface") }
        assertEquals(
            listOf("set wireless.wrtpulse_guest=wifi-iface", "set wireless.wrtpulse_guest_2=wifi-iface"),
            created,
        )
    }

    @Test
    fun `a section name is derived from the ssid and stripped to uci characters`() {
        assertEquals("wrtpulse_casa_guest", WifiStore.sectionBase("Casa Guest!", "ap"))
        assertEquals("wrtpulse_ap", WifiStore.sectionBase("  ", "ap"))     // nothing usable left
        assertEquals("wrtpulse_caf", WifiStore.sectionBase("Café", "sta")) // non-ascii dropped
        assertEquals("wrtpulse_test", WifiStore.sectionBase("WrtPulse-Test", "ap")) // no double prefix
        assertEquals("a_2", WifiStore.free("a", setOf("a")))
        assertEquals("a_3", WifiStore.free("a", setOf("a", "a_2")))
    }

    @Test
    fun `an open draft carries no key option`() {
        val s = store()
        s.addDraft(listOf("radio0"), "ap", "Lobby", "none", "")
        assertFalse(s.ops().any { it.contains(".key=") })
        assertTrue(s.ops().contains("set wireless.wrtpulse_lobby.encryption='none'"))
    }

    @Test
    fun `a hidden draft sets hidden, and a client never does`() {
        val ap = store().apply { addDraft(listOf("radio0"), "ap", "Quiet", "psk2", "hunter22", hidden = true) }
        assertTrue(ap.ops().contains("set wireless.wrtpulse_quiet.hidden='1'"))
        val sta = store().apply { addDraft(listOf("radio0"), "sta", "Upstream", "psk2", "hunter22") }
        assertFalse(sta.ops().any { it.contains(".hidden=") })
    }

    /**
     * A station with no network behind it associates and then sits there with no address,
     * and one outside the wan zone gives the LAN no way out — so both must ride along.
     */
    @Test
    fun `a client draft also brings up wwan and joins the wan zone`() {
        val s = store()
        s.addDraft(listOf("radio0"), "sta", "Cafe WiFi", "psk2", "hunter22")
        assertTrue(s.ops().contains("set wireless.wrtpulse_cafe_wifi.mode='sta'"))
        assertTrue(s.ops().contains("set wireless.wrtpulse_cafe_wifi.network='wwan'"))
        assertEquals(
            listOf("set network.wwan=interface", "set network.wwan.proto='dhcp'"),
            s.networkOps(),
        )
        assertEquals(1, s.firewallLines().size)
        assertTrue(s.commitLine().contains("uci commit wireless && uci commit network"))
    }

    /**
     * This router already has a `wwan` uplink. Reusing that name would rewrite the interface
     * the router is currently reaching the internet through.
     */
    @Test
    fun `a client never reuses an interface name the router already has`() {
        val s = store()
        s.interfaces.addAll(listOf("lan", "wan", "wwan"))
        s.addDraft(listOf("radio0"), "sta", "Cafe WiFi", "psk2", "hunter22")
        assertTrue(s.ops().contains("set wireless.wrtpulse_cafe_wifi.network='wwan_2'"))
        assertEquals(
            listOf("set network.wwan_2=interface", "set network.wwan_2.proto='dhcp'"),
            s.networkOps(),
        )
        assertEquals(listOf("+ firewall.@zone[wan].network += 'wwan_2'"), s.firewallLines())
    }

    @Test
    fun `drafts show in the diff with the password masked, and can be dropped`() {
        val s = store()
        val draft = s.addDraft(listOf("radio1"), "ap", "Guest", "sae", "correcthorse")
        val lines = s.diffLines().map { it.first }
        assertTrue(lines.contains("+ wrtpulse_guest=wifi-iface"))
        assertTrue(lines.contains("+ wrtpulse_guest.ssid='Guest'"))
        assertFalse(lines.any { it.contains("correcthorse") })
        assertTrue(lines.any { it.startsWith("+ wrtpulse_guest.key='c") })

        s.removeDraft(draft.id)
        assertEquals(0, s.pendingCount)
        assertTrue(s.ops().isEmpty())
    }

    @Test
    fun `reverting drops drafts along with edits`() {
        val s = store()
        s.stage("radio0", "channel", "6", "11")
        s.addDraft(listOf("radio0"), "ap", "Guest", "psk2", "hunter22")
        assertEquals(2, s.pendingCount)
        s.revert()
        assertEquals(0, s.pendingCount)
    }

    @Test
    fun `a draft quotes like any other value`() {
        val s = store()
        s.addDraft(listOf("radio0"), "ap", "it's mine", "psk2", "hunter22")
        assertTrue(s.ops().contains("set wireless.wrtpulse_it_s_mine.ssid='it'\\''s mine'"))
    }

    @Test
    fun `client wifi-iface sections are read back from uci`() {
        val uci = Parsers.uciShow(
            """
            wireless.radio0=wifi-device
            wireless.radio0.band='2g'
            wireless.wwan=wifi-iface
            wireless.wwan.device='radio0'
            wireless.wwan.mode='sta'
            wireless.wwan.ssid='Cafe WiFi'
            wireless.wwan.encryption='psk2'
            wireless.wwan.network='wwan'
            """.trimIndent()
        )
        val (_, networks) = Parsers.wireless(uci)
        assertEquals(1, networks.size)
        assertTrue(networks[0].isClient)
        assertEquals("wwan", networks[0].network)
        assertEquals("Cafe WiFi", networks[0].ssid)
    }

    @Test
    fun `encryption labels`() {
        assertEquals("WPA3-SAE", Parsers.encryptionLabel("sae"))
        assertEquals("WPA2/3", Parsers.encryptionLabel("sae-mixed"))
        assertEquals("WPA2-PSK", Parsers.encryptionLabel("psk2+ccmp"))
        assertEquals("OPEN", Parsers.encryptionLabel("none"))
    }

    // ---- anonymous sections: the batch run the way uci runs it ----
    //
    // A wifi-iface LuCI adds is `@wifi-iface[i]`. The index counts the named interfaces too, and
    // uci resolves it command by command, so every delete renumbers the interfaces after it.
    // These run ops() through FakeUci against a config read from its own `uci show`.

    @Test
    fun `deleting interfaces takes exactly those, and edits above them land on their own`() {
        val (s, uci) = used()
        s.stageDelete("@wifi-iface[2]") // Casa-IoT
        s.stageDelete("@wifi-iface[5]") // Casa-Old
        s.stageDelete("guest_5g") // named, but it sits between them and counts
        s.stage("@wifi-iface[4]", "key", "upstream-key", "new-upstream-key") // between the two
        s.stageFastTransition(s.networks.single { it.ssid == "Casa-Work" }, on = false) // @wifi-iface[6], above all
        s.stage("radio1", "channel", "36", "149")
        s.addDraft(listOf("radio0"), "ap", "Casa-Lab", "psk2", "lab-password")
        val ops = s.ops()
        assertEquals(
            listOf(
                "set wireless.@wifi-iface[4].key='new-upstream-key'",
                "delete wireless.@wifi-iface[6].bss_transition",
                "delete wireless.@wifi-iface[6].ft_over_ds",
                "delete wireless.@wifi-iface[6].ft_psk_generate_local",
                "delete wireless.@wifi-iface[6].ieee80211k",
                "delete wireless.@wifi-iface[6].ieee80211r",
                "delete wireless.@wifi-iface[6].mobility_domain",
                "set wireless.radio1.channel='149'",
                "delete wireless.@wifi-iface[5]",
                "delete wireless.@wifi-iface[2]",
                "delete wireless.guest_5g",
                "set wireless.wrtpulse_casa_lab=wifi-iface",
                "set wireless.wrtpulse_casa_lab.device='radio0'",
                "set wireless.wrtpulse_casa_lab.mode='ap'",
                "set wireless.wrtpulse_casa_lab.ssid='Casa-Lab'",
                "set wireless.wrtpulse_casa_lab.encryption='psk2'",
                "set wireless.wrtpulse_casa_lab.key='lab-password'",
                "set wireless.wrtpulse_casa_lab.network='lan'",
            ),
            ops,
        )
        uci.run(ops).assertLeaves(
            usedWireless,
            deleted = setOf("iot", "old", "guest"),
            edited = mapOf(
                "radio1" to mapOf("channel" to "149"),
                "uplink" to mapOf("key" to "new-upstream-key"),
                "work" to WifiStore.FT_OPTIONS.associateWith { null },
            ),
            added = listOf(
                iface(
                    "wrtpulse_casa_lab", "wrtpulse_casa_lab",
                    "device" to "radio0", "mode" to "ap", "ssid" to "Casa-Lab", "encryption" to "psk2",
                    "key" to "lab-password", "network" to "lan",
                ),
            ),
        )
        // The review lists the same changes in the same order: paths without the package, keys masked.
        assertEquals(
            batchChanges(ops).map { (path, values) ->
                path.removePrefix("wireless.") to if (path.endsWith(".key")) values.map(WifiStore::mask) else values
            },
            reviewChanges(s.diffLines()),
        )
    }

    /** An option the batch removes is shown going, not as a `+` line setting it to nothing. */
    @Test
    fun `auto tx power and fast roaming off read as removals in the review`() {
        val s = store()
        s.stage("radio0", "txpower", "20", "")
        val work = WifiNetwork(
            "work", "radio0", "Casa-Work", "sae", "work-password", disabled = false, network = "lan",
            ieee80211r = true, mobilityDomain = MeshOps.mobilityDomain("Casa-Work"),
        )
        s.networks.add(work)
        s.stageFastTransition(work, on = false)
        assertTrue(s.ops().none { it.startsWith("set ") })
        assertTrue(s.diffLines().none { it.second })
        assertEquals(
            batchChanges(s.ops()).map { (path, values) -> path.removePrefix("wireless.") to values },
            reviewChanges(s.diffLines()),
        )
    }

    private fun iface(id: String, section: String?, vararg options: Pair<String, String>) =
        FakeUci.Section(id, "wifi-iface", section, mapOf(*options))

    /** Two radios and seven interfaces: the stock one, LuCI's anonymous ones, and a guest AP named by hand. */
    private val usedWireless = listOf(
        FakeUci.Section("radio0", "wifi-device", "radio0", mapOf("type" to "mac80211", "band" to "2g", "channel" to "6", "htmode" to "HE20")),
        FakeUci.Section("radio1", "wifi-device", "radio1", mapOf("type" to "mac80211", "band" to "5g", "channel" to "36", "htmode" to "HE80")),
        // default_radio0 at 0, @wifi-iface[1] and [2], guest_5g at 3, then @wifi-iface[4] to [6]
        iface("casa2", "default_radio0", "device" to "radio0", "mode" to "ap", "ssid" to "Casa", "encryption" to "sae", "key" to "tr0ub4dor&3", "network" to "lan"),
        iface("casa5", null, "device" to "radio1", "mode" to "ap", "ssid" to "Casa", "encryption" to "sae", "key" to "tr0ub4dor&3", "network" to "lan"),
        iface("iot", null, "device" to "radio0", "mode" to "ap", "ssid" to "Casa-IoT", "encryption" to "psk2", "key" to "iot-devices", "network" to "iot"),
        iface("guest", "guest_5g", "device" to "radio1", "mode" to "ap", "ssid" to "Casa-Guest", "encryption" to "psk2", "key" to "welcome-in", "network" to "guest", "isolate" to "1"),
        iface("uplink", null, "device" to "radio1", "mode" to "sta", "ssid" to "Upstream", "encryption" to "psk2", "key" to "upstream-key", "network" to "wwan"),
        iface("old", null, "device" to "radio0", "mode" to "ap", "ssid" to "Casa-Old", "encryption" to "psk2", "key" to "old-password", "network" to "lan", "disabled" to "1"),
        iface(
            "work", null,
            "device" to "radio1", "mode" to "ap", "ssid" to "Casa-Work", "encryption" to "sae", "key" to "work-password", "network" to "lan",
            *MeshOps.roamingOptions("Casa-Work", "sae").toTypedArray(),
        ),
    )

    /** A store holding [usedWireless] as load() reads it, and the uci its batch will run against. */
    private fun used(): Pair<WifiStore, FakeUci> {
        val uci = FakeUci("wireless", usedWireless)
        val (radios, networks) = Parsers.wireless(Parsers.uciShow(uci.show()))
        return store().apply { this.radios.addAll(radios); this.networks.addAll(networks) } to uci
    }
}

class ScanCommandTest {

    /**
     * A band with no SSID has no netdev, so iwinfo has nothing to scan through. The temp
     * interface must be removed whether or not the scan itself worked.
     */
    @org.junit.Test
    fun `temporary scan interface is created and always torn down`() {
        val cmd = com.vivekkaushik.wrtpulse.ops.Commands.scanViaTempInterface("phy0")
        org.junit.Assert.assertTrue(cmd.contains("iw phy phy0 interface add wrtpulse-scan type managed"))
        org.junit.Assert.assertTrue(cmd.contains("ip link set wrtpulse-scan up"))
        org.junit.Assert.assertTrue(cmd.contains("wrt_scan wrtpulse-scan"))
        // Deleted before creating (stale leftovers), when it cannot come up, and after
        // scanning, so nothing persists whichever way it went.
        org.junit.Assert.assertEquals(3, Regex("iw dev wrtpulse-scan del").findAll(cmd).count())
        // Output is captured first so the teardown cannot swallow the results.
        org.junit.Assert.assertTrue(cmd.indexOf("R=\$(wrt_scan") < cmd.lastIndexOf("iw dev wrtpulse-scan del"))
        org.junit.Assert.assertTrue(cmd.trimEnd().endsWith("echo \"\$R\""))
        org.junit.Assert.assertTrue(!cmd.contains("uci"))   // nothing persistent is written
    }
}

class TxPowerStagingTest {
    private val unusedClient = object : com.vivekkaushik.wrtpulse.net.SshClient {
        override suspend fun probeHostKey(target: com.vivekkaushik.wrtpulse.net.SshTarget) = error("unused")
        override suspend fun connect(target: com.vivekkaushik.wrtpulse.net.SshTarget, auth: com.vivekkaushik.wrtpulse.net.SshAuth, connectTimeoutMs: Long): com.vivekkaushik.wrtpulse.net.SshConnection = error("unused")
    }
    private fun store() = WifiStore(com.vivekkaushik.wrtpulse.net.RouterSession(com.vivekkaushik.wrtpulse.net.SshTarget("t"), unusedClient, { error("unused") }))

    /** Beamforming is one switch over four (seven on ax) options; "on" is their absence. */
    @org.junit.Test
    fun `beamforming toggles every switch and on means unset`() {
        val s = store()
        val ac = com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "5G", "149", "VHT80", false)
        org.junit.Assert.assertTrue(s.beamforming(ac))
        s.setBeamforming(ac, false)
        org.junit.Assert.assertFalse(s.beamforming(ac))
        org.junit.Assert.assertEquals(
            listOf("set wireless.radio0.mu_beamformee='0'", "set wireless.radio0.mu_beamformer='0'",
                "set wireless.radio0.su_beamformee='0'", "set wireless.radio0.su_beamformer='0'"),
            s.ops(),
        )
        s.setBeamforming(ac, true)
        org.junit.Assert.assertEquals(emptyList<String>(), s.ops())   // back to saved = unset

        // Saved as explicitly on: turning it on again removes the options, not sets "1".
        val explicit = ac.copy(beamform = mapOf("su_beamformer" to "1", "mu_beamformer" to "0"))
        org.junit.Assert.assertFalse(s.beamforming(explicit))
        s.setBeamforming(explicit, true)
        org.junit.Assert.assertEquals(
            listOf("delete wireless.radio0.mu_beamformer", "delete wireless.radio0.su_beamformer"),
            s.ops(),
        )
        // An ax radio carries the HE switches too.
        val ax = ac.copy(htmode = "HE80")
        org.junit.Assert.assertEquals(7, s.beamformOptions(ax).size)
    }

    /** "Auto" is the absence of the option, so choosing it after a fixed value deletes it. */
    @org.junit.Test
    fun `auto tx power deletes the option rather than setting it empty`() {
        val s = store()
        s.stage("radio0", "txpower", "26", "")
        org.junit.Assert.assertEquals(listOf("delete wireless.radio0.txpower"), s.ops())
        s.stage("radio0", "txpower", "", "20")
        org.junit.Assert.assertEquals(listOf("set wireless.radio0.txpower='20'"), s.ops())
    }
}

class SurveyHonestyTest {
    private fun cell(ch: Int, bssid: String = "AA:BB:CC:DD:EE:0$ch") =
        com.vivekkaushik.wrtpulse.ops.ScanCell(ch, -60, "n$ch", bssid)

    /** Our own AP can appear in a scan; it is not a neighbour and must not score its channel. */
    @org.junit.Test
    fun `own access points are dropped from a scan`() {
        val cells = listOf(cell(40), cell(40, "A8:6E:84:93:80:37"), cell(149))
        val heard = WifiStore.withoutOwn(cells, setOf("A8:6E:84:93:80:37"))
        org.junit.Assert.assertEquals(listOf(cell(40), cell(149)), heard)
    }

    /**
     * A scan that heard only the AP's own channel is flagged, not trusted: on the reference
     * router the driver never left the channel while the AP was up, and the old advisor rated
     * the band on that one channel's neighbours.
     */
    @org.junit.Test
    fun `hearing only the own channel marks the survey partial`() {
        org.junit.Assert.assertTrue(WifiStore.onlyOwnChannel(listOf(cell(40), cell(40)), 40))
        org.junit.Assert.assertFalse(WifiStore.onlyOwnChannel(listOf(cell(40), cell(149)), 40))
        org.junit.Assert.assertFalse(WifiStore.onlyOwnChannel(emptyList(), 40))
        // No live channel to compare with (radio off, temp-interface scan): nothing to flag.
        org.junit.Assert.assertFalse(WifiStore.onlyOwnChannel(listOf(cell(40)), null))
    }

    @org.junit.Test
    fun `radios are mapped to the phy the driver names`() {
        val phys = com.vivekkaushik.wrtpulse.ops.Parsers.phyNames("radio0 phy1\nradio1 phy0\nradio2 \n")
        org.junit.Assert.assertEquals(mapOf("radio0" to "phy1", "radio1" to "phy0"), phys)
    }

    /** The radio-off survey must outlive the SSH session that started it. */
    @org.junit.Test
    fun `radio-off survey is detached and brings the radio back`() {
        val cmd = com.vivekkaushik.wrtpulse.ops.Commands.surveyWithRadioDown("radio0", "phy0")
        org.junit.Assert.assertTrue(cmd.contains("setsid sh -c '"))
        org.junit.Assert.assertTrue(cmd.contains("wifi down radio0; "))
        org.junit.Assert.assertTrue(cmd.contains("iw phy phy0 interface add wrtpulse-scan type managed"))
        org.junit.Assert.assertTrue(cmd.contains("wrt_scan wrtpulse-scan > /tmp/wrtpulse-survey-radio0.part"))
        // The scan function rides inside the detached job, so it is defined inside the quotes.
        org.junit.Assert.assertTrue(cmd.contains("setsid sh -c 'wrt_scan() {"))
        org.junit.Assert.assertTrue(cmd.indexOf("wifi up radio0") > cmd.indexOf("wifi down radio0"))
        // The file only appears, with its marker, once the radio is back up.
        org.junit.Assert.assertTrue(cmd.contains("wifi up radio0; echo \"___wrt___ done\" >> /tmp/wrtpulse-survey-radio0.part; mv"))
        org.junit.Assert.assertEquals("cat /tmp/wrtpulse-survey-radio0 2>/dev/null", com.vivekkaushik.wrtpulse.ops.Commands.readSurvey("radio0"))
    }

    /**
     * iwinfo gives up waiting for the scan-complete event after ~5 s, and an ath10k scan with
     * the AP up takes 5–7 s: on the reference router's 5 GHz radio it failed 3 times in 4 with
     * "No event received" while the kernel held the finished results. `iw` waits properly.
     */
    @org.junit.Test
    fun `a scan triggers with iw, falls back to the kernel's cache, and only then to iwinfo`() {
        val cmd = com.vivekkaushik.wrtpulse.ops.Commands.scan("phy0-ap0")
        val trigger = cmd.indexOf("iw dev \"\$1\" scan 2>&1")
        val dump = cmd.indexOf("iw dev \"\$1\" scan dump")
        val legacy = cmd.indexOf("iwinfo \"\$1\" scan")
        org.junit.Assert.assertTrue(trigger in 0 until dump && dump < legacy)
        org.junit.Assert.assertTrue(cmd.contains("for i in 1 2 3; do R=\$(iwinfo \"\$1\" scan 2>&1) && break; sleep 2; done"))
        org.junit.Assert.assertTrue(cmd.trimEnd().endsWith("wrt_scan phy0-ap0"))
        // The radio-off survey wraps it in sh -c '…', so it must not contain a single quote.
        org.junit.Assert.assertFalse(com.vivekkaushik.wrtpulse.ops.Commands.SCAN_FN.contains("'"))
    }

    /** ath10k refuses a station beside a live AP; the interface must not be left behind. */
    @org.junit.Test
    fun `a temporary scan interface that cannot come up is removed and reported`() {
        val cmd = com.vivekkaushik.wrtpulse.ops.Commands.scanViaTempInterface("phy0")
        org.junit.Assert.assertTrue(
            cmd.contains("ip link set wrtpulse-scan up >/dev/null 2>&1 || { iw dev wrtpulse-scan del >/dev/null 2>&1; echo 'ERR up'; exit 1; }")
        )
        org.junit.Assert.assertTrue(cmd.contains("R=\$(wrt_scan wrtpulse-scan); iw dev wrtpulse-scan del"))
        org.junit.Assert.assertTrue(cmd.indexOf("wrt_scan() {") < cmd.indexOf("iw phy phy0 interface add"))
    }
}

class ScanParserTest {
    @org.junit.Test
    fun `iwinfo scan cells parse`() {
        val cells = com.vivekkaushik.wrtpulse.ops.Parsers.scanCells(
            """
            Cell 01 - Address: AA:BB:CC:DD:EE:01
                      ESSID: "neighbor-one"
                      Mode: Master  Channel: 6
                      Signal: -72 dBm  Quality: 38/70
                      Encryption: WPA2 PSK (CCMP)
            Cell 02 - Address: AA:BB:CC:DD:EE:02
                      ESSID: unknown
                      Mode: Master  Channel: 11
                      Signal: -85 dBm  Quality: 15/70
                      Encryption: none
            """.trimIndent()
        )
        org.junit.Assert.assertEquals(2, cells.size)
        org.junit.Assert.assertEquals(6, cells[0].channel)
        org.junit.Assert.assertEquals(-72, cells[0].signalDbm)
        org.junit.Assert.assertEquals("neighbor-one", cells[0].ssid)
        org.junit.Assert.assertEquals(11, cells[1].channel)
        // No operation block: a plain 20 MHz cell centred on its own channel.
        org.junit.Assert.assertEquals(20, cells[0].widthMhz)
        org.junit.Assert.assertEquals(6, cells[0].centerChannel)
    }

    /** As a Deco M4R prints its 5 GHz neighbours: HT and VHT operation blocks after the basics. */
    @org.junit.Test
    fun `scan cells carry the neighbour's real width and centre`() {
        val cells = com.vivekkaushik.wrtpulse.ops.Parsers.scanCells(
            """
            Cell 01 - Address: A8:6E:84:93:7F:6F
                      ESSID: "VivekWifi"
                      Mode: Master  Frequency: 5.200 GHz  Band: 5 GHz  Channel: 40
                      Signal: -14 dBm  Quality: 70/70
                      Encryption: WPA PSK / FT PSK (CCMP)
                      HT Operation:
                                Primary Channel: 40
                                Secondary Channel Offset: below
                                Channel Width: 40 MHz or higher
                      VHT Operation:
                                Center Frequency 1: 42
                                Center Frequency 2: 0
                                Channel Width: 80 MHz
            Cell 02 - Address: AA:BB:CC:DD:EE:02
                      ESSID: "ht40-only"
                      Mode: Master  Frequency: 2.437 GHz  Band: 2.4 GHz  Channel: 6
                      Signal: -70 dBm  Quality: 40/70
                      Encryption: none
                      HT Operation:
                                Primary Channel: 6
                                Secondary Channel Offset: above
                                Channel Width: 40 MHz or higher
            """.trimIndent()
        )
        org.junit.Assert.assertEquals(40, cells[0].channel)
        org.junit.Assert.assertEquals(80, cells[0].widthMhz)
        org.junit.Assert.assertEquals(42, cells[0].centerChannel)
        org.junit.Assert.assertEquals(-14, cells[0].signalDbm)
        org.junit.Assert.assertEquals(40, cells[1].widthMhz)
        org.junit.Assert.assertEquals(8, cells[1].centerChannel)   // HT40+, two channels up
    }

    /** `iw dev phy0-ap0 scan dump` as the Deco M4R printed it — a named 80 MHz cell and a hidden one. */
    @org.junit.Test
    fun `iw scan blocks parse, hidden networks included`() {
        val cells = com.vivekkaushik.wrtpulse.ops.Parsers.scanCells(
            """
            BSS b4:f9:49:97:c2:58(on phy0-ap0)
            	last seen: 3680.454s [boottime]
            	freq: 5260.0
            	capability: ESS (0x0111)
            	signal: -51.00 dBm
            	SSID: jogi1
            	BSS Load:
            		 * station count: 0
            		 * channel utilisation: 0/255
            	HT operation:
            		 * primary channel: 52
            		 * secondary channel offset: above
            		 * STA channel width: any
            	VHT operation:
            		 * channel width: 1 (80 MHz)
            		 * center freq segment 1: 58
            		 * center freq segment 2: 0
            	WPA:	 * Version: 1
            		 * Pairwise ciphers: TKIP CCMP
            		 * Authentication suites: PSK
            	RSN:	 * Version: 1
            		 * Authentication suites: PSK
            BSS ae:37:28:c8:c2:bd(on phy0-ap0)
            	freq: 5805.0
            	capability: ESS (0x1911)
            	signal: -70.00 dBm
            	RSN:	 * Version: 1
            		 * Authentication suites: PSK
            	HT operation:
            		 * primary channel: 161
            		 * secondary channel offset: below
            	VHT operation:
            		 * channel width: 1 (80 MHz)
            		 * center freq segment 1: 155
            """.trimIndent()
        )
        org.junit.Assert.assertEquals(2, cells.size)
        val jogi = cells[0]
        org.junit.Assert.assertEquals("B4:F9:49:97:C2:58", jogi.bssid)
        org.junit.Assert.assertEquals("jogi1", jogi.ssid)
        org.junit.Assert.assertEquals(52, jogi.channel)
        org.junit.Assert.assertEquals(-51, jogi.signalDbm)
        org.junit.Assert.assertEquals("WPA2", jogi.encryption)     // RSN outranks the WPA1 block
        org.junit.Assert.assertEquals(80, jogi.widthMhz)
        org.junit.Assert.assertEquals(58, jogi.centerChannel)
        val hidden = cells[1]
        org.junit.Assert.assertFalse(hidden.named)                  // no SSID line at all
        org.junit.Assert.assertEquals(161, hidden.channel)
        org.junit.Assert.assertEquals(155, hidden.centerChannel)
        org.junit.Assert.assertEquals(80, hidden.widthMhz)
    }

    /** 2.4 GHz: HT40- centres two channels down, a plain HT20 cell stays put, no HT block → the frequency decides. */
    @org.junit.Test
    fun `iw scan widths on 2 point 4 GHz and the frequency fallback`() {
        val cells = com.vivekkaushik.wrtpulse.ops.Parsers.scanCells(
            """
            BSS b4:f9:49:97:c2:5e(on phy1-ap0)
            	freq: 2462.0
            	signal: -43.00 dBm
            	SSID: www.excitel.com
            	HT operation:
            		 * primary channel: 11
            		 * secondary channel offset: below
            		 * STA channel width: any
            	RSN:	 * Version: 1
            		 * Authentication suites: PSK
            BSS ae:37:28:c8:c2:b9(on phy1-ap0)
            	freq: 2462.0
            	signal: -58.00 dBm
            	HT operation:
            		 * primary channel: 11
            		 * secondary channel offset: no secondary
            		 * STA channel width: 20 MHz
            BSS 00:11:22:33:44:55(on phy1-ap0)
            	freq: 2437
            	capability: ESS Privacy ShortSlotTime (0x0411)
            	signal: -80.00 dBm
            	SSID: legacy-b
            """.trimIndent()
        )
        org.junit.Assert.assertEquals(3, cells.size)
        org.junit.Assert.assertEquals(40, cells[0].widthMhz)
        org.junit.Assert.assertEquals(9, cells[0].centerChannel)
        org.junit.Assert.assertEquals(20, cells[1].widthMhz)
        org.junit.Assert.assertEquals(11, cells[1].centerChannel)
        org.junit.Assert.assertEquals(6, cells[2].channel)           // 2437 MHz, no HT operation
        org.junit.Assert.assertEquals("WEP", cells[2].encryption)    // Privacy, no RSN or WPA
    }

    @org.junit.Test
    fun `iw scan security and duplicate readings`() {
        val cells = com.vivekkaushik.wrtpulse.ops.Parsers.scanCells(
            """
            BSS aa:bb:cc:dd:ee:01(on phy0-ap0)
            	freq: 5180.0
            	capability: ESS Privacy (0x0011)
            	signal: -60.00 dBm
            	SSID: wpa3-home
            	RSN:	 * Version: 1
            		 * Authentication suites: PSK SAE
            BSS aa:bb:cc:dd:ee:01(on phy0-ap0)
            	freq: 5180.0
            	capability: ESS Privacy (0x0011)
            	signal: -50.00 dBm
            	SSID: wpa3-home
            	RSN:	 * Version: 1
            		 * Authentication suites: PSK SAE
            BSS aa:bb:cc:dd:ee:02(on phy0-ap0)
            	freq: 5180.0
            	capability: ESS (0x0001)
            	signal: -65.00 dBm
            	SSID: cafe
            """.trimIndent()
        )
        org.junit.Assert.assertEquals(2, cells.size)                 // same BSSID twice → one cell
        org.junit.Assert.assertEquals(-50, cells[0].signalDbm)       // …the stronger reading
        org.junit.Assert.assertEquals("WPA3", cells[0].encryption)
        org.junit.Assert.assertEquals(36, cells[0].channel)
        org.junit.Assert.assertEquals("OPEN", cells[1].encryption)
    }

    @org.junit.Test
    fun `frequencies map to channel numbers`() {
        val p = com.vivekkaushik.wrtpulse.ops.Parsers
        org.junit.Assert.assertEquals(1, p.channelForMhz(2412))
        org.junit.Assert.assertEquals(13, p.channelForMhz(2472))
        org.junit.Assert.assertEquals(14, p.channelForMhz(2484))
        org.junit.Assert.assertEquals(36, p.channelForMhz(5180))
        org.junit.Assert.assertEquals(161, p.channelForMhz(5805))
        org.junit.Assert.assertEquals(1, p.channelForMhz(5955))     // 6 GHz
        org.junit.Assert.assertNull(p.channelForMhz(1000))
    }
}

class CreateNetworkCommandTest {

    /**
     * The wan zone is anonymous in every stock config, so it is found by walking `@zone[i]`
     * rather than by grepping for the name — a firewall *rule* called wan must not match.
     */
    @org.junit.Test
    fun `wan zone is found by walking zone sections`() {
        val cmd = com.vivekkaushik.wrtpulse.ops.Commands.attachToWanZone("wwan")
        org.junit.Assert.assertTrue(cmd.contains("uci -q get firewall.@zone[\$i].name"))
        // del_list before add_list, so applying twice leaves one entry, not two.
        org.junit.Assert.assertTrue(cmd.indexOf("del_list") < cmd.indexOf("add_list"))
        org.junit.Assert.assertTrue(cmd.contains("uci commit firewall"))
        // Ends in a true, so "no wan zone" doesn't fail the whole apply.
        org.junit.Assert.assertTrue(cmd.trimEnd().endsWith("; :"))
    }

    @org.junit.Test
    fun `a batch can commit more than one package`() {
        val script = com.vivekkaushik.wrtpulse.ops.Commands.uciBatch(
            listOf("add wireless wifi-iface", "set network.wwan.proto='dhcp'"),
            listOf("wireless", "network"),
            reload = "wifi reload",
        )
        org.junit.Assert.assertTrue(script.startsWith("uci batch <<'WRTPULSE_EOF'"))
        org.junit.Assert.assertTrue(
            script.trimEnd().endsWith("uci commit wireless && uci commit network && wifi reload")
        )
    }
}

class NetworkInterfaceParserTest {
    @org.junit.Test
    fun `interface sections are listed, options are not`() {
        val uci = com.vivekkaushik.wrtpulse.ops.Parsers.uciShow(
            """
            network.loopback=interface
            network.loopback.proto='static'
            network.lan=interface
            network.@device[0]=device
            network.wwan=interface
            network.wwan.proto='dhcp'
            """.trimIndent()
        )
        org.junit.Assert.assertEquals(
            setOf("loopback", "lan", "wwan"),
            com.vivekkaushik.wrtpulse.ops.Parsers.networkInterfaces(uci),
        )
    }
}

class InterfaceRowTest {

    private val unusedClient = object : com.vivekkaushik.wrtpulse.net.SshClient {
        override suspend fun probeHostKey(target: com.vivekkaushik.wrtpulse.net.SshTarget) = error("unused")
        override suspend fun connect(
            target: com.vivekkaushik.wrtpulse.net.SshTarget,
            auth: com.vivekkaushik.wrtpulse.net.SshAuth,
            connectTimeoutMs: Long,
        ) = error("unused")
    }

    private fun store() = WifiStore(
        com.vivekkaushik.wrtpulse.net.RouterSession(
            com.vivekkaushik.wrtpulse.net.SshTarget("t"), unusedClient, { error("unused") },
        )
    ).apply {
        radios.add(com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "2.4G", "11", "HT40", false))
        radios.add(com.vivekkaushik.wrtpulse.ops.WifiRadio("radio1", "5G", "36", "HE80", false))
        zones.add(com.vivekkaushik.wrtpulse.ops.FirewallZone("@zone[0]", "lan", listOf("lan")))
        zones.add(com.vivekkaushik.wrtpulse.ops.FirewallZone("@zone[1]", "wan", listOf("wan", "wwan")))
        zones.add(com.vivekkaushik.wrtpulse.ops.FirewallZone("@zone[2]", "guest", listOf("guest")))
        interfaces.addAll(listOf("lan", "wan", "wwan", "guest"))
    }

    private fun ap(
        section: String, device: String, ssid: String, network: String = "lan",
        disabled: Boolean = false, isolate: Boolean = false,
    ) = com.vivekkaushik.wrtpulse.ops.WifiNetwork(
        section, device, ssid, "psk2", "hunter22", disabled, "ap", network, false, isolate,
    )

    @Test
    fun `an access point row counts its clients and names where it lands`() {
        val s = store()
        s.networks.add(ap("default_radio1", "radio1", "Casa"))
        s.sectionIfnames["default_radio1"] = "phy1-ap0"
        s.clientCounts["phy1-ap0"] = 14
        val row = s.interfaceRows().single()
        assertEquals("14 clients · WPA2-PSK · lan", row.detail)
        // The radio's channel belongs on the row that sets it.
        assertEquals("5G · ch 36", row.bands)
        assertFalse(row.isClient)
        assertTrue(row.enabled)
    }

    /** The channel is a property of the radio, so only the first AP on it should claim one. */
    @Test
    fun `a second SSID on the same radio does not repeat the channel`() {
        val s = store()
        s.networks.add(ap("a", "radio1", "Casa"))
        s.networks.add(ap("b", "radio1", "Casa-IoT", network = "guest", isolate = true))
        val rows = s.interfaceRows()
        assertEquals("5G · ch 36", rows[0].bands)
        assertEquals("5G", rows[1].bands)
        assertEquals("0 clients · WPA2-PSK · guest zone · isolated", rows[1].detail)
    }

    @Test
    fun `a disabled network says so instead of counting clients`() {
        val s = store()
        s.networks.add(ap("g", "radio1", "Casa-Guest", network = "guest", disabled = true))
        val row = s.interfaceRows().single()
        assertFalse(row.enabled)
        assertEquals("disabled · WPA2-PSK · guest zone", row.detail)
    }

    @Test
    fun `a client in the wan zone is the uplink and reports its own signal`() {
        val s = store()
        s.networks.add(
            com.vivekkaushik.wrtpulse.ops.WifiNetwork(
                "wwan", "radio1", "Casa-Upstairs", "psk2", "k", false, "sta", "wwan",
            )
        )
        s.sectionIfnames["wwan"] = "phy1-sta0"
        s.live["phy1-sta0"] = com.vivekkaushik.wrtpulse.ops.IwinfoIface(
            "phy1-sta0", "Casa-Upstairs", "5A:8B:1C:44:E2:90", "Client", 100, -61, "WPA2 PSK",
        )
        val row = s.interfaceRows().single()
        assertTrue(row.isClient)
        assertTrue(row.isUplink)
        assertEquals("→ Casa-Upstairs · -61 dBm · wan zone", row.detail)
    }

    /** A client outside the wan zone is joined to something, but nothing routes through it. */
    @Test
    fun `a client in no zone is not marked as the uplink`() {
        val s = store()
        s.networks.add(
            com.vivekkaushik.wrtpulse.ops.WifiNetwork(
                "wwan2", "radio0", "Elsewhere", "psk2", "k", false, "sta", "spare",
            )
        )
        assertFalse(s.interfaceRows().single().isUplink)
    }

    @Test
    fun `one SSID on two radios is one draft, one row, and two sections`() {
        val s = store()
        val draft = s.addDraft(listOf("radio0", "radio1"), "ap", "Casa-Media", "sae", "correcthorse")
        assertEquals(2, draft.sections.size)
        assertEquals(2, draft.sections.values.distinct().size)
        val created = s.ops().filter { it.endsWith("=wifi-iface") }
        assertEquals(2, created.size)
        // Each section is pinned to its own radio.
        assertTrue(s.ops().contains("set wireless.${draft.sections["radio0"]}.device='radio0'"))
        assertTrue(s.ops().contains("set wireless.${draft.sections["radio1"]}.device='radio1'"))

        val row = s.interfaceRows().single { it.isNew }
        assertEquals("2.4G + 5G", row.bands)
        assertEquals(1, s.pendingCount)   // one thing the user made, not two
    }

    @Test
    fun `a client draft can decline the uplink zone`() {
        val s = store()
        s.addDraft(listOf("radio0"), "sta", "Guest net", "psk2", "hunter22", zone = "")
        assertTrue(s.firewallLines().isEmpty())
        // The network still has to exist, or the station has nowhere to get an address.
        assertTrue(s.networkOps().isNotEmpty())
    }

    /**
     * The form offers this as the default interface name, so it must not be one the router
     * is already using — the uplink it is reaching the internet through, typically.
     */
    @Test
    fun `the default uplink name steps around interfaces that exist`() {
        val s = store()
        assertEquals("wwan_2", s.freeUplinkName())
        assertTrue(s.networkExists("wwan"))
        assertFalse(s.networkExists("wwan_2"))
        // A staged uplink counts too, so two clients in one batch don't collide.
        s.addDraft(listOf("radio0"), "sta", "A", "psk2", "hunter22", network = "wwan_2")
        assertEquals("wwan_3", s.freeUplinkName())
    }

    @Test
    fun `a disabled uplink says so instead of reporting a stale signal`() {
        val s = store()
        s.networks.add(
            com.vivekkaushik.wrtpulse.ops.WifiNetwork(
                "wwan", "radio0", "VivekWifi", "psk2", "k", true, "sta", "wwan",
            )
        )
        assertEquals("→ VivekWifi · disabled · wan zone", s.interfaceRows().single().detail)
    }

    /**
     * The failure this came from: an SSID was created on a radio whose wifi-device had
     * disabled='1'. The app showed it as active, the network never appeared on any phone,
     * and LuCI said "Wireless is disabled". Nothing in the app mentioned the radio.
     */
    @Test
    fun `a network on a switched-off radio says so instead of looking active`() {
        val s = store()
        s.radios[0] = com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "2.4G", "11", "HT40", true)
        s.networks.add(ap("guest", "radio0", "Casa-2G"))
        val row = s.interfaceRows().single()
        // The interface itself is not disabled — only the radio under it.
        assertTrue(row.enabled)
        assertFalse(row.radioOn)
        assertFalse(row.onAir)
        assertEquals("radio0 is off · WPA2-PSK · lan", row.detail)
    }

    @Test
    fun `staging the radio back on clears the warning without touching the interface`() {
        val s = store()
        s.radios[0] = com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "2.4G", "11", "HT40", true)
        s.networks.add(ap("guest", "radio0", "Casa-2G"))
        assertFalse(s.radioEnabled("radio0"))

        s.stage("radio0", "disabled", "1", "0")
        assertTrue(s.radioEnabled("radio0"))
        assertTrue(s.interfaceRows().single().onAir)
        assertEquals(listOf("set wireless.radio0.disabled='0'"), s.ops())
    }

    @Test
    fun `a draft on a dead radio warns that nothing will broadcast`() {
        val s = store()
        s.radios[0] = com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "2.4G", "11", "HT40", true)
        s.addDraft(listOf("radio0"), "ap", "Casa-2G", "psk2", "hunter22")
        val row = s.interfaceRows().single { it.isNew }
        assertFalse(row.radioOn)
        assertEquals("radio0 off · nothing will broadcast", row.detail)
    }

    /** One live radio is enough for the draft to reach the air. */
    @Test
    fun `a draft across two radios is not written off when only one is dead`() {
        val s = store()
        s.radios[0] = com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "2.4G", "11", "HT40", true)
        s.addDraft(listOf("radio0", "radio1"), "ap", "Casa-Media", "psk2", "hunter22")
        val row = s.interfaceRows().single { it.isNew }
        assertFalse(row.radioOn)                       // not everything it asked for is up
        assertTrue(row.detail.contains("0 clients"))   // but it is not a dead network either
    }

    @Test
    fun `client isolation is written only when asked for`() {
        val s = store()
        s.addDraft(listOf("radio0"), "ap", "IoT", "psk2", "hunter22", isolate = true)
        assertTrue(s.ops().any { it.endsWith(".isolate='1'") })
        val plain = store().apply { addDraft(listOf("radio0"), "ap", "IoT", "psk2", "hunter22") }
        assertFalse(plain.ops().any { it.contains(".isolate") })
    }

    // ---- swipe-to-delete (design screen 3e) ----
    // These use the class's own store()/ap() fixtures. Adding a second "radio0" instead of
    // replacing the fixture's one made radioEnabled() find the enabled copy first, which is
    // how the radio-off case first passed for the wrong reason.

    private fun sta(section: String, device: String, ssid: String, network: String, disabled: Boolean) =
        com.vivekkaushik.wrtpulse.ops.WifiNetwork(
            section, device, ssid, "psk2", "hunter22", disabled, "sta", network, false, false,
        )

    @Test
    fun `a staged delete becomes a uci delete and counts as pending`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        assertEquals(listOf("delete wireless.wrtpulse"), s.ops())
        assertEquals(1, s.pendingCount)
    }

    @Test
    fun `staging the same delete twice still deletes once`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        s.stageDelete("wrtpulse")
        assertEquals(1, s.ops().size)
    }

    @Test
    fun `a delete can be undone in place`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        assertTrue(s.isDeleting("wrtpulse"))
        s.undoDelete("wrtpulse")
        assertFalse(s.isDeleting("wrtpulse"))
        assertEquals(0, s.pendingCount)
        assertTrue(s.ops().isEmpty())
    }

    /** Setting an option on a section the same batch is about to delete is noise. */
    @Test
    fun `edits to a deleted section never reach the batch`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stage("wrtpulse", "ssid", "WrtPulse", "Renamed")
        s.stageDelete("wrtpulse")
        assertEquals(listOf("delete wireless.wrtpulse"), s.ops())
        assertTrue(s.diffLines().none { it.first.contains("Renamed") })
    }

    @Test
    fun `the review sheet shows a delete as a removal`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        assertEquals(listOf("- wrtpulse=wifi-iface" to false), s.diffLines())
    }

    @Test
    fun `revert drops staged deletes with everything else`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        s.revert()
        assertEquals(0, s.pendingCount)
        assertTrue(s.ops().isEmpty())
    }

    /**
     * Every saved interface is swipeable, on the air or not — a deliberate departure from
     * design screen 3e. The protection is that the swipe only STAGES, and the review sheet
     * names the cost; see the deletionNotes tests below.
     */
    @Test
    fun `every saved interface offers the swipe`() {
        val off = store().apply { networks.add(ap("a", "radio0", "Off", disabled = true)) }
        assertTrue(off.interfaceRows().single().deletable)

        val live = store().apply { networks.add(ap("a", "radio0", "Live", disabled = false)) }
        assertTrue(live.interfaceRows().single().deletable)
    }

    @Test
    fun `an unsaved draft is not swipe-deletable`() {
        val s = store()
        s.addDraft(listOf("radio0"), "ap", "Guest", "psk2", "guestpass")
        val draft = s.interfaceRows().single { it.isNew }
        assertFalse(draft.deletable)
    }

    /** Deleting a live AP costs its clients the network, so the sheet has to say so. */
    @Test
    fun `deleting an on-air access point warns that clients lose it`() {
        val s = store()
        s.networks.add(ap("default_radio0", "radio0", "OpenWrt", disabled = false))
        s.stageDelete("default_radio0")
        val note = s.deletionNotes().single()
        assertTrue(note.contains("OpenWrt"))
        assertTrue(note.contains("on the air"))
        assertTrue(note.contains("this phone"))
    }

    /** The uplink is the one deletion that takes the router's own internet with it. */
    @Test
    fun `deleting the uplink warns about losing the router's internet`() {
        val s = store()
        s.networks.add(sta("wwan_2", "radio0", "VivekWifi_5G", "wwan", false))
        s.stageDelete("wwan_2")
        val notes = s.deletionNotes()
        assertTrue(notes.any { it.contains("upstream link") && it.contains("internet") })
        // and still the orphaned network stanza
        assertTrue(notes.any { it.contains("network.wwan") })
    }

    @Test
    fun `a switched-off interface gets no on-air warning`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        assertTrue(s.deletionNotes().none { it.contains("on the air") })
    }

    /** An enabled interface whose radio is off is not on the air, and is not described as such. */
    @Test
    fun `an interface on a switched-off radio is not called on-air`() {
        val s = store()
        s.radios[0] = com.vivekkaushik.wrtpulse.ops.WifiRadio("radio0", "2.4G", "11", "HT40", true)
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = false))
        s.stageDelete("wrtpulse")
        assertTrue(s.interfaceRows().single().deletable)
        assertTrue(s.deletionNotes().none { it.contains("on the air") })
    }

    @Test
    fun `the row reports it is being deleted so the list can mark it`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        assertTrue(s.interfaceRows().single().deleting)
    }

    /** A wifi-iface delete does not take the network stanza it pointed at. */
    @Test
    fun `deleting a client interface warns about the uplink it leaves behind`() {
        val s = store()
        s.networks.add(sta("wifinet2", "radio0", "VivekWifi", "wwan", true))
        s.stageDelete("wifinet2")
        val note = s.deletionNotes().single()
        assertTrue(note.contains("network.wwan"))
        assertTrue(note.contains("firewall"))
    }

    /**
     * A switched-off uplink is not carrying anything, so it must not claim that deleting it
     * takes the router offline — that warning is reserved for one that is actually up.
     */
    @Test
    fun `a switched-off uplink does not claim to be carrying the internet`() {
        val s = store()
        s.networks.add(sta("wifinet2", "radio0", "VivekWifi", "wwan", true))
        s.stageDelete("wifinet2")
        assertTrue(s.deletionNotes().none { it.contains("upstream link") })
    }

    @Test
    fun `deleting a switched-off AP has nothing to warn about`() {
        val s = store()
        s.networks.add(ap("wrtpulse", "radio0", "WrtPulse", disabled = true))
        s.stageDelete("wrtpulse")
        assertTrue(s.deletionNotes().isEmpty())
    }
}
