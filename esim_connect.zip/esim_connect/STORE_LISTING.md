# Store Listing — eSIM Connect

> This app is built for personal sideloading, not store submission. This
> listing is kept for consistency with the standard project template.

- **App name** (3–24 chars): `eSIM Connect`
- **Keywords** (5–15): esim, bluetooth, odcpe, provisioning, activation code,
  sm-dp+, qr scan, web ui, router, network
- **Short description** (≤100 chars): Connect to an ODCPE unit over
  Bluetooth and install its eSIM profile.
- **Long description** (200–2000 chars):
  eSIM Connect helps you provision a new eUICC profile on a compatible
  ODCPE unit. Scan the unit's label QR code, connect to it over Bluetooth,
  open its local web admin page from inside the app, and install an eSIM
  profile using a standard GSMA activation code (SM-DP+ address + matching
  ID) via Android's own eSIM system service — the same mechanism every
  carrier app relies on. An on-device activity log lets you copy or share
  what happened during setup. No account, no ads, no analytics, no backend
  server — everything runs locally on your phone.
- **Category**: Tools / Utilities
- **Age rating**: Everyone

## Self-certification table (honest, unmeasured items marked as such)

| Check | Status |
|---|---|
| Uses Google Play Services / GMS | No |
| Uses third-party ad SDK | No |
| Uses third-party push/billing/analytics SDK | No |
| Uses Google Maps | No |
| Uses voice search | No |
| Works without internet (except WebView/eSIM steps) | Measure/Not done |
| Android M (API 23) compatible | No (minSdk 24) |
| Accessibility audit | Measure/Not done |
| Battery usage audit | Measure/Not done |

## Integration checks

No Jio Ad/Push/Voice-Assistant/Analytics SDK integrated — this is an
independent, non-carrier app.
