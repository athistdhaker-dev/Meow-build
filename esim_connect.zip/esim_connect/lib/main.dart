import 'package:flutter/material.dart';
import 'glass.dart';
import 'mobile.dart';

void main() {
  runApp(const EsimConnectApp());
}

class EsimConnectApp extends StatelessWidget {
  const EsimConnectApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'eSIM Connect',
      debugShowCheckedModeBanner: false,
      theme: ThemeData.dark(useMaterial3: true).copyWith(
        scaffoldBackgroundColor: Colors.transparent,
        colorScheme: ThemeData.dark(useMaterial3: true)
            .colorScheme
            .copyWith(primary: kPurple),
      ),
      builder: (context, child) => AppBackground(child: child!),
      home: const HomeScreen(),
    );
  }
}
