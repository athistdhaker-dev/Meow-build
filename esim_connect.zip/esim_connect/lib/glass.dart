import 'dart:ui';
import 'package:flutter/material.dart';

const Color kPurple = Color(0xFF7B2FF7);
const Color kPink = Color(0xFFEC5678);
const Color kBlue = Color(0xFF2FA8F7);
const Color kTeal = Color(0xFF2ED3B7);

/// App-wide dark gradient background with soft colour orbs.
class AppBackground extends StatelessWidget {
  final Widget child;
  const AppBackground({super.key, required this.child});

  @override
  Widget build(BuildContext context) {
    return Container(
      decoration: const BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Color(0xFF0B0714), Color(0xFF16102A), Color(0xFF0D0B1C)],
        ),
      ),
      child: Stack(
        children: [
          Positioned(
              top: -80,
              left: -60,
              child: _Orb(color: kPurple.withOpacity(0.35), size: 260)),
          Positioned(
              top: 120,
              right: -90,
              child: _Orb(color: kBlue.withOpacity(0.28), size: 240)),
          Positioned(
              bottom: -100,
              left: -40,
              child: _Orb(color: kPink.withOpacity(0.25), size: 300)),
          Positioned(
              bottom: 60,
              right: -60,
              child: _Orb(color: kTeal.withOpacity(0.22), size: 220)),
          child,
        ],
      ),
    );
  }
}

class _Orb extends StatelessWidget {
  final Color color;
  final double size;
  const _Orb({required this.color, required this.size});

  @override
  Widget build(BuildContext context) {
    return IgnorePointer(
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: [color, color.withOpacity(0)]),
        ),
      ),
    );
  }
}

/// Paints the specular rim + top highlight for a glass panel.
class _GlassRimPainter extends CustomPainter {
  final double radius;
  final bool focused;
  _GlassRimPainter({required this.radius, this.focused = false});

  @override
  void paint(Canvas canvas, Size size) {
    final rrect = RRect.fromRectAndRadius(
        Offset.zero & size, Radius.circular(radius));
    final rim = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = focused ? 1.6 : 1.0
      ..shader = LinearGradient(
        begin: Alignment.topLeft,
        end: Alignment.bottomRight,
        colors: focused
            ? [Colors.white.withOpacity(0.9), kPurple.withOpacity(0.5)]
            : [Colors.white.withOpacity(0.35), Colors.white.withOpacity(0.05)],
      ).createShader(Offset.zero & size);
    canvas.drawRRect(rrect.deflate(0.5), rim);

    final highlight = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1.2
      ..color = Colors.white.withOpacity(0.25);
    final path = Path()
      ..moveTo(radius, 1)
      ..lineTo(size.width - radius, 1);
    canvas.drawPath(path, highlight);
  }

  @override
  bool shouldRepaint(covariant _GlassRimPainter old) =>
      old.focused != focused || old.radius != radius;
}

/// A single-blur glass panel. Use this for the outer container of a screen
/// or card; inner tiles/keys should use [GlassTile] (no blur) instead so we
/// never stack multiple BackdropFilters.
class GlassPanel extends StatelessWidget {
  final Widget child;
  final double radius;
  final EdgeInsets padding;
  final bool blur;

  const GlassPanel({
    super.key,
    required this.child,
    this.radius = 24,
    this.padding = const EdgeInsets.all(16),
    this.blur = true,
  });

  @override
  Widget build(BuildContext context) {
    final content = Container(
      padding: padding,
      decoration: BoxDecoration(
        borderRadius: BorderRadius.circular(radius),
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [Colors.white.withOpacity(0.10), Colors.white.withOpacity(0.03)],
        ),
      ),
      child: CustomPaint(
        foregroundPainter: _GlassRimPainter(radius: radius),
        child: child,
      ),
    );

    final clipped = ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: content,
    );

    if (!blur) return clipped;

    return ClipRRect(
      borderRadius: BorderRadius.circular(radius),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 18, sigmaY: 18),
        child: content,
      ),
    );
  }
}

/// A translucent gradient tile with no blur of its own — safe to nest
/// inside a [GlassPanel] that already has a BackdropFilter.
class GlassTile extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;
  final bool enabled;
  final EdgeInsets padding;
  final double radius;

  const GlassTile({
    super.key,
    required this.child,
    this.onTap,
    this.enabled = true,
    this.padding = const EdgeInsets.symmetric(horizontal: 18, vertical: 16),
    this.radius = 16,
  });

  @override
  State<GlassTile> createState() => _GlassTileState();
}

class _GlassTileState extends State<GlassTile> {
  bool _focused = false;
  bool _pressed = false;

  @override
  Widget build(BuildContext context) {
    final active = (_focused || _pressed) && widget.enabled;
    return Opacity(
      opacity: widget.enabled ? 1 : 0.4,
      child: FocusableActionDetector(
        enabled: widget.enabled,
        onShowFocusHighlight: (v) => setState(() => _focused = v),
        actions: {
          ActivateIntent: CallbackAction<ActivateIntent>(
              onInvoke: (_) {
                widget.onTap?.call();
                return null;
              }),
        },
        child: GestureDetector(
          onTap: widget.enabled ? widget.onTap : null,
          onTapDown: (_) => setState(() => _pressed = true),
          onTapCancel: () => setState(() => _pressed = false),
          onTapUp: (_) => setState(() => _pressed = false),
          child: AnimatedScale(
            duration: const Duration(milliseconds: 120),
            scale: active ? 1.02 : 1.0,
            child: Container(
              padding: widget.padding,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(widget.radius),
                gradient: LinearGradient(
                  begin: Alignment.topLeft,
                  end: Alignment.bottomRight,
                  colors: active
                      ? [kPurple.withOpacity(0.35), kBlue.withOpacity(0.25)]
                      : [
                          Colors.white.withOpacity(0.08),
                          Colors.white.withOpacity(0.02)
                        ],
                ),
                border: Border.all(
                  color: active
                      ? Colors.white.withOpacity(0.6)
                      : Colors.white.withOpacity(0.12),
                  width: active ? 1.4 : 1,
                ),
              ),
              child: widget.child,
            ),
          ),
        ),
      ),
    );
  }
}
