import 'dart:async';
import 'dart:io';

/// Builds the list of IPv4 addresses to probe in a /24 subnet, e.g.
/// subnetBase "192.168.44" -> ["192.168.44.1", ..., "192.168.44.254"].
/// Pure logic, unit-testable.
List<String> scanTargets(String subnetBase, {int start = 1, int end = 254}) {
  final out = <String>[];
  for (var i = start; i <= end; i++) {
    out.add('$subnetBase.$i');
  }
  return out;
}

/// Probes a /24 subnet for hosts with [port] open (443 by default — the
/// ODU's web UI), the same idea as `nmap -p 443 192.168.44.0/24`. Only
/// usable on a real device with a live Bluetooth PAN connection, so it is
/// not unit-tested here.
///
/// Returns the IPs that accepted a connection on [port], in ascending
/// order. Runs probes in bounded batches so it doesn't open 254 sockets
/// at once.
Future<List<String>> findHostsWithOpenPort({
  String subnetBase = '192.168.44',
  int port = 443,
  Duration timeout = const Duration(milliseconds: 400),
  int concurrency = 32,
}) async {
  final targets = scanTargets(subnetBase);
  final found = <String>[];

  for (var i = 0; i < targets.length; i += concurrency) {
    final batch = targets.skip(i).take(concurrency);
    final results = await Future.wait(batch.map((ip) async {
      try {
        final socket = await Socket.connect(ip, port, timeout: timeout);
        socket.destroy();
        return ip;
      } catch (_) {
        return null;
      }
    }));
    found.addAll(results.whereType<String>());
  }

  found.sort((a, b) {
    int lastOctet(String ip) => int.parse(ip.split('.').last);
    return lastOctet(a).compareTo(lastOctet(b));
  });
  return found;
}
