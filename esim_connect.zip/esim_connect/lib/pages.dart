import 'package:flutter/material.dart';
import 'package:flutter/foundation.dart' show LicenseRegistry, LicenseEntry;
import 'glass.dart';
import 'legal.dart';

class AboutPage extends StatelessWidget {
  const AboutPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('About & Legal'),
      ),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            GlassPanel(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text('eSIM Connect',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 18,
                          fontWeight: FontWeight.w700)),
                  const SizedBox(height: 6),
                  Text('Version $kAppVersion',
                      style: TextStyle(color: Colors.white.withOpacity(0.6))),
                ],
              ),
            ),
            const SizedBox(height: 14),
            _NavTile(
              label: 'Privacy Policy',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) =>
                      const _TextPage(title: 'Privacy Policy', body: kPrivacyPolicy))),
            ),
            _NavTile(
              label: 'Terms & Conditions',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const _TextPage(
                      title: 'Terms & Conditions', body: kTermsAndConditions))),
            ),
            _NavTile(
              label: 'Open-source licenses',
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const LicensesPage())),
            ),
          ],
        ),
      ),
    );
  }
}

class _NavTile extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _NavTile({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: GlassTile(
        onTap: onTap,
        child: Row(
          children: [
            Expanded(
                child: Text(label,
                    style: const TextStyle(color: Colors.white, fontSize: 15))),
            Icon(Icons.chevron_right, color: Colors.white.withOpacity(0.4)),
          ],
        ),
      ),
    );
  }
}

class _TextPage extends StatelessWidget {
  final String title;
  final String body;
  const _TextPage({required this.title, required this.body});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(backgroundColor: Colors.transparent, title: Text(title)),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GlassPanel(
            child: SingleChildScrollView(
              child: Text(body, style: const TextStyle(color: Colors.white70, height: 1.4)),
            ),
          ),
        ),
      ),
    );
  }
}

class LicensesPage extends StatelessWidget {
  const LicensesPage({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
          backgroundColor: Colors.transparent,
          title: const Text('Open-source licenses')),
      body: SafeArea(
        child: FutureBuilder<List<LicenseEntry>>(
          future: LicenseRegistry.licenses.toList(),
          builder: (context, snapshot) {
            final entries = snapshot.data ?? const [];
            if (snapshot.connectionState != ConnectionState.done) {
              return const Center(
                  child: CircularProgressIndicator(color: Colors.white));
            }
            return ListView.builder(
              padding: const EdgeInsets.all(16),
              itemCount: entries.length,
              itemBuilder: (context, i) {
                final e = entries[i];
                return Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: GlassPanel(
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(e.packages.join(', '),
                            style: const TextStyle(
                                color: Colors.white, fontWeight: FontWeight.w700)),
                        const SizedBox(height: 6),
                        Text(
                            e.paragraphs.map((p) => p.text).join('\n\n'),
                            style: const TextStyle(color: Colors.white54, fontSize: 11)),
                      ],
                    ),
                  ),
                );
              },
            );
          },
        ),
      ),
    );
  }
}
