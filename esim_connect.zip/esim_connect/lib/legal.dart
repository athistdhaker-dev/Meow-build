// Legal text placeholders. Fill in the Grievance Officer block before
// publishing anywhere public; these are required by India's IT Rules 2021
// (Rule 3(1)) for any app that is an "intermediary"/publishes user content.
// This app stores its activity log only on-device and sends no content to
// a server, so most of Rule 3(1) does not strictly apply — the block is
// kept here anyway so it's in one place if you ever add a backend.

const String kAppVersion = '1.0.0';
const String kLastUpdated = '10 October 2026';

const String kGrievanceOfficerName = '<Your Name>';
const String kGrievanceOfficerMobile = '<Your Mobile Number>';
const String kGrievanceOfficerAddress = '<Your Address>';
const String kGrievanceOfficerEmail = '<Your Email>';

const String kPrivacyPolicy = '''
Privacy Policy

Last updated: $kLastUpdated

This app ("eSIM Connect") runs entirely on your device. It does not have a
server backend and does not transmit your data anywhere.

What the app accesses, and why:
  • Camera — to scan a unit's label QR code. The camera feed is not stored
    or transmitted; only the decoded text is used.
  • Bluetooth — to discover and connect to the ODCPE unit you scan.
  • Local network / WebView — to show the unit's own web admin page inside
    the app, once connected.
  • The standard Android eSIM system service — to install a profile you
    supply an activation code for. This app does not see or store your
    eSIM credentials; the system handles the install directly.

The in-app activity log stays on your device until you clear the app's
data; it is not uploaded anywhere. You can copy and share it yourself from
the Share Log screen.

Grievance Officer (IT Rules 2021, Rule 3(1)):
  Name: $kGrievanceOfficerName
  Mobile: $kGrievanceOfficerMobile
  Address: $kGrievanceOfficerAddress
  Email: $kGrievanceOfficerEmail
''';

const String kTermsAndConditions = '''
Terms & Conditions

Last updated: $kLastUpdated

By using this app you agree that:
  1. It is provided as-is, for personal use, with no warranty of any kind.
  2. It is not affiliated with, endorsed by, or produced by any carrier or
     device manufacturer.
  3. Bluetooth tethering and eSIM installation ultimately depend on your
     device and operating system; the app cannot guarantee either will
     succeed on every device.
  4. You are responsible for any charges or consequences of installing an
     eSIM profile.

Electronic record notice (IT Rules 2021, Rule 3(1)): this document is an
electronic record published in accordance with the rules, and does not
require any physical or digital signature.

Grievance Officer:
  Name: $kGrievanceOfficerName
  Mobile: $kGrievanceOfficerMobile
  Address: $kGrievanceOfficerAddress
  Email: $kGrievanceOfficerEmail
''';
