import 'package:flutter/services.dart';

/// Thin wrappers around the native (Kotlin) side. Every call is guarded so
/// the UI layer never has to deal with PlatformException directly.
class Native {
  Native._();

  static const MethodChannel _env = MethodChannel('env');
  static const MethodChannel _bt = MethodChannel('bt');
  static const MethodChannel _esim = MethodChannel('esim');
  static const MethodChannel _settings = MethodChannel('settings');

  static Future<bool> isLowEndDevice() async {
    try {
      return (await _env.invokeMethod<bool>('lowEnd')) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Returns a list of currently bonded (paired) devices as
  /// {"name": ..., "mac": ...} maps.
  static Future<List<Map<String, String>>> bondedDevices() async {
    try {
      final res = await _bt.invokeMethod<List<dynamic>>('bondedDevices');
      if (res == null) return const [];
      return res
          .cast<Map>()
          .map((m) => m.map((k, v) => MapEntry('$k', '$v')))
          .toList();
    } catch (_) {
      return const [];
    }
  }

  /// Starts a classic-Bluetooth scan; [onFound] is called once per
  /// discovered device as it's reported. Call [stopScan] to stop early.
  static Future<void> startScan(
      void Function(String name, String mac) onFound) async {
    _bt.setMethodCallHandler((call) async {
      if (call.method == 'deviceFound') {
        final args = (call.arguments as Map).cast<String, dynamic>();
        onFound('${args['name'] ?? 'Unknown device'}', '${args['mac']}');
      }
    });
    try {
      await _bt.invokeMethod('startScan');
    } catch (_) {}
  }

  static Future<void> stopScan() async {
    try {
      await _bt.invokeMethod('stopScan');
    } catch (_) {}
    _bt.setMethodCallHandler(null);
  }

  /// Whether the runtime Bluetooth permission (BLUETOOTH_CONNECT +
  /// BLUETOOTH_SCAN on Android 12+, location on older versions) has been
  /// granted. Declaring it in the manifest is not enough — Android only
  /// shows the grant dialog when the app explicitly asks.
  static Future<bool> hasBluetoothPermission() async {
    try {
      return (await _bt.invokeMethod<bool>('hasPermissions')) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Shows the system permission dialog for Bluetooth. Fire-and-forget —
  /// there's no synchronous result, so the caller should ask the user to
  /// retry the action once they've granted it.
  static Future<void> requestBluetoothPermission() async {
    try {
      await _bt.invokeMethod('requestPermissions');
    } catch (_) {}
  }

  /// Attempts to pair/bond with the device at [mac]. Returns true on
  /// success. The actual confirmation dialog, if any, is shown by Android.
  static Future<bool> bondDevice(String mac) async {
    try {
      return (await _bt.invokeMethod<bool>('bond', {'mac': mac})) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Opens Android's Bluetooth tethering toggle so the user can switch it
  /// on manually. Programmatically enabling Bluetooth tethering requires a
  /// privileged system permission a normal sideloaded app cannot hold, so
  /// this app can only take the user to the system switch, not flip it.
  static Future<void> openBluetoothTetherSettings() async {
    try {
      await _settings.invokeMethod('openBluetoothTether');
    } catch (_) {}
  }

  /// Opens this app's own system settings page (so the user can grant the
  /// camera permission by hand after denying it once, since Android won't
  /// show the request dialog again on its own).
  static Future<void> openAppSettings() async {
    try {
      await _settings.invokeMethod('openAppSettings');
    } catch (_) {}
  }

  static Future<bool> hasCameraPermission() async {
    try {
      return (await _settings.invokeMethod<bool>('hasCameraPermission')) ??
          true;
    } catch (_) {
      return true;
    }
  }

  static Future<bool> isEsimSupported() async {
    try {
      return (await _esim.invokeMethod<bool>('isSupported')) ?? false;
    } catch (_) {
      return false;
    }
  }

  /// Starts the standard Android eSIM activation-code install flow
  /// (EuiccManager.downloadSubscription). The system's own LPA shows the
  /// consent/progress UI; this returns a short status string once the
  /// system reports a result.
  static Future<String> installActivationCode(String lpaString) async {
    try {
      final res = await _esim
          .invokeMethod<String>('install', {'code': lpaString});
      return res ?? 'No response from system.';
    } on PlatformException catch (e) {
      return 'Failed: ${e.message ?? e.code}';
    } catch (e) {
      return 'Failed: $e';
    }
  }
}
