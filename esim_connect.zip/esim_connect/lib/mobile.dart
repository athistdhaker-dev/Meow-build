import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:mobile_scanner/mobile_scanner.dart';
import 'package:webview_flutter/webview_flutter.dart';

import 'core.dart';
import 'glass.dart';
import 'logic.dart';
import 'netscan.dart';
import 'ui.dart';
import 'pages.dart';

/// Simple in-memory activity log, shared across screens for this session.
class AppLog {
  AppLog._();
  static final List<LogEntry> entries = [];

  static void add(String message) {
    entries.add(LogEntry(DateTime.now(), message));
  }
}

class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: [
            Row(
              children: [
                const Expanded(
                  child: Text('eSIM Connect',
                      style: TextStyle(
                          color: Colors.white,
                          fontSize: 24,
                          fontWeight: FontWeight.w800)),
                ),
                IconButton(
                  icon: const Icon(Icons.info_outline, color: Colors.white70),
                  onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const AboutPage())),
                ),
              ],
            ),
            Text('Provision a new eUICC profile on an ODCPE unit.',
                style: TextStyle(color: Colors.white.withOpacity(0.6))),
            const SectionTitle('Functions'),
            FunctionRow(
              label: 'Scan & connect',
              icon: Icons.qr_code_scanner,
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const ScanQrScreen())),
            ),
            FunctionRow(
              label: 'Enter Bluetooth MAC manually',
              icon: Icons.edit_outlined,
              subtitle: 'Connect without using the camera',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const ManualMacScreen())),
            ),
            FunctionRow(
              label: 'Install via activation code',
              icon: Icons.sim_card_download_outlined,
              subtitle: 'Standard Android eSIM (SM-DP+) install',
              onTap: () => Navigator.of(context).push(MaterialPageRoute(
                  builder: (_) => const ActivationCodeScreen())),
            ),
            FunctionRow(
              label: 'Open unit web UI',
              icon: Icons.public,
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const WebUiScreen())),
            ),
            FunctionRow(
              label: 'Bluetooth tethering settings',
              icon: Icons.bluetooth_connected,
              subtitle: 'Turn on sharing from system settings',
              onTap: () async {
                AppLog.add('Opened Bluetooth tethering settings');
                await Native.openBluetoothTetherSettings();
              },
            ),
            FunctionRow(
              label: 'Share log',
              icon: Icons.share_outlined,
              onTap: () => Navigator.of(context).push(
                  MaterialPageRoute(builder: (_) => const LogScreen())),
            ),
          ],
        ),
      ),
    );
  }
}

class ScanQrScreen extends StatefulWidget {
  const ScanQrScreen({super.key});

  @override
  State<ScanQrScreen> createState() => _ScanQrScreenState();
}

class _ScanQrScreenState extends State<ScanQrScreen> {
  bool _handled = false;
  MobileScannerController _controller = MobileScannerController(
    detectionSpeed: DetectionSpeed.normal,
    facing: CameraFacing.back,
  );

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  /// "genericError" (and other non-permission errors) from mobile_scanner
  /// are often a transient CameraX failure — e.g. the camera was still held
  /// by another app, or the very first start raced with permission grant.
  /// Tearing down and recreating the controller usually clears it.
  void _retry() {
    final old = _controller;
    setState(() {
      _controller = MobileScannerController(
        detectionSpeed: DetectionSpeed.normal,
        facing: CameraFacing.back,
      );
    });
    old.dispose();
    AppLog.add('Retried opening the camera');
  }

  void _onDetect(BarcodeCapture capture) {
    if (_handled) return;
    final barcodes = capture.barcodes;
    if (barcodes.isEmpty) return;
    final raw = barcodes.first.rawValue;
    if (raw == null || raw.isEmpty) return;
    final details = parseUnitQr(raw);
    if (!details.hasMac) return;
    _handled = true;
    AppLog.add('Scanned label: $raw');
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => ConnectScreen(details: details)),
    );
  }

  void _goManual() {
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => const ManualMacScreen()),
    );
  }

  Widget _cameraError(BuildContext context, MobileScannerException error) {
    final denied = error.errorCode == MobileScannerErrorCode.permissionDenied;
    return Container(
      color: Colors.black,
      padding: const EdgeInsets.all(24),
      child: Center(
        child: GlassPanel(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.videocam_off_outlined,
                  color: Colors.white.withOpacity(0.7), size: 36),
              const SizedBox(height: 12),
              Text(
                denied
                    ? 'Camera permission was denied. Allow it in Settings, '
                        'or enter the unit\'s Bluetooth MAC manually instead.'
                    : 'Could not open the camera (${error.errorCode}). This '
                        'is often temporary — try again, or enter the MAC '
                        'manually instead.',
                style: const TextStyle(color: Colors.white),
                textAlign: TextAlign.center,
              ),
              const SizedBox(height: 16),
              if (denied)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: PrimaryButton(
                    label: 'Open app settings',
                    onPressed: () async {
                      AppLog.add('Opened app settings for camera permission');
                      await Native.openAppSettings();
                    },
                  ),
                )
              else
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: PrimaryButton(label: 'Try again', onPressed: _retry),
                ),
              PrimaryButton(label: 'Enter MAC manually', onPressed: _goManual),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.black,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Scan the QR code on the unit'),
      ),
      body: Stack(
        fit: StackFit.expand,
        children: [
          MobileScanner(
            controller: _controller,
            onDetect: _onDetect,
            errorBuilder: (context, error) => _cameraError(context, error),
          ),
          Align(
            alignment: Alignment.center,
            child: Container(
              width: 240,
              height: 240,
              decoration: BoxDecoration(
                border: Border.all(color: Colors.white.withOpacity(0.8), width: 2),
                borderRadius: BorderRadius.circular(18),
              ),
            ),
          ),
          Positioned(
            left: 16,
            right: 16,
            bottom: 24,
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                GlassPanel(
                  child: const Text(
                    'Point the camera at the label QR code printed on the unit.',
                    style: TextStyle(color: Colors.white),
                    textAlign: TextAlign.center,
                  ),
                ),
                const SizedBox(height: 10),
                GlassTile(
                  onTap: _goManual,
                  child: const Center(
                    child: Text('Camera not working? Enter MAC manually',
                        style: TextStyle(color: Colors.white, fontSize: 13)),
                  ),
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

class ManualMacScreen extends StatefulWidget {
  const ManualMacScreen({super.key});

  @override
  State<ManualMacScreen> createState() => _ManualMacScreenState();
}

class _ManualMacScreenState extends State<ManualMacScreen> {
  final _macCtrl = TextEditingController();
  final _modelCtrl = TextEditingController();
  final _eidCtrl = TextEditingController();
  String? _error;

  @override
  void dispose() {
    _macCtrl.dispose();
    _modelCtrl.dispose();
    _eidCtrl.dispose();
    super.dispose();
  }

  void _continue() {
    final mac = normalizeMac(_macCtrl.text);
    if (mac == null) {
      setState(() => _error =
          'Enter a valid MAC address, e.g. BC:F8:7E:EA:D7:87 (or just BCF87EEAD787).');
      return;
    }
    final details = UnitDetails(
      mac: mac,
      model: _modelCtrl.text.trim().isEmpty ? null : _modelCtrl.text.trim(),
      eid: _eidCtrl.text.trim().isEmpty ? null : _eidCtrl.text.trim(),
    );
    AppLog.add('Entered MAC manually: $mac');
    Navigator.of(context).pushReplacement(
      MaterialPageRoute(builder: (_) => ConnectScreen(details: details)),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Enter Bluetooth MAC manually'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              GlassPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                        'Usually printed on the unit\'s label next to the QR '
                        'code. Model and EID are optional.',
                        style: TextStyle(color: Colors.white70, fontSize: 13)),
                    const SizedBox(height: 16),
                    const Text('MAC address', style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 6),
                    GlassTextField(
                        controller: _macCtrl, hint: 'BC:F8:7E:EA:D7:87'),
                    const SizedBox(height: 14),
                    const Text('Model (optional)', style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 6),
                    GlassTextField(controller: _modelCtrl, hint: 'e.g. JODU52240'),
                    const SizedBox(height: 14),
                    const Text('EID (optional)', style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 6),
                    GlassTextField(controller: _eidCtrl, hint: 'EID'),
                  ],
                ),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(_error!,
                      style: const TextStyle(color: Colors.redAccent)),
                ),
              const SizedBox(height: 16),
              PrimaryButton(label: 'Continue', onPressed: _continue),
            ],
          ),
        ),
      ),
    );
  }
}

class ConnectScreen extends StatefulWidget {
  final UnitDetails details;
  const ConnectScreen({super.key, required this.details});

  @override
  State<ConnectScreen> createState() => _ConnectScreenState();
}

class _ConnectScreenState extends State<ConnectScreen> {
  bool _connecting = false;
  bool _connected = false;
  String? _status;

  Future<void> _connect() async {
    final mac = widget.details.mac;
    if (mac == null) return;
    setState(() {
      _connecting = true;
      _status = null;
    });
    AppLog.add('Connecting via Bluetooth to $mac');
    final ok = await Native.bondDevice(mac);
    setState(() {
      _connecting = false;
      _connected = ok;
      _status = ok
          ? 'Connected. You can now open the unit web UI or install the eSIM profile.'
          : 'Could not connect. Make sure Bluetooth is on and the unit is in pairing mode, then try again.';
    });
    AppLog.add(ok ? 'Bluetooth connect succeeded' : 'Bluetooth connect failed');
  }

  @override
  Widget build(BuildContext context) {
    final d = widget.details;
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Connect'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              StepDots(
                step: _connected ? 2 : 1,
                labels: const ['Scan label', 'Connect', 'Provision'],
              ),
              const SizedBox(height: 20),
              GlassPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('UNIT DETAILS',
                        style: TextStyle(
                            color: Colors.white70,
                            fontSize: 12,
                            fontWeight: FontWeight.w700)),
                    const SizedBox(height: 10),
                    _detailRow('MAC', d.mac ?? '-'),
                    _detailRow('Model', d.model ?? '-'),
                    _detailRow('EID', d.eid ?? '-'),
                  ],
                ),
              ),
              const SizedBox(height: 20),
              if (_status != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(_status!,
                      style: TextStyle(color: Colors.white.withOpacity(0.8))),
                ),
              PrimaryButton(
                label: _connected ? 'Connected' : 'Connect via Bluetooth',
                loading: _connecting,
                onPressed: (d.mac == null || _connected) ? null : _connect,
              ),
              if (_connected) ...[
                const SizedBox(height: 10),
                PrimaryButton(
                  label: 'Install via activation code',
                  onPressed: () => Navigator.of(context).push(MaterialPageRoute(
                      builder: (_) => const ActivationCodeScreen())),
                ),
                const SizedBox(height: 10),
                PrimaryButton(
                  label: 'Open unit web UI',
                  onPressed: () => Navigator.of(context).push(
                      MaterialPageRoute(builder: (_) => const WebUiScreen())),
                ),
              ],
            ],
          ),
        ),
      ),
    );
  }

  Widget _detailRow(String label, String value) {
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 4),
      child: Row(
        children: [
          SizedBox(
              width: 70,
              child: Text(label,
                  style: TextStyle(color: Colors.white.withOpacity(0.5)))),
          Expanded(
              child: Text(value,
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w600))),
        ],
      ),
    );
  }
}

class ActivationCodeScreen extends StatefulWidget {
  const ActivationCodeScreen({super.key});

  @override
  State<ActivationCodeScreen> createState() => _ActivationCodeScreenState();
}

class _ActivationCodeScreenState extends State<ActivationCodeScreen> {
  final _codeCtrl = TextEditingController();
  final _matchingCtrl = TextEditingController();
  bool _installing = false;
  String? _result;

  @override
  void dispose() {
    _codeCtrl.dispose();
    _matchingCtrl.dispose();
    super.dispose();
  }

  Future<void> _install() async {
    final parsed = parseActivationCode(_codeCtrl.text,
        matchingIdIfBare: _matchingCtrl.text);
    if (parsed == null) {
      setState(() => _result =
          'That doesn\'t look like a valid activation code. Use the full '
          '"LPA:1\$smdp.address\$matchingId" string, or enter the SM-DP+ '
          'address above and the matching ID below.');
      return;
    }
    setState(() {
      _installing = true;
      _result = null;
    });
    AppLog.add('Installing eSIM profile via ${parsed.smdpAddress}');
    final res = await Native.installActivationCode(parsed.raw);
    setState(() {
      _installing = false;
      _result = res;
    });
    AppLog.add('Install result: $res');
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Install via activation code'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: ListView(
            children: [
              GlassPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                        'This uses the standard Android eSIM installer '
                        '(the same system API every carrier app uses). '
                        'Paste the full activation code, or fill in both '
                        'fields separately.',
                        style: TextStyle(color: Colors.white70, fontSize: 13)),
                    const SizedBox(height: 16),
                    const Text('Activation code or SM-DP+ address',
                        style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 6),
                    GlassTextField(
                        controller: _codeCtrl,
                        hint: r'LPA:1$smdp.example.com$MATCHINGID'),
                    const SizedBox(height: 14),
                    const Text('Matching ID (only if not already in the code above)',
                        style: TextStyle(color: Colors.white)),
                    const SizedBox(height: 6),
                    GlassTextField(controller: _matchingCtrl, hint: 'Matching ID'),
                  ],
                ),
              ),
              const SizedBox(height: 18),
              if (_result != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 14),
                  child: GlassPanel(
                    child: Text(_result!,
                        style: const TextStyle(color: Colors.white)),
                  ),
                ),
              PrimaryButton(
                label: 'Install eSIM profile',
                loading: _installing,
                onPressed: _installing ? null : _install,
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class WebUiScreen extends StatefulWidget {
  const WebUiScreen({super.key});

  @override
  State<WebUiScreen> createState() => _WebUiScreenState();
}

class _WebUiScreenState extends State<WebUiScreen> {
  final _addrCtrl =
      TextEditingController(text: defaultBluetoothPanGatewayGuess);
  String? _error;
  bool _scanning = false;

  @override
  void dispose() {
    _addrCtrl.dispose();
    super.dispose();
  }

  void _open() {
    final url = buildWebUiUrl(_addrCtrl.text);
    if (url == null) {
      setState(() => _error = 'Enter a valid address, e.g. 192.168.44.1');
      return;
    }
    AppLog.add('Opening unit web UI at $url');
    Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => WebViewPage(url: url)));
  }

  Future<void> _autoDetect() async {
    setState(() {
      _scanning = true;
      _error = null;
    });
    AppLog.add('Scanning 192.168.44.0/24 for an open port 443 (ODU web UI)');
    List<String> found;
    try {
      found = await findHostsWithOpenPort();
    } catch (e) {
      found = const [];
    }
    if (!mounted) return;
    setState(() => _scanning = false);

    if (found.isEmpty) {
      setState(() => _error =
          'No device with the web UI port open was found on 192.168.44.0/24. '
          'Make sure Bluetooth tethering is on and connected, then try again.');
      AppLog.add('Auto-detect found no hosts');
      return;
    }
    if (found.length == 1) {
      setState(() => _addrCtrl.text = found.first);
      AppLog.add('Auto-detect found ${found.first}');
      return;
    }
    AppLog.add('Auto-detect found ${found.length} hosts: ${found.join(', ')}');
    if (!mounted) return;
    final chosen = await showDialog<String>(
      context: context,
      builder: (context) => _IpPickerDialog(ips: found),
    );
    if (chosen != null) setState(() => _addrCtrl.text = chosen);
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Open unit web UI'),
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              GlassPanel(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text(
                        'Once connected over Bluetooth, the unit\'s admin '
                        'page is usually reachable at this address. Edit it '
                        'yourself, or let the app find it automatically.',
                        style: TextStyle(color: Colors.white70, fontSize: 13)),
                    const SizedBox(height: 12),
                    GlassTextField(
                        controller: _addrCtrl, hint: '192.168.44.1'),
                  ],
                ),
              ),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(top: 10),
                  child: Text(_error!,
                      style: const TextStyle(color: Colors.redAccent)),
                ),
              const SizedBox(height: 12),
              GlassTile(
                onTap: _scanning ? null : _autoDetect,
                enabled: !_scanning,
                child: Row(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    if (_scanning)
                      const SizedBox(
                          width: 16,
                          height: 16,
                          child: CircularProgressIndicator(
                              strokeWidth: 2, color: Colors.white))
                    else
                      const Icon(Icons.search, color: Colors.white, size: 18),
                    const SizedBox(width: 8),
                    Text(_scanning ? 'Scanning…' : 'Auto-detect ODU address',
                        style: const TextStyle(color: Colors.white)),
                  ],
                ),
              ),
              const SizedBox(height: 10),
              PrimaryButton(label: 'Open', onPressed: _open),
            ],
          ),
        ),
      ),
    );
  }
}

class WebViewPage extends StatefulWidget {
  final String url;
  const WebViewPage({super.key, required this.url});

  @override
  State<WebViewPage> createState() => _WebViewPageState();
}

class _WebViewPageState extends State<WebViewPage> {
  late final WebViewController _controller;

  @override
  void initState() {
    super.initState();
    _controller = WebViewController()
      ..setJavaScriptMode(JavaScriptMode.unrestricted)
      ..loadRequest(Uri.parse(widget.url));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text(widget.url)),
      body: WebViewWidget(controller: _controller),
    );
  }
}

class LogScreen extends StatelessWidget {
  const LogScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final text = formatLog(AppLog.entries);
    return Scaffold(
      backgroundColor: Colors.transparent,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: const Text('Activity log'),
        actions: [
          IconButton(
            icon: const Icon(Icons.copy),
            onPressed: () {
              Clipboard.setData(ClipboardData(text: text));
              showGlassSnack(context, 'Log copied to clipboard');
            },
          ),
        ],
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(16),
          child: GlassPanel(
            child: SingleChildScrollView(
              child: SelectableText(
                text.isEmpty ? 'Nothing logged yet.' : text,
                style: const TextStyle(
                    color: Colors.white, fontFamily: 'monospace', fontSize: 12),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class _IpPickerDialog extends StatelessWidget {
  final List<String> ips;
  const _IpPickerDialog({required this.ips});

  @override
  Widget build(BuildContext context) {
    return Dialog(
      backgroundColor: Colors.transparent,
      child: GlassPanel(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Multiple devices found',
                style: TextStyle(
                    color: Colors.white,
                    fontSize: 15,
                    fontWeight: FontWeight.w700)),
            const SizedBox(height: 10),
            for (final ip in ips)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: GlassTile(
                  onTap: () => Navigator.of(context).pop(ip),
                  child: Text(ip, style: const TextStyle(color: Colors.white)),
                ),
              ),
          ],
        ),
      ),
    );
  }
}
