// Pure-Dart logic: no Flutter imports, so this is fully unit-testable.

/// Parsed details read off a unit's label QR code.
class UnitDetails {
  final String? mac;
  final String? model;
  final String? eid;

  const UnitDetails({this.mac, this.model, this.eid});

  bool get hasMac => mac != null && mac!.isNotEmpty;

  @override
  String toString() => 'UnitDetails(mac: $mac, model: $model, eid: $eid)';
}

/// Parses a unit label QR payload. Handles the XML-tag label format used on
/// ODU units, e.g.:
///   <MFRNAME>HFCL</MFRNAME> <MODELNO>JODU52540</MODELNO>
///   <SRNO>RHFODBL00085804</SRNO> <IMEI>353799913558045</IMEI>
///   <EAN>8908023615008</EAN> <EID>8904...503782</EID>
///   <BT MAC>0006AEAA8D97</BT MAC>
/// as well as a looser "key=value" style, or a raw MAC address by itself.
/// Returns an [UnitDetails] with whatever fields were found (any may be null).
UnitDetails parseUnitQr(String raw) {
  final text = raw.trim();
  if (text.isEmpty) return const UnitDetails();

  String? mac = _findMac(text);
  String? model = _findTag(text, const ['MODELNO', 'MODEL']) ??
      _findField(text, const ['model', 'mdl']);
  String? eid = _findTag(text, const ['EID']) ?? _findField(text, const ['eid']);

  // A bare MAC address with nothing else.
  if (mac == null && model == null && eid == null) {
    final bareMac = normalizeMac(text);
    if (bareMac != null) mac = bareMac;
  }

  return UnitDetails(mac: mac, model: model, eid: eid);
}

/// Extracts the value of an XML-style "<TAG>value</TAG>" field. Tag names
/// may contain a space (e.g. "BT MAC"). Case-insensitive.
String? _findTag(String text, List<String> tags) {
  for (final tag in tags) {
    final escaped = RegExp.escape(tag);
    final pattern =
        RegExp('<$escaped>\\s*([^<]*?)\\s*</$escaped>', caseSensitive: false);
    final m = pattern.firstMatch(text);
    final value = m?.group(1)?.trim();
    if (value != null && value.isNotEmpty) return value;
  }
  return null;
}

String? _findField(String text, List<String> keys) {
  for (final key in keys) {
    final pattern = RegExp('$key\\s*[:=]\\s*([^;,\\s]+)', caseSensitive: false);
    final m = pattern.firstMatch(text);
    if (m != null) return m.group(1);
  }
  return null;
}

/// Finds the unit's MAC address, preferring an explicit "BT MAC"/"MAC ID"
/// tag or key over a loose scan. A loose scan only looks for a
/// colon/dash-separated address — never a bare 12-hex-digit run — so it
/// can't accidentally match inside a longer plain-digit field such as an
/// IMEI (15 digits) or EID (32 digits), which are also valid hex
/// characters and would otherwise be matched by mistake.
String? _findMac(String text) {
  final tagMac = _findTag(text, const ['BT MAC', 'MAC ID', 'PRIMARY MAC ID', 'MAC']);
  if (tagMac != null) {
    final n = normalizeMac(tagMac);
    if (n != null) return n;
  }

  final kvMac = _findField(text, const ['mac']);
  if (kvMac != null) {
    final n = normalizeMac(kvMac);
    if (n != null) return n;
  }

  final colonForm =
      RegExp(r'([0-9A-Fa-f]{2}[:\-]){5}[0-9A-Fa-f]{2}').firstMatch(text);
  if (colonForm != null) return normalizeMac(colonForm.group(0)!);

  return null;
}

/// Normalizes any of "BCF87EEAD787", "bc:f8:7e:ea:d7:87", "BC-F8-7E-EA-D7-87"
/// into canonical "BC:F8:7E:EA:D7:87". Returns null if not a valid MAC.
String? normalizeMac(String input) {
  final hex = input.replaceAll(RegExp(r'[^0-9A-Fa-f]'), '');
  if (hex.length != 12) return null;
  final upper = hex.toUpperCase();
  final parts = <String>[];
  for (var i = 0; i < 12; i += 2) {
    parts.add(upper.substring(i, i + 2));
  }
  return parts.join(':');
}

/// Result of validating an eSIM activation code.
class ActivationCode {
  final String raw;
  final String smdpAddress;
  final String matchingId;
  final String? confirmCode;

  const ActivationCode({
    required this.raw,
    required this.smdpAddress,
    required this.matchingId,
    this.confirmCode,
  });
}

/// Parses/validates a GSMA RSP activation code.
///
/// Accepts either the full "LPA:1$smdp.address$matchingId" form (optionally
/// with a third "$confirmCode" segment), or a bare "smdp.address" paired
/// with a separately-entered matching id (pass [matchingIdIfBare]).
///
/// Returns null if the input cannot be parsed into a usable activation code.
ActivationCode? parseActivationCode(String input, {String? matchingIdIfBare}) {
  final text = input.trim();
  if (text.isEmpty) return null;

  if (text.toUpperCase().startsWith('LPA:1\$') || text.startsWith('1\$')) {
    final body = text.toUpperCase().startsWith('LPA:1\$')
        ? text.substring(6)
        : text.substring(2);
    final parts = body.split('\$');
    if (parts.length < 2) return null;
    final smdp = parts[0].trim();
    final matching = parts[1].trim();
    if (!_looksLikeHost(smdp) || matching.isEmpty) return null;
    final confirm = parts.length > 2 && parts[2].trim().isNotEmpty
        ? parts[2].trim()
        : null;
    return ActivationCode(
      raw: 'LPA:1\$$smdp\$$matching${confirm != null ? '\$$confirm' : ''}',
      smdpAddress: smdp,
      matchingId: matching,
      confirmCode: confirm,
    );
  }

  // Bare SM-DP+ address + separately supplied matching id.
  if (_looksLikeHost(text) &&
      matchingIdIfBare != null &&
      matchingIdIfBare.trim().isNotEmpty) {
    final matching = matchingIdIfBare.trim();
    return ActivationCode(
      raw: 'LPA:1\$$text\$$matching',
      smdpAddress: text,
      matchingId: matching,
    );
  }

  return null;
}

bool _looksLikeHost(String s) {
  if (s.isEmpty || s.length > 253) return false;
  return RegExp(r'^[A-Za-z0-9.\-]+\.[A-Za-z]{2,}$').hasMatch(s);
}

/// Validates a plain IPv4 address or "host[:port]" string for the manual
/// "open unit web UI" field. Returns a cleaned-up URL (http://...) or null.
String? buildWebUiUrl(String input) {
  var text = input.trim();
  if (text.isEmpty) return null;
  if (!text.startsWith('http://') && !text.startsWith('https://')) {
    text = 'http://$text';
  }
  final uri = Uri.tryParse(text);
  if (uri == null || uri.host.isEmpty) return null;
  return uri.toString();
}

/// The AOSP default subnet for a phone acting as a Bluetooth PAN (NAP)
/// server; most devices hand the tethered peer a gateway at this address.
/// It's a generic Android platform default, not vendor-specific — used only
/// as a pre-filled guess the user can edit.
const String defaultBluetoothPanGatewayGuess = '192.168.44.1';

/// A single share-able log line.
class LogEntry {
  final DateTime time;
  final String message;

  const LogEntry(this.time, this.message);

  String format() {
    final t = time.toIso8601String();
    return '[$t] $message';
  }
}

String formatLog(List<LogEntry> entries) => entries.map((e) => e.format()).join('\n');
