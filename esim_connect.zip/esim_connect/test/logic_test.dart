import 'package:flutter_test/flutter_test.dart';
import 'package:esim_connect/logic.dart';

void main() {
  group('normalizeMac', () {
    test('colon separated lowercase', () {
      expect(normalizeMac('bc:f8:7e:ea:d7:87'), 'BC:F8:7E:EA:D7:87');
    });
    test('no separators', () {
      expect(normalizeMac('BCF87EEAD787'), 'BC:F8:7E:EA:D7:87');
    });
    test('dash separated', () {
      expect(normalizeMac('BC-F8-7E-EA-D7-87'), 'BC:F8:7E:EA:D7:87');
    });
    test('invalid length returns null', () {
      expect(normalizeMac('BCF87E'), isNull);
    });
  });

  group('parseUnitQr', () {
    test('key=value style with semicolons', () {
      final d = parseUnitQr(
          'label: mac=BCF87EEAD787 model=JODU52240 eid=890490322222223393');
      expect(d.mac, 'BC:F8:7E:EA:D7:87');
      expect(d.model, 'JODU52240');
      expect(d.eid, '890490322222223393');
    });
    test('colon style mac with separators', () {
      final d = parseUnitQr('mac: BC:F8:7E:EA:D7:87; model: JODU52240');
      expect(d.mac, 'BC:F8:7E:EA:D7:87');
      expect(d.model, 'JODU52240');
    });
    test('bare mac only', () {
      final d = parseUnitQr('BCF87EEAD787');
      expect(d.mac, 'BC:F8:7E:EA:D7:87');
      expect(d.model, isNull);
    });
    test('empty input', () {
      final d = parseUnitQr('  ');
      expect(d.hasMac, isFalse);
    });
    test('real ODU XML label: BT MAC tag, not the IMEI digits', () {
      const xml = '<?xml version="1.0" encoding="UTF-8"?> '
          '<!--Document created by: RJIL http://jio.com--> '
          '<MFRNAME>HFCL</MFRNAME> <MODELNO>JODU52540</MODELNO> '
          '<SRNO>RHFODBL00085804</SRNO> <IMEI>353799913558045</IMEI> '
          '<EAN>8908023615008</EAN> '
          '<EID>890440475670990100000252503782</EID> '
          '<BT MAC>0006AEAA8D97</BT MAC>';
      final d = parseUnitQr(xml);
      expect(d.mac, '00:06:AE:AA:8D:97');
      expect(d.mac, isNot(contains('35:37:99')));
      expect(d.model, 'JODU52540');
      expect(d.eid, '890440475670990100000252503782');
    });
  });

  group('parseActivationCode', () {
    test('full LPA string', () {
      final a = parseActivationCode(r'LPA:1$smdp.example.com$ABC123XYZ');
      expect(a, isNotNull);
      expect(a!.smdpAddress, 'smdp.example.com');
      expect(a.matchingId, 'ABC123XYZ');
      expect(a.confirmCode, isNull);
    });
    test('full LPA string with confirm code', () {
      final a = parseActivationCode(r'LPA:1$smdp.example.com$ABC123$999999');
      expect(a, isNotNull);
      expect(a!.confirmCode, '999999');
    });
    test('bare smdp + separate matching id', () {
      final a = parseActivationCode('smdp.example.com',
          matchingIdIfBare: 'ABC123XYZ');
      expect(a, isNotNull);
      expect(a!.raw, r'LPA:1$smdp.example.com$ABC123XYZ');
    });
    test('garbage input returns null', () {
      expect(parseActivationCode('not an activation code'), isNull);
    });
    test('missing matching id for bare host returns null', () {
      expect(parseActivationCode('smdp.example.com'), isNull);
    });
  });

  group('buildWebUiUrl', () {
    test('bare ip gets http scheme', () {
      expect(buildWebUiUrl('192.168.44.1'), 'http://192.168.44.1');
    });
    test('existing scheme kept', () {
      expect(buildWebUiUrl('https://192.168.44.1:8443'),
          'https://192.168.44.1:8443');
    });
    test('empty input returns null', () {
      expect(buildWebUiUrl('   '), isNull);
    });
  });

  group('formatLog', () {
    test('formats entries in order', () {
      final entries = [
        LogEntry(DateTime.utc(2026, 1, 1, 10, 0, 0), 'started'),
        LogEntry(DateTime.utc(2026, 1, 1, 10, 0, 5), 'connected'),
      ];
      final out = formatLog(entries);
      expect(out.contains('started'), isTrue);
      expect(out.contains('connected'), isTrue);
      expect(out.split('\n').length, 2);
    });
  });
}
