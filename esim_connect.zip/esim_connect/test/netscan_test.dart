import 'package:flutter_test/flutter_test.dart';
import 'package:esim_connect/netscan.dart';

void main() {
  group('scanTargets', () {
    test('builds full /24 range by default', () {
      final targets = scanTargets('192.168.44');
      expect(targets.length, 254);
      expect(targets.first, '192.168.44.1');
      expect(targets.last, '192.168.44.254');
    });
    test('respects custom start/end', () {
      final targets = scanTargets('10.0.0', start: 5, end: 7);
      expect(targets, ['10.0.0.5', '10.0.0.6', '10.0.0.7']);
    });
  });
}
