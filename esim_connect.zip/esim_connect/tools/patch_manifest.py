#!/usr/bin/env python3
"""Patch the Flutter-generated android/ project for esim_connect.

Usage: python3 tools/patch_manifest.py

Repeat-safe: always starts from AndroidManifest.xml.orig (a copy is made on
first run). Does NOT need a tv/mobile argument — this app is mobile-only.

What it does:
  1. Backs up AndroidManifest.xml -> AndroidManifest.xml.orig on first run,
     then always rewrites AndroidManifest.xml from the .orig copy.
  2. Sets android:label.
  3. Copies launcher icons into android/app/src/main/res.
  4. Writes MainActivity.kt from tools/MainActivity.kt.tpl (MethodChannels:
     env, bt, esim, settings).
  5. Adds only the permissions this app actually needs.
"""
import os
import re
import shutil
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ANDROID = os.path.join(ROOT, "android")
APP_LABEL = "eSIM Connect"
PACKAGE = "com.maraj.esim_connect"

PERMISSIONS = [
    "android.permission.BLUETOOTH",  # maxSdkVersion 30, legacy devices
    "android.permission.BLUETOOTH_ADMIN",
    "android.permission.BLUETOOTH_CONNECT",
    "android.permission.BLUETOOTH_SCAN",
    "android.permission.ACCESS_FINE_LOCATION",  # required for BT scan <= Android 11
    "android.permission.CAMERA",
    "android.permission.INTERNET",
    "android.permission.ACCESS_NETWORK_STATE",
]


def main():
    manifest_dir = os.path.join(ANDROID, "app", "src", "main")
    manifest = os.path.join(manifest_dir, "AndroidManifest.xml")
    orig = manifest + ".orig"
    if not os.path.exists(manifest_dir):
        sys.exit("ERROR: android/app/src/main not found — run `flutter create` first")

    if not os.path.exists(orig):
        shutil.copyfile(manifest, orig)
    with open(orig, encoding="utf-8") as f:
        xml = f.read()

    # permissions
    perm_block = "".join(
        f'    <uses-permission android:name="{p}"'
        + (' android:maxSdkVersion="30"' if p == "android.permission.BLUETOOTH" else "")
        + " />\n"
        for p in PERMISSIONS
    )
    # camera is used if available, but the app works fully without one
    # (manual MAC entry), so don't let Play filter out cameraless devices
    feature_block = '    <uses-feature android:name="android.hardware.camera" android:required="false" />\n'

    if "<application" not in xml:
        sys.exit("ERROR: <application> tag not found in manifest")
    xml = xml.replace("<application", perm_block + feature_block + "<application", 1)

    # label
    if 'android:label="' in xml:
        xml = re.sub(r'android:label="[^"]*"', f'android:label="{APP_LABEL}"', xml, count=1)
    else:
        xml = xml.replace("<application", f'<application android:label="{APP_LABEL}"', 1)

    with open(manifest, "w", encoding="utf-8") as f:
        f.write(xml)
    print("manifest patched:", manifest)

    # icons
    icon_src = os.path.join(ROOT, "assets", "android_icons")
    res_dst = os.path.join(manifest_dir, "res")
    for density in ("mdpi", "hdpi", "xhdpi", "xxhdpi", "xxxhdpi"):
        src = os.path.join(icon_src, f"mipmap-{density}", "ic_launcher.png")
        dst_dir = os.path.join(res_dst, f"mipmap-{density}")
        if os.path.exists(src):
            os.makedirs(dst_dir, exist_ok=True)
            shutil.copyfile(src, os.path.join(dst_dir, "ic_launcher.png"))
    print("icons copied")

    # MainActivity.kt
    with open(os.path.join(ROOT, "tools", "MainActivity.kt.tpl"), encoding="utf-8") as f:
        kt = f.read().replace("__PACKAGE__", PACKAGE)
    kt_dir = os.path.join(
        manifest_dir, "kotlin", *PACKAGE.split(".")
    )
    os.makedirs(kt_dir, exist_ok=True)
    with open(os.path.join(kt_dir, "MainActivity.kt"), "w", encoding="utf-8") as f:
        f.write(kt)
    print("MainActivity.kt written:", os.path.join(kt_dir, "MainActivity.kt"))
    print("done")


if __name__ == "__main__":
    main()
