package __PACKAGE__

import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.bluetooth.BluetoothDevice
import android.bluetooth.BluetoothManager
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.os.Build
import android.os.Bundle
import android.telephony.euicc.DownloadableSubscription
import android.telephony.euicc.EuiccManager
import androidx.annotation.NonNull
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {
    private val envChannel = "env"
    private val btChannel = "bt"
    private val esimChannel = "esim"
    private val settingsChannel = "settings"
    private val esimInstallAction = "__PACKAGE__.ESIM_INSTALL_RESULT"

    private var discoveryReceiver: BroadcastReceiver? = null
    private var methodChannelBt: MethodChannel? = null
    private var pendingEsimResult: MethodChannel.Result? = null
    private var esimReceiver: BroadcastReceiver? = null

    override fun configureFlutterEngine(@NonNull engine: FlutterEngine) {
        super.configureFlutterEngine(engine)

        MethodChannel(engine.dartExecutor.binaryMessenger, envChannel).setMethodCallHandler { call, result ->
            when (call.method) {
                "lowEnd" -> {
                    val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                    val memInfo = android.app.ActivityManager.MemoryInfo()
                    am.getMemoryInfo(memInfo)
                    result.success(am.isLowRamDevice || am.memoryClass < 192)
                }
                else -> result.notImplemented()
            }
        }

        val bt = MethodChannel(engine.dartExecutor.binaryMessenger, btChannel)
        methodChannelBt = bt
        bt.setMethodCallHandler { call, result ->
            val adapter = (getSystemService(Context.BLUETOOTH_SERVICE) as? BluetoothManager)?.adapter
            when (call.method) {
                "bondedDevices" -> {
                    val list = ArrayList<Map<String, String>>()
                    if (adapter != null && adapter.isEnabled) {
                        for (d in adapter.bondedDevices) {
                            list.add(mapOf("name" to (d.name ?: "Unknown"), "mac" to d.address))
                        }
                    }
                    result.success(list)
                }
                "startScan" -> {
                    if (adapter == null || !adapter.isEnabled) {
                        result.success(false)
                        return@setMethodCallHandler
                    }
                    stopDiscoveryReceiver()
                    val receiver = object : BroadcastReceiver() {
                        override fun onReceive(context: Context, intent: Intent) {
                            if (intent.action == BluetoothDevice.ACTION_FOUND) {
                                val device =
                                    intent.getParcelableExtra<BluetoothDevice>(BluetoothDevice.EXTRA_DEVICE)
                                        ?: return
                                methodChannelBt?.invokeMethod(
                                    "deviceFound",
                                    mapOf("name" to (device.name ?: "Unknown device"), "mac" to device.address)
                                )
                            }
                        }
                    }
                    discoveryReceiver = receiver
                    registerReceiver(receiver, IntentFilter(BluetoothDevice.ACTION_FOUND))
                    adapter.startDiscovery()
                    result.success(true)
                }
                "stopScan" -> {
                    adapter?.cancelDiscovery()
                    stopDiscoveryReceiver()
                    result.success(null)
                }
                "bond" -> {
                    val mac = call.argument<String>("mac")
                    if (adapter == null || mac == null) {
                        result.success(false)
                        return@setMethodCallHandler
                    }
                    try {
                        val device = adapter.getRemoteDevice(mac)
                        if (device.bondState == BluetoothDevice.BOND_BONDED) {
                            result.success(true)
                        } else {
                            result.success(device.createBond())
                        }
                    } catch (e: Exception) {
                        result.success(false)
                    }
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(engine.dartExecutor.binaryMessenger, settingsChannel).setMethodCallHandler { call, result ->
            when (call.method) {
                "openBluetoothTether" -> {
                    try {
                        startActivity(Intent().apply {
                            setClassName("com.android.settings", "com.android.settings.TetherSettings")
                        })
                    } catch (e: Exception) {
                        try {
                            startActivity(Intent(android.provider.Settings.ACTION_WIRELESS_SETTINGS))
                        } catch (e2: Exception) {
                            // nothing more we can do
                        }
                    }
                    result.success(null)
                }
                else -> result.notImplemented()
            }
        }

        MethodChannel(engine.dartExecutor.binaryMessenger, esimChannel).setMethodCallHandler { call, result ->
            val euicc = getSystemService(Context.EUICC_SERVICE) as? EuiccManager
            when (call.method) {
                "isSupported" -> result.success(euicc?.isEnabled ?: false)
                "install" -> {
                    val code = call.argument<String>("code")
                    if (euicc == null || !euicc.isEnabled) {
                        result.success("This device does not support eSIM, or eSIM is disabled.")
                        return@setMethodCallHandler
                    }
                    if (code == null) {
                        result.success("No activation code provided.")
                        return@setMethodCallHandler
                    }
                    pendingEsimResult = result
                    registerEsimReceiver()
                    val subscription = DownloadableSubscription.forActivationCode(code)
                    val intent = Intent(esimInstallAction).setPackage(packageName)
                    val flags = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S)
                        android.app.PendingIntent.FLAG_MUTABLE else 0
                    val pending = android.app.PendingIntent.getBroadcast(this, 0, intent, flags)
                    euicc.downloadSubscription(subscription, true, pending)
                }
                else -> result.notImplemented()
            }
        }
    }

    private fun registerEsimReceiver() {
        if (esimReceiver != null) return
        val receiver = object : BroadcastReceiver() {
            override fun onReceive(context: Context, intent: Intent) {
                val code = resultCode
                val msg = when (code) {
                    EuiccManager.EMBEDDED_SUBSCRIPTION_RESULT_OK -> "Profile installed successfully."
                    EuiccManager.EMBEDDED_SUBSCRIPTION_RESULT_RESOLVABLE_ERROR ->
                        "The system needs you to confirm something — check for a system prompt/notification."
                    else -> "Install did not complete (code $code)."
                }
                pendingEsimResult?.success(msg)
                pendingEsimResult = null
            }
        }
        esimReceiver = receiver
        val filter = IntentFilter(esimInstallAction)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            registerReceiver(receiver, filter, Context.RECEIVER_EXPORTED)
        } else {
            registerReceiver(receiver, filter)
        }
    }

    private fun stopDiscoveryReceiver() {
        discoveryReceiver?.let {
            try { unregisterReceiver(it) } catch (e: Exception) {}
        }
        discoveryReceiver = null
    }

    override fun onDestroy() {
        stopDiscoveryReceiver()
        esimReceiver?.let {
            try { unregisterReceiver(it) } catch (e: Exception) {}
        }
        super.onDestroy()
    }
}
