# eSIM Connect

A mobile-only Flutter app to scan an ODCPE unit's label QR code, connect to
it over Bluetooth, open its local web admin UI, and install an eSIM profile
via the standard Android activation-code flow.

## What's real vs. a stub

- **Install via activation code** — fully implemented using Android's own
  `EuiccManager.downloadSubscription()` (the same public system API every
  carrier app uses). Give it a full `LPA:1$smdp$matchingId` string, or the
  SM-DP+ address and matching ID separately.
- **Scan QR, Bluetooth connect, open unit web UI, tether settings, log** —
  fully implemented with standard Android APIs (classic Bluetooth bonding,
  `WebView`, `Settings` intents).
- **Automatically fetching an activation code from a specific carrier's
  unit/server** is *not* implemented. That would require that carrier's own
  proprietary device/server protocol, which this app does not replicate.
  Use the manual activation-code screen instead.
- **Turning Bluetooth tethering on programmatically** is not possible from a
  normal sideloaded app — Android requires a privileged system permission
  for that (`TETHER_PRIVILEGED`) that a regular APK cannot hold. The app
  instead opens the system's own Bluetooth tethering switch for you to flip.
- The eSIM install result handling (reading the system's broadcast result
  code) follows the documented `EuiccManager` pattern but has **not** been
  compiled or run — this environment has no Flutter/Android SDK. Please
  treat the first CI build as the first real compile, and test the eSIM
  install step carefully on a real device before relying on it.
- The default web-UI address (`192.168.44.1`) is AOSP's generic default
  subnet for a Bluetooth PAN connection, not anything device-specific — it's
  just a pre-filled guess; edit it if your unit uses a different address.

## Project structure

- `lib/logic.dart` — pure-Dart parsing/validation (QR payload, activation
  codes, addresses), unit-tested in `test/`.
- `lib/core.dart` — MethodChannel bridge to the native Android side.
- `lib/glass.dart`, `lib/ui.dart` — shared liquid-glass widgets.
- `lib/mobile.dart` — all screens.
- `lib/pages.dart`, `lib/legal.dart` — About & Legal.
- `tools/patch_manifest.py` — patches the Flutter-generated `android/`
  project (permissions, label, icons, `MainActivity.kt`). Repeat-safe.
- `tools/MainActivity.kt.tpl` — native Bluetooth/eSIM/settings code.
- `tools/esim_connect-sideload.jks` — this app's own sideload signing key
  (password `sideload`). It's public — fine for installing/updating on your
  own device, not for anything you'd publish to a store.

## Running the GitHub Actions build

1. Create a new (private is fine) GitHub repo.
2. Put `build-apk.yml` in `.github/workflows/`.
3. Upload `esim_connect.zip` to the repo root.
4. Push. The workflow unzips the project, runs `flutter create`, patches
   the manifest, builds, signs, and publishes a GitHub Release with the
   APKs (per-ABI + universal).
5. Download the APK from the repo's **Releases** tab.

### Signing

- With no repo secrets set, every build is signed with the bundled public
  sideload key — same key every time, so updates install cleanly over each
  other.
- To use your own private key instead (e.g. before publishing anywhere),
  add repo secrets `KEYSTORE_BASE64` (base64 of your `.jks`),
  `KEYSTORE_PASSWORD`, and `KEY_ALIAS`.

## Permissions requested

Bluetooth (classic + BLE triplet for Android 12+), location (required by
Android for Bluetooth scanning pre-Android 12), camera (QR scan), internet
and network state (WebView + connectivity checks). No analytics, no ads, no
background services.
