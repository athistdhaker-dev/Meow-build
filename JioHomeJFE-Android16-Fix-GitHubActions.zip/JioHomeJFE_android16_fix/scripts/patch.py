#!/usr/bin/env python3
import re
import shutil
from pathlib import Path
import xml.etree.ElementTree as ET

ROOT = Path(__file__).resolve().parents[1]
DECODED = ROOT / 'work' / 'decoded'
PATCHES = ROOT / 'patches' / 'smali'

ANDROID_NS = 'http://schemas.android.com/apk/res/android'
ET.register_namespace('android', ANDROID_NS)


def add_manifest_permissions():
    p = DECODED / 'AndroidManifest.xml'
    text = p.read_text(encoding='utf-8')
    # Apktool's decoded manifest normally has an android namespace and readable XML.
    root = ET.fromstring(text)
    existing = {e.get(f'{{{ANDROID_NS}}}name') for e in root.findall('uses-permission')}
    permissions = [
        'android.permission.BLUETOOTH_SCAN',
        'android.permission.BLUETOOTH_CONNECT',
        'android.permission.BLUETOOTH_ADVERTISE',
        'android.permission.ACCESS_FINE_LOCATION',
        'android.permission.CAMERA',
    ]
    for perm in permissions:
        if perm not in existing:
            e = ET.Element('uses-permission')
            e.set(f'{{{ANDROID_NS}}}name', perm)
            # Keep uses-permission entries before <application> for compatibility with old tooling.
            root.insert(0, e)
    p.write_text(ET.tostring(root, encoding='unicode'), encoding='utf-8')


def copy_helper_smali():
    # Put helpers in the primary smali directory. Apktool accepts new classes here.
    out = DECODED / 'smali' / 'com' / 'jio' / 'home' / 'jfe' / 'compat'
    out.mkdir(parents=True, exist_ok=True)
    src = PATCHES / 'com' / 'jio' / 'home' / 'jfe' / 'compat'
    for f in src.glob('*.smali'):
        shutil.copy2(f, out / f.name)


def find_class_file(descriptor: str):
    needle = descriptor + '\n'
    for smali_root in sorted(DECODED.glob('smali*')):
        if not smali_root.is_dir():
            continue
        for f in smali_root.rglob('*.smali'):
            try:
                head = f.read_text(encoding='utf-8', errors='ignore')[:400]
            except Exception:
                continue
            if needle in head or f' {descriptor}\n' in head:
                return f
    return None


def inject_permission_call(class_descriptor: str):
    f = find_class_file(class_descriptor)
    if not f:
        print(f'[WARN] class not found: {class_descriptor}')
        return False
    s = f.read_text(encoding='utf-8', errors='ignore')
    marker = 'Lcom/jio/home/jfe/compat/CompatPermissions;->ensure(Landroid/app/Activity;)V'
    if marker in s:
        print(f'[OK] permissions already patched: {f}')
        return True

    # Match the first onCreate(Bundle) method. Kotlin/Java access flags can vary.
    pat = re.compile(r'(\.method[^\n]*\bonCreate\(Landroid/os/Bundle;\)V\n)')
    m = pat.search(s)
    if not m:
        print(f'[WARN] onCreate(Bundle) not found: {f}')
        return False
    insert = (
        m.group(1)
        + '    invoke-static {p0}, Lcom/jio/home/jfe/compat/CompatPermissions;->ensure(Landroid/app/Activity;)V\n'
    )
    s = s[:m.start()] + insert + s[m.end():]
    f.write_text(s, encoding='utf-8')
    print(f'[OK] injected permission gate: {f}')
    return True


def patch_tether_start_calls():
    changed = 0
    for smali_root in sorted(DECODED.glob('smali*')):
        if not smali_root.is_dir():
            continue
        for f in smali_root.rglob('*.smali'):
            s = f.read_text(encoding='utf-8', errors='ignore')
            if 'com.android.settings.TetherSettings' not in s:
                continue
            # Only patch startActivity calls inside a method that contains the old Settings component.
            parts = re.split(r'(?=\.method\b)', s)
            out = []
            file_changed = False
            for part in parts:
                if 'com.android.settings.TetherSettings' not in part:
                    out.append(part)
                    continue
                # Preserve receiver + intent register. This is intentionally narrow.
                new_part, n = re.subn(
                    r'invoke-virtual \{([^,}]+), ([^}]+)\}, Landroid/app/Activity;->startActivity\(Landroid/content/Intent;\)V',
                    r'invoke-static {\1, \2}, Lcom/jio/home/jfe/compat/CompatTether;->open(Landroid/content/Context;Landroid/content/Intent;)V',
                    part,
                )
                if n:
                    changed += n
                    file_changed = True
                    part = new_part
                    print(f'[OK] tether fallback patched: {f} ({n} call(s))')
                out.append(part)
            if file_changed:
                f.write_text(''.join(out), encoding='utf-8')
    if not changed:
        print('[WARN] no TetherSettings startActivity call matched the safe patch pattern')
    return changed


def main():
    add_manifest_permissions()
    copy_helper_smali()
    inject_permission_call('Lcom/jio/esimprovisioning/presentation/view/activity/ESimScanQRCodeActivity;')
    inject_permission_call('Lcom/jio/home/jfe/stb/STBLaunchActivity;')
    patch_tether_start_calls()


if __name__ == '__main__':
    main()
