#!/usr/bin/env bash
set -euo pipefail
ROOT="$(cd "$(dirname "$0")/.." && pwd)"
APKTOOL="${ROOT}/tools/apktool.jar"
SIGNER="${ROOT}/tools/uber-apk-signer.jar"
INPUT="${ROOT}/input/app.apk"
WORK="${ROOT}/work"
OUT="${ROOT}/out"
rm -rf "$WORK" "$OUT"
mkdir -p "$WORK" "$OUT"

[[ -f "$APKTOOL" ]] || { echo "Missing tools/apktool.jar"; exit 1; }
[[ -f "$INPUT" ]] || { echo "Missing input/app.apk"; exit 1; }

echo '[1/4] Decoding APK with Apktool'
java -jar "$APKTOOL" d -f "$INPUT" -o "$WORK/decoded" --only-main-classes

echo '[2/4] Applying Android 12–16 compatibility patch'
python3 "$ROOT/scripts/patch.py"

echo '[3/4] Rebuilding APK'
java -jar "$APKTOOL" b "$WORK/decoded" -o "$OUT/JioHomeJFE-fixed-unsigned.apk" --use-aapt2

echo '[4/4] Zipalign + debug signing'
java -jar "$SIGNER" -a "$OUT/JioHomeJFE-fixed-unsigned.apk" --allowResign --overwrite
SIGNED=$(find "$OUT" -maxdepth 1 -type f -name '*-aligned-debugSigned.apk' -print -quit || true)
if [[ -z "$SIGNED" ]]; then
  SIGNED=$(find "$OUT" -maxdepth 1 -type f -name '*-debugSigned.apk' -print -quit || true)
fi
if [[ -z "$SIGNED" ]]; then
  echo 'Signer did not produce a debug-signed APK'; exit 1
fi
mv "$SIGNED" "$OUT/JioHomeJFE-fixed-signed.apk"
rm -f "$OUT/JioHomeJFE-fixed-unsigned.apk"

echo "Built: $OUT/JioHomeJFE-fixed-signed.apk"
