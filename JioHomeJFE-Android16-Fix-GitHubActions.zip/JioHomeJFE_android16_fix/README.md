# JioHomeJFE Android 12–16 compatibility patch

This repository is a reproducible patch/rebuild project for the supplied `JioHomeJFE_patched_v4-aligned-debugSigned.apk`.

## What the patch targets

- Adds modern Bluetooth runtime permissions (`BLUETOOTH_SCAN`, `BLUETOOTH_CONNECT`, `BLUETOOTH_ADVERTISE`).
- Requests BLE/camera permissions before QR/STB flows start.
- Requests legacy BLE location permission on Android 11 and below.
- Wraps the STB/eSIM `startActivity()` call sites that reference `com.android.settings.TetherSettings` so a missing/changed Settings component falls back to Android's public tether/Bluetooth settings instead of crashing.
- Keeps all original app code/resources unless the patcher changes the targeted compatibility points.

## Build with GitHub Actions

1. Put this ZIP's contents in a GitHub repository.
2. Run **Actions → Build patched JioHomeJFE APK → Run workflow**.
3. Download the `JioHomeJFE-fixed` artifact.

The workflow downloads Apktool 3.0.3 and Uber APK Signer 1.3.0 during the build. Apktool 3.0.3 is the last release in the Apktool 3.0 line. The build uses JDK 17.

## Local build

Requires Java 17+, Python 3 and network access:

```bash
chmod +x scripts/build.sh
./scripts/build.sh
```

Output: `out/JioHomeJFE-fixed.apk`

## Important

This is an APK-level compatibility patch, so the resulting APK is re-signed. If a Jio backend checks the original production certificate, authenticated backend features may still be rejected. The patch does not bypass server-side authorization.

The patch deliberately does not silently enable Bluetooth tethering or bypass Android system protections. It prevents known compatibility failures and opens the appropriate system settings when the old `TetherSettings` component is unavailable.
