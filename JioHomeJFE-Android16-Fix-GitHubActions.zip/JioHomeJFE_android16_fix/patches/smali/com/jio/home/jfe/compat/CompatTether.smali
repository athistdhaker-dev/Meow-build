.class public final Lcom/jio/home/jfe/compat/CompatTether;
.super Ljava/lang/Object;
.source "CompatTether.java"

.method public static open(Landroid/content/Context;Landroid/content/Intent;)V
    .locals 4

    if-eqz p0, :ret

    :try_start_0
    invoke-virtual {p0, p1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_0
    .catch Ljava/lang/Throwable; {:try_start_0 .. :try_end_0} :catch_0
    goto :ret

:catch_0
    move-exception v0

    :try_start_1
    new-instance v1, Landroid/content/Intent;
    const-string v2, "android.settings.TETHER_SETTINGS"
    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_1
    .catch Ljava/lang/Throwable; {:try_start_1 .. :try_end_1} :catch_1
    goto :ret

:catch_1
    move-exception v0

    :try_start_2
    new-instance v1, Landroid/content/Intent;
    const-string v2, "android.settings.BLUETOOTH_SETTINGS"
    invoke-direct {v1, v2}, Landroid/content/Intent;-><init>(Ljava/lang/String;)V
    invoke-virtual {p0, v1}, Landroid/content/Context;->startActivity(Landroid/content/Intent;)V
    :try_end_2
    .catch Ljava/lang/Throwable; {:try_start_2 .. :try_end_2} :catch_2
    goto :ret

:catch_2
    move-exception v0

:ret
    return-void
.end method
