.class public final Lcom/jio/home/jfe/compat/CompatPermissions;
.super Ljava/lang/Object;
.source "CompatPermissions.java"

.method public static ensure(Landroid/app/Activity;)V
    .locals 5

    if-eqz p0, :ret

    sget v0, Landroid/os/Build$VERSION;->SDK_INT:I
    const/16 v1, 0x1f
    if-lt v0, v1, :legacy

    const/4 v0, 0x4
    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "android.permission.CAMERA"
    const/4 v2, 0x0
    aput-object v1, v0, v2

    const-string v1, "android.permission.BLUETOOTH_SCAN"
    const/4 v2, 0x1
    aput-object v1, v0, v2

    const-string v1, "android.permission.BLUETOOTH_CONNECT"
    const/4 v2, 0x2
    aput-object v1, v0, v2

    const-string v1, "android.permission.BLUETOOTH_ADVERTISE"
    const/4 v2, 0x3
    aput-object v1, v0, v2

    const/16 v1, 0x515
    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V
    goto :ret

:legacy
    const/4 v0, 0x2
    new-array v0, v0, [Ljava/lang/String;

    const-string v1, "android.permission.CAMERA"
    const/4 v2, 0x0
    aput-object v1, v0, v2

    const-string v1, "android.permission.ACCESS_FINE_LOCATION"
    const/4 v2, 0x1
    aput-object v1, v0, v2

    const/16 v1, 0x515
    invoke-virtual {p0, v0, v1}, Landroid/app/Activity;->requestPermissions([Ljava/lang/String;I)V

:ret
    return-void
.end method
