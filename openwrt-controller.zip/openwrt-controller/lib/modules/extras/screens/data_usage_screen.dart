// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'dart:convert';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _DeviceUsage {
  _DeviceUsage(this.mac, this.name);
  final String mac;
  String name;
  double rx = 0;
  double tx = 0;
  double get total => rx + tx;
}

class _Bucket {
  const _Bucket(this.label, this.rx, this.tx);
  final String label;
  final double rx;
  final double tx;
}

/// Data usage history: per-device (nlbwmon) and per-interface daily/monthly
/// totals (vnstat).
class DataUsageScreen extends ConsumerStatefulWidget {
  const DataUsageScreen({super.key});

  @override
  ConsumerState<DataUsageScreen> createState() => _DataUsageScreenState();
}

class _DataUsageScreenState extends ConsumerState<DataUsageScreen> {
  static final RegExp _dateRe = RegExp(r'\d{4}-\d{2}-\d{2}');

  bool _checking = true;
  bool _loading = false;
  bool _installing = false;
  bool _hasNlbw = false;
  bool _hasVnstat = false;

  int _mode = 0; // 0 = per device, 1 = per interface
  String? _error;

  // Per device
  List<String> _periods = const [];
  String? _period;
  List<_DeviceUsage> _devices = const [];
  bool _deviceLoaded = false;

  // Per interface
  bool _monthly = false;
  String? _iface;
  Map<String, List<_Bucket>> _daily = const {};
  Map<String, List<_Bucket>> _months = const {};
  bool _ifaceLoaded = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _detect());
  }

  ExtrasShell get _shell => ExtrasShell(ref.read(appStateProvider));

  Future<void> _detect() async {
    setState(() {
      _checking = true;
      _error = null;
    });
    final out = await _shell.run(
      'command -v nlbw >/dev/null 2>&1 && echo NLBW=1 || echo NLBW=0; '
      'command -v vnstat >/dev/null 2>&1 && echo VNSTAT=1 || echo VNSTAT=0',
    );
    if (!mounted) return;
    final nlbw = out.contains('NLBW=1');
    final vn = out.contains('VNSTAT=1');
    setState(() {
      _hasNlbw = nlbw;
      _hasVnstat = vn;
      _checking = false;
      _deviceLoaded = false;
      _ifaceLoaded = false;
      if (_mode == 0 && !nlbw && vn) _mode = 1;
      if (_mode == 1 && !vn && nlbw) _mode = 0;
    });
    await _loadCurrent();
  }

  Future<void> _loadCurrent() async {
    if (_mode == 0 && _hasNlbw) {
      await _loadDevices();
    } else if (_mode == 1 && _hasVnstat) {
      await _loadInterfaces();
    }
  }

  // ── nlbwmon ──────────────────────────────────────────────────────────────
  Future<void> _loadDevices({String? period}) async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final shell = _shell;

    var periods = _periods;
    if (periods.isEmpty) {
      final list = await shell.run('nlbw -c list 2>&1; true');
      periods = _dateRe.allMatches(list).map((m) => m.group(0)!).toList();
    }
    final selected =
        period ?? _period ?? (periods.isEmpty ? null : periods.last);
    final topt = (selected != null && _dateRe.hasMatch(selected))
        ? '-t ${ExtrasShell.q(selected)}'
        : '';

    final out = await shell.run(
      'nlbw -c commit >/dev/null 2>&1; '
      'echo __JSON__; nlbw -c json -g mac $topt 2>&1; '
      'echo __LEASES__; cat /tmp/dhcp.leases 2>/dev/null; true',
    );
    if (!mounted) return;

    final jsonPart = out.contains('__LEASES__')
        ? out.substring(0, out.indexOf('__LEASES__'))
        : out;
    final leasePart = out.contains('__LEASES__')
        ? out.substring(out.indexOf('__LEASES__'))
        : '';

    final names = <String, String>{};
    for (final line in leasePart.split('\n')) {
      final p = line.trim().split(RegExp(r'\s+'));
      if (p.length >= 4 && ExtrasShell.isMac(p[1]) && p[3] != '*') {
        names[p[1].toUpperCase()] = p[3];
      }
    }

    final rows = <String, _DeviceUsage>{};
    String? err;
    try {
      final start = jsonPart.indexOf('{');
      final end = jsonPart.lastIndexOf('}');
      if (start < 0 || end <= start) {
        throw const FormatException('no json');
      }
      final obj = jsonDecode(jsonPart.substring(start, end + 1));
      if (obj is Map) {
        final cols = (obj['columns'] as List?)
                ?.map((e) => e.toString())
                .toList() ??
            const <String>[];
        final iMac = cols.indexOf('mac');
        final iRx = cols.indexOf('rx_bytes');
        final iTx = cols.indexOf('tx_bytes');
        final data = obj['data'];
        if (iMac >= 0 && iRx >= 0 && iTx >= 0 && data is List) {
          for (final row in data) {
            if (row is! List || row.length <= iMac) continue;
            final mac = row[iMac].toString().toUpperCase();
            final d = rows.putIfAbsent(
              mac,
              () => _DeviceUsage(mac, names[mac] ?? mac),
            );
            d.rx += (row[iRx] as num?)?.toDouble() ?? 0;
            d.tx += (row[iTx] as num?)?.toDouble() ?? 0;
          }
        }
      }
    } catch (_) {
      err = 'Could not read nlbwmon data. Make sure the nlbwmon service is '
          'running.';
    }

    final list = rows.values.where((d) => d.total > 0).toList()
      ..sort((a, b) => b.total.compareTo(a.total));

    setState(() {
      _periods = periods;
      _period = selected;
      _devices = list;
      _deviceLoaded = true;
      _loading = false;
      _error = err;
    });
  }

  // ── vnstat ───────────────────────────────────────────────────────────────
  Future<void> _loadInterfaces() async {
    setState(() {
      _loading = true;
      _error = null;
    });
    final out = await _shell.run(
      'echo __D__; vnstat --json d 2>/dev/null; '
      'echo __M__; vnstat --json m 2>/dev/null; true',
    );
    if (!mounted) return;

    Map<String, List<_Bucket>> parse(String text, bool monthly) {
      final result = <String, List<_Bucket>>{};
      final start = text.indexOf('{');
      final end = text.lastIndexOf('}');
      if (start < 0 || end <= start) return result;
      try {
        final obj = jsonDecode(text.substring(start, end + 1));
        final ifaces = (obj is Map ? obj['interfaces'] : null) as List?;
        for (final i in ifaces ?? const []) {
          if (i is! Map) continue;
          final name = (i['name'] ?? '').toString();
          final traffic = i['traffic'];
          final entries = (traffic is Map
                  ? (monthly ? traffic['month'] : traffic['day'])
                  : null) as List?;
          final buckets = <_Bucket>[];
          for (final e in entries ?? const []) {
            if (e is! Map) continue;
            final date = e['date'];
            String label = '';
            if (date is Map) {
              final y = date['year'];
              final m = (date['month'] ?? '').toString().padLeft(2, '0');
              final d = (date['day'] ?? '').toString().padLeft(2, '0');
              label = monthly ? '$y-$m' : '$m-$d';
            }
            buckets.add(
              _Bucket(
                label,
                (e['rx'] as num?)?.toDouble() ?? 0,
                (e['tx'] as num?)?.toDouble() ?? 0,
              ),
            );
          }
          if (name.isNotEmpty && name != 'lo') result[name] = buckets;
        }
      } catch (_) {}
      return result;
    }

    final dPart = out.contains('__M__')
        ? out.substring(0, out.indexOf('__M__'))
        : out;
    final mPart = out.contains('__M__')
        ? out.substring(out.indexOf('__M__'))
        : '';
    final daily = parse(dPart, false);
    final months = parse(mPart, true);

    String? pick = _iface;
    if (pick == null || !daily.containsKey(pick)) {
      double best = -1;
      for (final e in daily.entries) {
        final t = e.value.fold<double>(0, (a, b) => a + b.rx + b.tx);
        if (t > best) {
          best = t;
          pick = e.key;
        }
      }
    }

    setState(() {
      _daily = daily;
      _months = months;
      _iface = pick;
      _ifaceLoaded = true;
      _loading = false;
      if (daily.isEmpty) {
        _error = 'vnstat has no data yet. It needs a few minutes after '
            'installation to start collecting traffic.';
      }
    });
  }

  // ── install ──────────────────────────────────────────────────────────────
  Future<void> _install(String package, String service) async {
    setState(() => _installing = true);
    final shell = _shell;
    final res = await shell.installPackage(package);
    if (res.ok) {
      await shell.service(service, 'enable');
      await shell.service(service, 'start');
    }
    if (!mounted) return;
    setState(() => _installing = false);
    extrasToast(
      context,
      res.ok ? '$package installed and started' : 'Install failed: ${res.output}',
      error: !res.ok,
    );
    await _detect();
  }

  // ── UI ───────────────────────────────────────────────────────────────────
  Widget _summary(ThemeData theme, double rx, double tx) {
    final cs = theme.colorScheme;
    Widget tile(String label, double value, Color color, IconData icon) {
      return Expanded(
        child: Container(
          padding: const EdgeInsets.all(14),
          decoration: BoxDecoration(
            color: cs.surfaceContainerLow,
            borderRadius: BorderRadius.circular(20),
            border: Border.all(color: cs.outlineVariant),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  Icon(icon, size: 16, color: color),
                  const SizedBox(width: 6),
                  Text(
                    label,
                    style: theme.textTheme.labelMedium?.copyWith(color: color),
                  ),
                ],
              ),
              const SizedBox(height: 6),
              Text(
                extrasFormatBytes(value),
                style: theme.textTheme.titleLarge,
              ),
            ],
          ),
        ),
      );
    }

    return Row(
      children: [
        tile('Download', rx, cs.secondary, Icons.arrow_downward_rounded),
        const SizedBox(width: 10),
        tile('Upload', tx, cs.primary, Icons.arrow_upward_rounded),
      ],
    );
  }

  Widget _deviceView(ThemeData theme) {
    final cs = theme.colorScheme;
    final totalRx = _devices.fold<double>(0, (a, d) => a + d.rx);
    final totalTx = _devices.fold<double>(0, (a, d) => a + d.tx);
    final maxTotal = _devices.isEmpty ? 1.0 : _devices.first.total;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        if (_periods.isNotEmpty)
          DropdownButtonFormField<String>(
            initialValue: _periods.contains(_period) ? _period : null,
            decoration: const InputDecoration(
              labelText: 'Billing period starting',
              isDense: true,
            ),
            items: [
              for (final p in _periods.reversed)
                DropdownMenuItem(value: p, child: Text(p)),
            ],
            onChanged: _loading
                ? null
                : (v) {
                    if (v != null) _loadDevices(period: v);
                  },
          ),
        const SizedBox(height: 12),
        _summary(theme, totalRx, totalTx),
        const SizedBox(height: 16),
        Text(
          'TOP DEVICES',
          style: theme.textTheme.labelSmall?.copyWith(
            letterSpacing: 1.2,
            color: cs.onSurfaceVariant,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        if (_devices.isEmpty && _deviceLoaded)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('No traffic recorded for this period yet.'),
          ),
        for (final d in _devices)
          Card(
            child: Padding(
              padding: const EdgeInsets.all(14),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Expanded(
                        child: Text(
                          d.name,
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                          style: theme.textTheme.titleSmall,
                        ),
                      ),
                      Text(
                        extrasFormatBytes(d.total),
                        style: theme.textTheme.titleSmall,
                      ),
                    ],
                  ),
                  if (d.name != d.mac)
                    Text(
                      d.mac,
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: cs.onSurfaceVariant,
                      ),
                    ),
                  const SizedBox(height: 8),
                  FractionallySizedBox(
                    alignment: Alignment.centerLeft,
                    widthFactor: (d.total / maxTotal).clamp(0.04, 1.0).toDouble(),
                    child: ClipRRect(
                      borderRadius: BorderRadius.circular(6),
                      child: SizedBox(
                        height: 8,
                        child: Row(
                          children: [
                            Expanded(
                              flex: (d.rx / d.total * 1000).round().clamp(1, 999).toInt(),
                              child: ColoredBox(color: cs.secondary),
                            ),
                            Expanded(
                              flex: (d.tx / d.total * 1000).round().clamp(1, 999).toInt(),
                              child: ColoredBox(color: cs.primary),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(height: 6),
                  Text(
                    '↓ ${extrasFormatBytes(d.rx)}    ↑ ${extrasFormatBytes(d.tx)}',
                    style: theme.textTheme.bodySmall?.copyWith(
                      color: cs.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          ),
      ],
    );
  }

  Widget _bars(ThemeData theme, List<_Bucket> items) {
    final cs = theme.colorScheme;
    const chartHeight = 140.0;
    final maxV = items.fold<double>(1, (a, b) => (b.rx + b.tx) > a ? b.rx + b.tx : a);
    return SizedBox(
      height: chartHeight + 28,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        reverse: true,
        itemCount: items.length,
        separatorBuilder: (_, _) => const SizedBox(width: 6),
        itemBuilder: (context, index) {
          // reverse:true lists newest first, so index 0 sits on the right.
          final b = items[items.length - 1 - index];
          final txH = b.tx / maxV * chartHeight;
          final rxH = b.rx / maxV * chartHeight;
          return Tooltip(
            message:
                '${b.label}\n↓ ${extrasFormatBytes(b.rx)}\n↑ ${extrasFormatBytes(b.tx)}',
            triggerMode: TooltipTriggerMode.tap,
            child: SizedBox(
              width: 30,
              child: Column(
                mainAxisAlignment: MainAxisAlignment.end,
                children: [
                  Container(
                    height: txH,
                    decoration: BoxDecoration(
                      color: cs.primary,
                      borderRadius: const BorderRadius.vertical(
                        top: Radius.circular(5),
                      ),
                    ),
                  ),
                  Container(height: rxH, color: cs.secondary),
                  const SizedBox(height: 4),
                  Text(
                    b.label.length > 5 ? b.label.substring(b.label.length - 5) : b.label,
                    maxLines: 1,
                    style: TextStyle(fontSize: 9, color: cs.onSurfaceVariant),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }

  Widget _ifaceView(ThemeData theme) {
    final cs = theme.colorScheme;
    final source = _monthly ? _months : _daily;
    var items = _iface == null ? const <_Bucket>[] : (source[_iface] ?? const <_Bucket>[]);
    final limit = _monthly ? 12 : 30;
    if (items.length > limit) items = items.sublist(items.length - limit);
    final rx = items.fold<double>(0, (a, b) => a + b.rx);
    final tx = items.fold<double>(0, (a, b) => a + b.tx);

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Row(
          children: [
            Expanded(
              child: DropdownButtonFormField<String>(
                initialValue: _daily.containsKey(_iface) ? _iface : null,
                decoration: const InputDecoration(
                  labelText: 'Interface',
                  isDense: true,
                ),
                items: [
                  for (final k in _daily.keys)
                    DropdownMenuItem(value: k, child: Text(k)),
                ],
                onChanged: (v) => setState(() => _iface = v),
              ),
            ),
            const SizedBox(width: 12),
            SegmentedButton<bool>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(value: false, label: Text('Daily')),
                ButtonSegment(value: true, label: Text('Monthly')),
              ],
              selected: {_monthly},
              onSelectionChanged: (s) => setState(() => _monthly = s.first),
            ),
          ],
        ),
        const SizedBox(height: 12),
        _summary(theme, rx, tx),
        const SizedBox(height: 16),
        Text(
          _monthly ? 'LAST 12 MONTHS' : 'LAST 30 DAYS',
          style: theme.textTheme.labelSmall?.copyWith(
            letterSpacing: 1.2,
            color: cs.onSurfaceVariant,
            fontWeight: FontWeight.w700,
          ),
        ),
        const SizedBox(height: 8),
        if (items.isEmpty)
          const Padding(
            padding: EdgeInsets.all(16),
            child: Text('No data for this interface yet.'),
          )
        else
          _bars(theme, items),
        const SizedBox(height: 8),
        Row(
          children: [
            Container(width: 10, height: 10, color: cs.secondary),
            const SizedBox(width: 6),
            const Text('Download', style: TextStyle(fontSize: 12)),
            const SizedBox(width: 16),
            Container(width: 10, height: 10, color: cs.primary),
            const SizedBox(width: 6),
            const Text('Upload', style: TextStyle(fontSize: 12)),
            const Spacer(),
            Text(
              'Tap a bar for details',
              style: TextStyle(fontSize: 11, color: cs.onSurfaceVariant),
            ),
          ],
        ),
      ],
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);

    Widget body;
    if (_checking) {
      body = const Center(child: CircularProgressIndicator());
    } else if (!_hasNlbw && !_hasVnstat) {
      body = ListView(
        padding: const EdgeInsets.all(16),
        children: [
          ExtrasInstallCard(
            title: 'Per-device usage needs nlbwmon',
            message:
                'nlbwmon records how much each device downloads and uploads, '
                'per billing period.',
            package: 'nlbwmon',
            busy: _installing,
            onInstall: () => _install('nlbwmon', 'nlbwmon'),
          ),
          const SizedBox(height: 12),
          ExtrasInstallCard(
            title: 'Daily & monthly totals need vnstat',
            message:
                'vnstat keeps daily and monthly traffic history for each '
                'network interface.',
            package: 'vnstat2',
            busy: _installing,
            onInstall: () => _install('vnstat2', 'vnstat'),
          ),
        ],
      );
    } else {
      body = RefreshIndicator(
        onRefresh: _loadCurrent,
        child: ListView(
          padding: const EdgeInsets.all(16),
          children: [
            SegmentedButton<int>(
              showSelectedIcon: false,
              segments: const [
                ButtonSegment(
                  value: 0,
                  icon: Icon(Icons.devices_other_rounded),
                  label: Text('Per device'),
                ),
                ButtonSegment(
                  value: 1,
                  icon: Icon(Icons.bar_chart_rounded),
                  label: Text('History'),
                ),
              ],
              selected: {_mode},
              onSelectionChanged: (s) {
                setState(() {
                  _mode = s.first;
                  _error = null;
                });
                final needLoad = _mode == 0
                    ? (!_deviceLoaded && _hasNlbw)
                    : (!_ifaceLoaded && _hasVnstat);
                if (needLoad) _loadCurrent();
              },
            ),
            const SizedBox(height: 16),
            if (_mode == 0 && !_hasNlbw)
              ExtrasInstallCard(
                title: 'nlbwmon is not installed',
                message:
                    'Install nlbwmon to see how much data each device uses.',
                package: 'nlbwmon',
                busy: _installing,
                onInstall: () => _install('nlbwmon', 'nlbwmon'),
              )
            else if (_mode == 1 && !_hasVnstat)
              ExtrasInstallCard(
                title: 'vnstat is not installed',
                message:
                    'Install vnstat to keep daily and monthly history per '
                    'interface.',
                package: 'vnstat2',
                busy: _installing,
                onInstall: () => _install('vnstat2', 'vnstat'),
              )
            else ...[
              if (_loading) const LinearProgressIndicator(minHeight: 2),
              if (_error != null)
                Padding(
                  padding: const EdgeInsets.only(bottom: 12),
                  child: Text(
                    _error!,
                    style: TextStyle(color: theme.colorScheme.error),
                  ),
                ),
              if (_mode == 0) _deviceView(theme) else _ifaceView(theme),
            ],
          ],
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: const Text('Data Usage'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: (_checking || _loading) ? null : _detect,
          ),
        ],
      ),
      body: body,
    );
  }
}
