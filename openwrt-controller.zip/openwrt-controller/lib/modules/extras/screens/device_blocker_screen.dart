// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _Dev {
  _Dev({
    required this.mac,
    required this.name,
    required this.ip,
    required this.online,
    required this.blocked,
  });

  final String mac;
  String name;
  String ip;
  bool online;
  bool blocked;
}

/// One-tap internet blocking per device (permanent until unblocked).
///
/// Each block is a UCI firewall rule named `yala_blk_<mac>` that rejects
/// LAN -> WAN traffic from the device's MAC address.
class DeviceBlockerScreen extends ConsumerStatefulWidget {
  const DeviceBlockerScreen({super.key});

  @override
  ConsumerState<DeviceBlockerScreen> createState() =>
      _DeviceBlockerScreenState();
}

class _DeviceBlockerScreenState extends ConsumerState<DeviceBlockerScreen> {
  static const String _prefix = 'yala_blk_';

  final TextEditingController _search = TextEditingController();
  List<_Dev> _devices = const [];
  bool _loading = true;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _search.dispose();
    super.dispose();
  }

  static String _sectionFor(String mac) =>
      '$_prefix${mac.replaceAll(':', '').toLowerCase()}';

  Future<void> _load() async {
    setState(() => _loading = true);
    final out = await ExtrasShell(ref.read(appStateProvider)).run(
      'echo __LEASES__; cat /tmp/dhcp.leases 2>/dev/null; '
      'echo __ARP__; cat /proc/net/arp 2>/dev/null; '
      'echo __FW__; uci -q show firewall 2>/dev/null | grep "yala_blk_"; true',
    );

    final map = <String, _Dev>{};
    var section = '';
    final blockedMacs = <String>{};
    final optRe = RegExp(
      r'^firewall\.' + _prefix + r'[a-f0-9]+\.src_mac=(.*)$',
    );

    for (final raw in out.split('\n')) {
      final line = raw.trim();
      if (line == '__LEASES__' || line == '__ARP__' || line == '__FW__') {
        section = line;
        continue;
      }
      if (line.isEmpty) continue;

      if (section == '__LEASES__') {
        final p = line.split(RegExp(r'\s+'));
        if (p.length >= 4 && ExtrasShell.isMac(p[1])) {
          final mac = p[1].toUpperCase();
          final d = map.putIfAbsent(
            mac,
            () => _Dev(
              mac: mac,
              name: 'Unknown device',
              ip: p[2],
              online: false,
              blocked: false,
            ),
          );
          if (p[3] != '*') d.name = p[3];
          d.ip = p[2];
        }
      } else if (section == '__ARP__') {
        final p = line.split(RegExp(r'\s+'));
        if (p.length >= 4 &&
            ExtrasShell.isMac(p[3]) &&
            p[3] != '00:00:00:00:00:00' &&
            p[2] == '0x2') {
          final mac = p[3].toUpperCase();
          final d = map.putIfAbsent(
            mac,
            () => _Dev(
              mac: mac,
              name: 'Unknown device',
              ip: p[0],
              online: true,
              blocked: false,
            ),
          );
          d.online = true;
          if (ExtrasShell.isIpv4(p[0])) d.ip = p[0];
        }
      } else if (section == '__FW__') {
        final m = optRe.firstMatch(line);
        if (m != null) {
          final mac = m.group(1)!.replaceAll("'", '').trim().toUpperCase();
          if (ExtrasShell.isMac(mac)) blockedMacs.add(mac);
        }
      }
    }

    for (final mac in blockedMacs) {
      final d = map.putIfAbsent(
        mac,
        () => _Dev(
          mac: mac,
          name: 'Blocked device',
          ip: '',
          online: false,
          blocked: true,
        ),
      );
      d.blocked = true;
    }

    final list = map.values.toList()
      ..sort((a, b) {
        if (a.blocked != b.blocked) return a.blocked ? -1 : 1;
        if (a.online != b.online) return a.online ? -1 : 1;
        return a.name.toLowerCase().compareTo(b.name.toLowerCase());
      });

    if (!mounted) return;
    setState(() {
      _devices = list;
      _loading = false;
    });
  }

  Future<void> _setBlocked(_Dev d, bool block) async {
    if (!ExtrasShell.isMac(d.mac) || _busy) return;
    setState(() => _busy = true);
    final shell = ExtrasShell(ref.read(appStateProvider));
    final id = _sectionFor(d.mac);
    final q = ExtrasShell.q;

    String script;
    if (block) {
      script = [
        'uci set ${q('firewall.$id=rule')}',
        'uci set ${q('firewall.$id.name=OWC-Block-${d.mac}')}',
        'uci set ${q('firewall.$id.src=lan')}',
        'uci set ${q('firewall.$id.src_mac=${d.mac}')}',
        'uci set ${q('firewall.$id.dest=wan')}',
        'uci set ${q('firewall.$id.target=REJECT')}',
        'uci commit firewall',
      ].join(' && ');
    } else {
      script = 'uci -q delete ${q('firewall.$id')}; uci commit firewall';
    }

    final res = await shell.attempt(script);
    var reloaded = false;
    if (res.ok) {
      reloaded = await shell.service('firewall', 'reload');
      if (block && ExtrasShell.isIpv4(d.ip)) {
        // Drop already-established connections so the block applies at once.
        await shell.run(
          'command -v conntrack >/dev/null 2>&1 && '
          'conntrack -D -s ${q(d.ip)} >/dev/null 2>&1; true',
        );
      }
    }

    if (!mounted) return;
    setState(() => _busy = false);
    if (!res.ok) {
      extrasToast(context, 'Failed: ${res.output}', error: true);
    } else {
      extrasToast(
        context,
        reloaded
            ? (block ? 'Blocked ${d.name}' : 'Unblocked ${d.name}')
            : 'Saved, but the firewall did not reload. Reload it manually.',
        error: !reloaded,
      );
    }
    await _load();
  }

  Future<void> _unblockAll() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Unblock all devices?'),
        content: const Text('Every block created by this screen is removed.'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Unblock all'),
          ),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    setState(() => _busy = true);
    final shell = ExtrasShell(ref.read(appStateProvider));
    final res = await shell.attempt(
      r'''for s in $(uci -q show firewall | sed -n 's/^firewall\.\(yala_blk_[a-f0-9]*\)=rule$/\1/p'); do uci -q delete firewall.$s; done; uci commit firewall''',
    );
    if (res.ok) await shell.service('firewall', 'reload');
    if (!mounted) return;
    setState(() => _busy = false);
    extrasToast(
      context,
      res.ok ? 'All devices unblocked' : 'Failed: ${res.output}',
      error: !res.ok,
    );
    await _load();
  }

  Future<void> _blockByMac() async {
    final ctrl = TextEditingController();
    String? error;
    final mac = await showDialog<String>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('Block by MAC address'),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: ctrl,
                autofocus: true,
                textCapitalization: TextCapitalization.characters,
                decoration: InputDecoration(
                  labelText: 'MAC address',
                  hintText: 'AA:BB:CC:DD:EE:FF',
                  errorText: error,
                ),
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                final v = ctrl.text.trim();
                if (!ExtrasShell.isMac(v)) {
                  setLocal(() => error = 'Use the format AA:BB:CC:DD:EE:FF');
                  return;
                }
                Navigator.of(ctx).pop(v.toUpperCase());
              },
              child: const Text('Block'),
            ),
          ],
        ),
      ),
    );
    Future<void>.delayed(const Duration(milliseconds: 600), ctrl.dispose);
    if (mac == null || !mounted) return;
    await _setBlocked(
      _Dev(
        mac: mac,
        name: mac,
        ip: '',
        online: false,
        blocked: false,
      ),
      true,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final cs = theme.colorScheme;
    final needle = _search.text.trim().toLowerCase();
    final visible = _devices.where((d) {
      if (needle.isEmpty) return true;
      return d.name.toLowerCase().contains(needle) ||
          d.ip.contains(needle) ||
          d.mac.toLowerCase().contains(needle);
    }).toList();
    final blockedCount = _devices.where((d) => d.blocked).length;

    return Scaffold(
      appBar: AppBar(
        title: const Text('Device Blocker'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: (_loading || _busy) ? null : _load,
          ),
          PopupMenuButton<String>(
            onSelected: (v) {
              if (v == 'all') _unblockAll();
            },
            itemBuilder: (_) => [
              PopupMenuItem(
                value: 'all',
                enabled: blockedCount > 0,
                child: const Text('Unblock all'),
              ),
            ],
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _blockByMac,
        icon: const Icon(Icons.block_rounded),
        label: const Text('Block by MAC'),
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 4),
            child: TextField(
              controller: _search,
              onChanged: (_) => setState(() {}),
              decoration: const InputDecoration(
                isDense: true,
                prefixIcon: Icon(Icons.search),
                hintText: 'Search name, IP or MAC',
              ),
            ),
          ),
          Padding(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 4),
            child: Row(
              children: [
                Icon(
                  Icons.block_rounded,
                  size: 16,
                  color: blockedCount > 0 ? cs.error : cs.onSurfaceVariant,
                ),
                const SizedBox(width: 6),
                Text(
                  blockedCount == 0
                      ? 'No blocked devices'
                      : '$blockedCount blocked',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: blockedCount > 0 ? cs.error : cs.onSurfaceVariant,
                    fontWeight: FontWeight.w600,
                  ),
                ),
              ],
            ),
          ),
          if (_busy || _loading) const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: visible.isEmpty && !_loading
                ? const Center(child: Text('No devices found.'))
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.builder(
                      padding: const EdgeInsets.fromLTRB(12, 4, 12, 96),
                      itemCount: visible.length,
                      itemBuilder: (context, i) {
                        final d = visible[i];
                        return Card(
                          child: Padding(
                            padding: const EdgeInsets.symmetric(
                              horizontal: 12,
                              vertical: 10,
                            ),
                            child: Row(
                              children: [
                                CircleAvatar(
                                  backgroundColor: d.blocked
                                      ? cs.errorContainer
                                      : cs.secondaryContainer,
                                  foregroundColor: d.blocked
                                      ? cs.onErrorContainer
                                      : cs.onSecondaryContainer,
                                  child: Icon(
                                    d.blocked
                                        ? Icons.block_rounded
                                        : Icons.devices_other_rounded,
                                  ),
                                ),
                                const SizedBox(width: 12),
                                Expanded(
                                  child: Column(
                                    crossAxisAlignment:
                                        CrossAxisAlignment.start,
                                    children: [
                                      Text(
                                        d.name,
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.titleSmall,
                                      ),
                                      Text(
                                        [
                                          if (d.ip.isNotEmpty) d.ip,
                                          d.mac,
                                        ].join('  •  '),
                                        maxLines: 1,
                                        overflow: TextOverflow.ellipsis,
                                        style: theme.textTheme.bodySmall
                                            ?.copyWith(
                                              color: cs.onSurfaceVariant,
                                            ),
                                      ),
                                      const SizedBox(height: 2),
                                      Text(
                                        d.blocked
                                            ? 'Internet blocked'
                                            : (d.online ? 'Online' : 'Offline'),
                                        style: theme.textTheme.labelSmall
                                            ?.copyWith(
                                              fontWeight: FontWeight.w700,
                                              color: d.blocked
                                                  ? cs.error
                                                  : (d.online
                                                        ? cs.secondary
                                                        : cs.onSurfaceVariant),
                                            ),
                                      ),
                                    ],
                                  ),
                                ),
                                const SizedBox(width: 8),
                                d.blocked
                                    ? FilledButton.tonal(
                                        style: FilledButton.styleFrom(
                                          minimumSize: const Size(0, 40),
                                          foregroundColor:
                                              cs.onSecondaryContainer,
                                          backgroundColor:
                                              cs.secondaryContainer,
                                        ),
                                        onPressed: _busy
                                            ? null
                                            : () => _setBlocked(d, false),
                                        child: const Text('Unblock'),
                                      )
                                    : FilledButton(
                                        style: FilledButton.styleFrom(
                                          minimumSize: const Size(0, 40),
                                          backgroundColor: cs.error,
                                          foregroundColor: cs.onError,
                                        ),
                                        onPressed: _busy
                                            ? null
                                            : () => _setBlocked(d, true),
                                        child: const Text('Block'),
                                      ),
                              ],
                            ),
                          ),
                        );
                      },
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
