// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:yet_another_luci_app/state/app_state.dart';

/// Small helper around [AppState] used by the "extras" modules
/// (log viewer, Wake-on-LAN, port forwarding, SQM, DNS filtering,
/// multi-WAN and speed test).
///
/// Everything goes through the already authenticated router session, so no
/// extra credentials or SSH access are required.
class ExtrasShell {
  ExtrasShell(this.app);

  final AppState app;

  static const String okMarker = '__YALA_OK__';

  /// Wraps [value] in single quotes so it is safe as one shell argument.
  static String q(String value) => "'${value.replaceAll("'", "'\\''")}'";

  static final RegExp _ipv4 = RegExp(
    r'^((25[0-5]|2[0-4]\d|1?\d?\d)\.){3}(25[0-5]|2[0-4]\d|1?\d?\d)$',
  );
  static final RegExp _mac = RegExp(r'^([0-9A-Fa-f]{2}:){5}[0-9A-Fa-f]{2}$');
  static final RegExp _ident = RegExp(r'^[A-Za-z0-9_.@-]{1,32}$');
  static final RegExp _label = RegExp(r'^[A-Za-z0-9 _.-]{1,32}$');
  static final RegExp _uciId = RegExp(r'^[@A-Za-z0-9_\[\]-]{1,64}$');

  static bool isIpv4(String s) => _ipv4.hasMatch(s);
  static bool isMac(String s) => _mac.hasMatch(s);
  static bool isIdent(String s) => _ident.hasMatch(s);
  static bool isLabel(String s) => _label.hasMatch(s);
  static bool isUciId(String s) => _uciId.hasMatch(s);

  /// Accepts "80" or a range such as "8000-8010" (1..65535).
  static bool isPortOrRange(String s) {
    final parts = s.split('-');
    if (parts.length > 2) return false;
    final nums = <int>[];
    for (final p in parts) {
      final n = int.tryParse(p);
      if (n == null || n < 1 || n > 65535) return false;
      nums.add(n);
    }
    return nums.length == 1 || nums[0] <= nums[1];
  }

  static const String doneMarker = '__YALA_DONE__';

  /// Runs [script] with `sh -c` and returns stdout (empty string on failure).
  ///
  /// A trailing marker guarantees non-empty output, because
  /// [AppState.executeRouterCommandOutput] re-runs a command through several
  /// fallbacks whenever stdout is empty, which would execute commands with
  /// side effects more than once.
  Future<String> run(String script) async {
    final out = await app.executeRouterCommandOutput('sh', [
      '-c',
      '( $script ) ; echo $doneMarker',
    ]);
    if (out == null) return '';
    return out.replaceAll(doneMarker, '').trimRight();
  }

  /// Runs [script] and reports whether the shell exited with status 0.
  Future<({bool ok, String output})> attempt(String script) async {
    final out = await run('( $script ) 2>&1 && echo $okMarker');
    return (
      ok: out.contains(okMarker),
      output: out.replaceAll(okMarker, '').trim(),
    );
  }

  /// Runs `/etc/init.d/<name> <action>`; falls back to the app's own
  /// service dispatcher when file.exec ACLs reject init scripts.
  Future<bool> service(String name, String action) async {
    if (!isIdent(name) || !isIdent(action)) return false;
    final res = await attempt('/etc/init.d/$name $action');
    if (res.ok) return true;
    try {
      return await app.manageServiceAction(name, action);
    } catch (_) {
      return false;
    }
  }

  /// Installs [package] with apk (OpenWrt 24.10+) or opkg.
  Future<({bool ok, String output})> installPackage(String package) {
    if (!isIdent(package)) {
      return Future.value((ok: false, output: 'Invalid package name'));
    }
    return attempt(
      'if command -v apk >/dev/null 2>&1; then apk update >/dev/null 2>&1; '
      'apk add $package; '
      'else opkg update >/dev/null 2>&1; opkg install $package; fi',
    );
  }
}

/// Shows a short snackbar message.
void extrasToast(BuildContext context, String message, {bool error = false}) {
  if (!context.mounted) return;
  final scheme = Theme.of(context).colorScheme;
  ScaffoldMessenger.of(context)
    ..hideCurrentSnackBar()
    ..showSnackBar(
      SnackBar(
        content: Text(
          message,
          style: TextStyle(color: error ? scheme.onError : null),
        ),
        backgroundColor: error ? scheme.error : null,
      ),
    );
}

/// Card shown when an optional OpenWrt package is not installed.
class ExtrasInstallCard extends StatelessWidget {
  const ExtrasInstallCard({
    super.key,
    required this.title,
    required this.message,
    required this.package,
    required this.busy,
    required this.onInstall,
  });

  final String title;
  final String message;
  final String package;
  final bool busy;
  final VoidCallback onInstall;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(Icons.extension_off_outlined, color: theme.colorScheme.outline),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(title, style: theme.textTheme.titleMedium),
                ),
              ],
            ),
            const SizedBox(height: 8),
            Text(message, style: theme.textTheme.bodyMedium),
            const SizedBox(height: 12),
            FilledButton.icon(
              onPressed: busy ? null : onInstall,
              icon: busy
                  ? const SizedBox(
                      width: 16,
                      height: 16,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.download_rounded),
              label: Text('Install $package'),
            ),
          ],
        ),
      ),
    );
  }
}

/// Monospace output block used by several screens.
class ExtrasMonoBox extends StatelessWidget {
  const ExtrasMonoBox(this.text, {super.key, this.maxHeight});

  final String text;
  final double? maxHeight;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final content = SelectableText(
      text,
      style: theme.textTheme.bodySmall?.copyWith(
        fontFamily: 'monospace',
        height: 1.35,
      ),
    );
    return Container(
      width: double.infinity,
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: theme.colorScheme.surfaceContainerHighest,
        borderRadius: BorderRadius.circular(12),
      ),
      child: maxHeight == null
          ? content
          : ConstrainedBox(
              constraints: BoxConstraints(maxHeight: maxHeight!),
              child: SingleChildScrollView(child: content),
            ),
    );
  }
}

/// Formats a byte count such as 1536 -> "1.5 KB".
String extrasFormatBytes(num bytes) {
  if (bytes < 1024) return '${bytes.toStringAsFixed(0)} B';
  const units = ['KB', 'MB', 'GB', 'TB', 'PB'];
  var value = bytes / 1024;
  var i = 0;
  while (value >= 1024 && i < units.length - 1) {
    value /= 1024;
    i++;
  }
  return '${value.toStringAsFixed(value >= 100 ? 0 : (value >= 10 ? 1 : 2))} ${units[i]}';
}
