// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import '../core/luci_module.dart';
import 'screens/data_usage_screen.dart';
import 'screens/device_blocker_screen.dart';
import 'screens/dns_filtering_screen.dart';
import 'screens/log_viewer_screen.dart';
import 'screens/multi_wan_screen.dart';
import 'screens/port_forwarding_screen.dart';
import 'screens/speed_test_screen.dart';
import 'screens/sqm_screen.dart';
import 'screens/wake_on_lan_screen.dart';

class LogViewerModule extends LuciModule {
  @override
  String get id => 'system_log';
  @override
  String get name => 'System Log';
  @override
  String get description =>
      'Live logread / dmesg viewer with search, severity filter & copy';
  @override
  IconData get icon => Icons.article_outlined;
  @override
  IconData get selectedIcon => Icons.article;
  @override
  LuciModuleCategory get category => LuciModuleCategory.tools;
  @override
  int get priority => 33;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const LogViewerScreen();
}

class WakeOnLanModule extends LuciModule {
  @override
  String get id => 'wake_on_lan';
  @override
  String get name => 'Wake on LAN';
  @override
  String get description =>
      'Power on LAN devices remotely with magic packets from the router';
  @override
  IconData get icon => Icons.power_settings_new_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.tools;
  @override
  int get priority => 34;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const WakeOnLanScreen();
}

class PortForwardingModule extends LuciModule {
  @override
  String get id => 'port_forwarding';
  @override
  String get name => 'Port Forwarding';
  @override
  String get description =>
      'Create, enable & remove WAN to LAN port forward (DNAT) rules';
  @override
  IconData get icon => Icons.call_split_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.security;
  @override
  int get priority => 35;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const PortForwardingScreen();
}

class SqmModule extends LuciModule {
  @override
  String get id => 'sqm_qos';
  @override
  String get name => 'SQM / QoS';
  @override
  String get description =>
      'Smart Queue Management (cake) to fight bufferbloat & keep latency low';
  @override
  IconData get icon => Icons.tune_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.network;
  @override
  int get priority => 36;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const SqmScreen();
}

class DnsFilteringModule extends LuciModule {
  @override
  String get id => 'dns_filtering';
  @override
  String get name => 'DNS Filtering & Privacy';
  @override
  String get description =>
      'Control adblock, banIP & DNS-over-HTTPS (https-dns-proxy)';
  @override
  IconData get icon => Icons.shield_outlined;
  @override
  IconData get selectedIcon => Icons.shield;
  @override
  LuciModuleCategory get category => LuciModuleCategory.security;
  @override
  int get priority => 37;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const DnsFilteringScreen();
}

class MultiWanModule extends LuciModule {
  @override
  String get id => 'multi_wan';
  @override
  String get name => 'Multi-WAN';
  @override
  String get description =>
      'mwan3 uplink status, failover & load balancing control';
  @override
  IconData get icon => Icons.alt_route_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.network;
  @override
  int get priority => 38;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const MultiWanScreen();
}

class SpeedTestModule extends LuciModule {
  @override
  String get id => 'speed_test';
  @override
  String get name => 'Speed Test';
  @override
  String get description =>
      'Router-side WAN download speed & latency test with history';
  @override
  IconData get icon => Icons.speed_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.tools;
  @override
  int get priority => 40;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const SpeedTestScreen();
}

class DataUsageModule extends LuciModule {
  @override
  String get id => 'data_usage';
  @override
  String get name => 'Data Usage';
  @override
  String get description =>
      'Per-device usage and daily / monthly traffic history';
  @override
  IconData get icon => Icons.data_usage_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.network;
  @override
  int get priority => 31;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const DataUsageScreen();
}

class DeviceBlockerModule extends LuciModule {
  @override
  String get id => 'device_blocker';
  @override
  String get name => 'Device Blocker';
  @override
  String get description =>
      'Block or unblock a device\'s internet instantly with one tap';
  @override
  IconData get icon => Icons.block_rounded;
  @override
  LuciModuleCategory get category => LuciModuleCategory.security;
  @override
  int get priority => 32;
  @override
  Widget buildScreen(BuildContext context, {Map<String, dynamic>? params}) =>
      const DeviceBlockerScreen();
}

/// All additional modules, in display order.
List<LuciModule> buildExtrasModules() => [
  DataUsageModule(),
  DeviceBlockerModule(),
  LogViewerModule(),
  WakeOnLanModule(),
  PortForwardingModule(),
  SqmModule(),
  DnsFilteringModule(),
  MultiWanModule(),
  SpeedTestModule(),
];
