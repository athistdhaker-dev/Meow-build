// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

/// Smart Queue Management (sqm-scripts / cake) configuration.
class SqmScreen extends ConsumerStatefulWidget {
  const SqmScreen({super.key});

  @override
  ConsumerState<SqmScreen> createState() => _SqmScreenState();
}

class _SqmScreenState extends ConsumerState<SqmScreen> {
  static const List<String> _scripts = [
    'piece_of_cake.qos',
    'layer_cake.qos',
    'simple.qos',
  ];

  final TextEditingController _ifaceCtrl = TextEditingController();
  final TextEditingController _downCtrl = TextEditingController(text: '0');
  final TextEditingController _upCtrl = TextEditingController(text: '0');
  bool _loading = true;
  bool _busy = false;
  bool _installed = true;
  bool _enabled = false;
  String _script = _scripts.first;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _ifaceCtrl.dispose();
    _downCtrl.dispose();
    _upCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final out = await ExtrasShell(ref.read(appStateProvider)).run(
      '[ -x /etc/init.d/sqm ] && echo INSTALLED=1 || echo INSTALLED=0; '
      'echo WANDEV=\$(ifstatus wan 2>/dev/null | jsonfilter -e "@.l3_device" '
      '2>/dev/null); '
      'uci -q show sqm 2>/dev/null; true',
    );
    var installed = true;
    var wanDev = '';
    final vals = <String, String>{};
    var firstQueue = '';
    final secRe = RegExp(r'^sqm\.([^.=\s]+)=(\S+)$');
    final optRe = RegExp(r'^sqm\.([^.=\s]+)\.([A-Za-z0-9_]+)=(.*)$');
    for (final raw in out.split('\n')) {
      final line = raw.trim();
      if (line.startsWith('INSTALLED=')) {
        installed = line.endsWith('1');
      } else if (line.startsWith('WANDEV=')) {
        wanDev = line.substring(7).trim();
      } else {
        final s = secRe.firstMatch(line);
        if (s != null) {
          if (firstQueue.isEmpty && s.group(2)!.replaceAll("'", '') == 'queue') {
            firstQueue = s.group(1)!;
          }
          continue;
        }
        final o = optRe.firstMatch(line);
        if (o != null && firstQueue.isNotEmpty && o.group(1) == firstQueue) {
          vals[o.group(2)!] = o.group(3)!.replaceAll("'", '').trim();
        }
      }
    }
    if (!mounted) return;
    setState(() {
      _installed = installed;
      _enabled = (vals['enabled'] ?? '0') == '1';
      _ifaceCtrl.text = (vals['interface'] ?? '').isNotEmpty
          ? vals['interface']!
          : wanDev;
      _downCtrl.text = vals['download'] ?? '0';
      _upCtrl.text = vals['upload'] ?? '0';
      final s = vals['script'] ?? '';
      _script = _scripts.contains(s) ? s : _scripts.first;
      _loading = false;
    });
  }

  Future<void> _install() async {
    setState(() => _busy = true);
    final res = await ExtrasShell(
      ref.read(appStateProvider),
    ).installPackage('sqm-scripts');
    if (!mounted) return;
    setState(() => _busy = false);
    extrasToast(
      context,
      res.ok ? 'sqm-scripts installed' : 'Install failed: ${res.output}',
      error: !res.ok,
    );
    await _load();
  }

  Future<void> _save() async {
    final iface = _ifaceCtrl.text.trim();
    final down = int.tryParse(_downCtrl.text.trim());
    final up = int.tryParse(_upCtrl.text.trim());
    if (!ExtrasShell.isIdent(iface)) {
      extrasToast(context, 'Enter a valid WAN interface (e.g. eth1)', error: true);
      return;
    }
    if (down == null || up == null || down < 0 || up < 0 || down > 10000000 || up > 10000000) {
      extrasToast(context, 'Speeds must be numbers in kbit/s (0 = off)', error: true);
      return;
    }
    if (_enabled && (down == 0 && up == 0)) {
      extrasToast(
        context,
        'Set at least one speed (kbit/s) before enabling SQM',
        error: true,
      );
      return;
    }
    setState(() => _busy = true);
    final shell = ExtrasShell(ref.read(appStateProvider));
    final en = _enabled ? '1' : '0';
    final res = await shell.attempt(
      [
        'uci -q get "sqm.@queue[0]" >/dev/null 2>&1 || uci add sqm queue >/dev/null',
        'uci set "sqm.@queue[0].enabled=$en"',
        'uci set "sqm.@queue[0].interface=$iface"',
        'uci set "sqm.@queue[0].download=$down"',
        'uci set "sqm.@queue[0].upload=$up"',
        'uci set "sqm.@queue[0].qdisc=cake"',
        'uci set "sqm.@queue[0].script=$_script"',
        'uci commit sqm',
      ].join(' && '),
    );
    var applied = res.ok;
    if (res.ok) {
      if (_enabled) await shell.service('sqm', 'enable');
      applied = await shell.service('sqm', _enabled ? 'restart' : 'stop');
    }
    if (!mounted) return;
    setState(() => _busy = false);
    if (!res.ok) {
      extrasToast(context, 'Failed: ${res.output}', error: true);
    } else {
      extrasToast(
        context,
        applied ? 'SQM settings applied' : 'Saved, but service did not respond',
        error: !applied,
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('SQM / QoS'),
        actions: [
          IconButton(
            tooltip: 'Reload',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: (_loading || _busy) ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (!_installed)
                  ExtrasInstallCard(
                    title: 'SQM is not installed',
                    message:
                        'Smart Queue Management reduces bufferbloat and keeps '
                        'latency low while the link is busy.',
                    package: 'sqm-scripts',
                    busy: _busy,
                    onInstall: _install,
                  )
                else
                  Card(
                    child: Padding(
                      padding: const EdgeInsets.all(16),
                      child: Column(
                        crossAxisAlignment: CrossAxisAlignment.start,
                        children: [
                          SwitchListTile(
                            contentPadding: EdgeInsets.zero,
                            title: const Text('Enable SQM'),
                            value: _enabled,
                            onChanged: _busy
                                ? null
                                : (v) => setState(() => _enabled = v),
                          ),
                          const SizedBox(height: 8),
                          TextField(
                            controller: _ifaceCtrl,
                            decoration: const InputDecoration(
                              labelText: 'WAN interface (device)',
                              hintText: 'eth1, wan, pppoe-wan',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _downCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Download (kbit/s)',
                              helperText: 'Use ~90-95% of your real speed',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 12),
                          TextField(
                            controller: _upCtrl,
                            keyboardType: TextInputType.number,
                            decoration: const InputDecoration(
                              labelText: 'Upload (kbit/s)',
                              border: OutlineInputBorder(),
                            ),
                          ),
                          const SizedBox(height: 12),
                          DropdownButtonFormField<String>(
                            initialValue: _script,
                            decoration: const InputDecoration(
                              labelText: 'Queue setup script',
                              border: OutlineInputBorder(),
                            ),
                            items: [
                              for (final s in _scripts)
                                DropdownMenuItem(value: s, child: Text(s)),
                            ],
                            onChanged: (v) =>
                                setState(() => _script = v ?? _script),
                          ),
                          const SizedBox(height: 16),
                          FilledButton.icon(
                            onPressed: _busy ? null : _save,
                            icon: const Icon(Icons.save_rounded),
                            label: Text(_busy ? 'Applying…' : 'Save & apply'),
                          ),
                        ],
                      ),
                    ),
                  ),
                const SizedBox(height: 12),
                Text(
                  'Uses the cake qdisc. Run a speed test first and enter '
                  'slightly lower values than the measured speeds.',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: theme.colorScheme.onSurfaceVariant,
                  ),
                ),
              ],
            ),
    );
  }
}
