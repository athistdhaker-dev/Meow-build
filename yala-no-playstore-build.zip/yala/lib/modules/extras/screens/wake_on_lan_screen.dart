// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _LeaseDevice {
  const _LeaseDevice(this.mac, this.ip, this.name);
  final String mac;
  final String ip;
  final String name;
}

/// Sends Wake-on-LAN magic packets from the router (`etherwake` / `wol`).
class WakeOnLanScreen extends ConsumerStatefulWidget {
  const WakeOnLanScreen({super.key});

  @override
  ConsumerState<WakeOnLanScreen> createState() => _WakeOnLanScreenState();
}

class _WakeOnLanScreenState extends ConsumerState<WakeOnLanScreen> {
  final TextEditingController _macCtrl = TextEditingController();
  final TextEditingController _ifaceCtrl = TextEditingController(text: 'br-lan');
  List<_LeaseDevice> _devices = const [];
  bool _loading = false;
  bool _sending = false;
  bool _installing = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _macCtrl.dispose();
    _ifaceCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final shell = ExtrasShell(ref.read(appStateProvider));
    final out = await shell.run('cat /tmp/dhcp.leases 2>/dev/null; true');
    final devices = <_LeaseDevice>[];
    for (final line in out.split('\n')) {
      final p = line.trim().split(RegExp(r'\s+'));
      if (p.length >= 4 && ExtrasShell.isMac(p[1])) {
        devices.add(
          _LeaseDevice(p[1].toUpperCase(), p[2], p[3] == '*' ? 'Unknown' : p[3]),
        );
      }
    }
    devices.sort((a, b) => a.name.toLowerCase().compareTo(b.name.toLowerCase()));
    if (!mounted) return;
    setState(() {
      _devices = devices;
      _loading = false;
    });
  }

  Future<void> _wake(String mac) async {
    final iface = _ifaceCtrl.text.trim();
    if (!ExtrasShell.isMac(mac)) {
      extrasToast(context, 'Enter a valid MAC (AA:BB:CC:DD:EE:FF)', error: true);
      return;
    }
    if (!ExtrasShell.isIdent(iface)) {
      extrasToast(context, 'Invalid interface name', error: true);
      return;
    }
    setState(() => _sending = true);
    final shell = ExtrasShell(ref.read(appStateProvider));
    final m = mac.toUpperCase();
    final res = await shell.attempt(
      'if command -v etherwake >/dev/null 2>&1; then '
      'etherwake -b -i ${ExtrasShell.q(iface)} ${ExtrasShell.q(m)}; '
      'elif command -v wol >/dev/null 2>&1; then wol ${ExtrasShell.q(m)}; '
      'else echo __NOTOOL__; exit 1; fi',
    );
    if (!mounted) return;
    setState(() => _sending = false);
    if (res.ok) {
      extrasToast(context, 'Magic packet sent to $m');
    } else if (res.output.contains('__NOTOOL__')) {
      _offerInstall();
    } else {
      extrasToast(
        context,
        res.output.isEmpty ? 'Could not send packet' : res.output,
        error: true,
      );
    }
  }

  Future<void> _offerInstall() async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Wake-on-LAN tool missing'),
        content: const Text(
          'The router has neither "etherwake" nor "wol" installed. '
          'Install etherwake now?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Install'),
          ),
        ],
      ),
    );
    if (yes != true || !mounted) return;
    setState(() => _installing = true);
    final res = await ExtrasShell(
      ref.read(appStateProvider),
    ).installPackage('etherwake');
    if (!mounted) return;
    setState(() => _installing = false);
    extrasToast(
      context,
      res.ok ? 'etherwake installed' : 'Install failed: ${res.output}',
      error: !res.ok,
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Wake on LAN'),
        actions: [
          IconButton(
            tooltip: 'Reload devices',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text('Manual wake', style: theme.textTheme.titleMedium),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _macCtrl,
                    textCapitalization: TextCapitalization.characters,
                    decoration: const InputDecoration(
                      labelText: 'MAC address',
                      hintText: 'AA:BB:CC:DD:EE:FF',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  TextField(
                    controller: _ifaceCtrl,
                    decoration: const InputDecoration(
                      labelText: 'Router interface',
                      border: OutlineInputBorder(),
                    ),
                  ),
                  const SizedBox(height: 12),
                  FilledButton.icon(
                    onPressed: (_sending || _installing)
                        ? null
                        : () => _wake(_macCtrl.text.trim()),
                    icon: const Icon(Icons.power_settings_new_rounded),
                    label: Text(_sending ? 'Sending…' : 'Send magic packet'),
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          Text('Known devices (DHCP leases)', style: theme.textTheme.titleMedium),
          const SizedBox(height: 8),
          if (_loading)
            const Padding(
              padding: EdgeInsets.all(24),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (_devices.isEmpty)
            const Padding(
              padding: EdgeInsets.all(16),
              child: Text('No DHCP leases found.'),
            )
          else
            for (final d in _devices)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.devices_other_rounded),
                  title: Text(d.name),
                  subtitle: Text('${d.ip}  •  ${d.mac}'),
                  trailing: IconButton(
                    tooltip: 'Wake',
                    icon: const Icon(Icons.power_settings_new_rounded),
                    onPressed: (_sending || _installing)
                        ? null
                        : () => _wake(d.mac),
                  ),
                  onTap: () => setState(() => _macCtrl.text = d.mac),
                ),
              ),
          const SizedBox(height: 12),
          Text(
            'Target devices must have Wake-on-LAN enabled in BIOS/OS and be '
            'on the same LAN segment as the selected interface.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
