// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'dart:async';

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

/// System log viewer (`logread`, falling back to `dmesg`).
class LogViewerScreen extends ConsumerStatefulWidget {
  const LogViewerScreen({super.key});

  @override
  ConsumerState<LogViewerScreen> createState() => _LogViewerScreenState();
}

enum _LogLevel { all, errors, warnings }

class _LogViewerScreenState extends ConsumerState<LogViewerScreen> {
  static final RegExp _errRe = RegExp(
    r'(emerg|alert|crit|\berr(or)?\b|fail|denied|panic)',
    caseSensitive: false,
  );
  static final RegExp _warnRe = RegExp(r'warn', caseSensitive: false);

  final TextEditingController _filterCtrl = TextEditingController();
  Timer? _timer;
  bool _loading = false;
  bool _auto = false;
  int _lines = 200;
  _LogLevel _level = _LogLevel.all;
  List<String> _all = const [];
  String? _message;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  @override
  void dispose() {
    _timer?.cancel();
    _filterCtrl.dispose();
    super.dispose();
  }

  Future<void> _load() async {
    if (_loading) return;
    setState(() => _loading = true);
    final shell = ExtrasShell(ref.read(appStateProvider));
    var text = await shell.run('logread 2>/dev/null | tail -n $_lines; true');
    if (text.trim().isEmpty) {
      text = await shell.run('dmesg 2>/dev/null | tail -n $_lines; true');
    }
    if (!mounted) return;
    final lines = text.split('\n').where((l) => l.trim().isNotEmpty).toList();
    setState(() {
      _all = lines;
      _loading = false;
      _message = lines.isEmpty
          ? 'No log output received. The router may restrict log access '
                'for this account.'
          : null;
    });
  }

  void _toggleAuto(bool value) {
    setState(() => _auto = value);
    _timer?.cancel();
    if (value) {
      _timer = Timer.periodic(const Duration(seconds: 5), (_) => _load());
    }
  }

  List<String> get _visible {
    final needle = _filterCtrl.text.trim().toLowerCase();
    final result = <String>[];
    for (final line in _all.reversed) {
      if (_level == _LogLevel.errors && !_errRe.hasMatch(line)) continue;
      if (_level == _LogLevel.warnings &&
          !(_warnRe.hasMatch(line) || _errRe.hasMatch(line))) {
        continue;
      }
      if (needle.isNotEmpty && !line.toLowerCase().contains(needle)) continue;
      result.add(line);
    }
    return result;
  }

  Color? _colorFor(String line, ColorScheme scheme) {
    if (_errRe.hasMatch(line)) return scheme.error;
    if (_warnRe.hasMatch(line)) return scheme.tertiary;
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final visible = _visible;
    return Scaffold(
      appBar: AppBar(
        title: const Text('System Log'),
        actions: [
          IconButton(
            tooltip: _auto ? 'Auto refresh on' : 'Auto refresh off',
            icon: Icon(_auto ? Icons.sync : Icons.sync_disabled),
            onPressed: () => _toggleAuto(!_auto),
          ),
          IconButton(
            tooltip: 'Copy visible lines',
            icon: const Icon(Icons.copy_rounded),
            onPressed: visible.isEmpty
                ? null
                : () async {
                    await Clipboard.setData(
                      ClipboardData(text: visible.join('\n')),
                    );
                    if (context.mounted) {
                      extrasToast(context, 'Copied ${visible.length} lines');
                    }
                  },
          ),
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _filterCtrl,
                    onChanged: (_) => setState(() {}),
                    decoration: InputDecoration(
                      isDense: true,
                      prefixIcon: const Icon(Icons.search),
                      hintText: 'Filter (e.g. dnsmasq, wlan0)',
                      border: OutlineInputBorder(
                        borderRadius: BorderRadius.circular(12),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 8),
                PopupMenuButton<int>(
                  tooltip: 'Lines to load',
                  icon: const Icon(Icons.format_list_numbered),
                  initialValue: _lines,
                  onSelected: (v) {
                    setState(() => _lines = v);
                    _load();
                  },
                  itemBuilder: (_) => const [
                    PopupMenuItem(value: 100, child: Text('Last 100 lines')),
                    PopupMenuItem(value: 200, child: Text('Last 200 lines')),
                    PopupMenuItem(value: 500, child: Text('Last 500 lines')),
                    PopupMenuItem(value: 1000, child: Text('Last 1000 lines')),
                  ],
                ),
              ],
            ),
          ),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 12),
            child: Wrap(
              spacing: 8,
              children: [
                for (final entry in const {
                  _LogLevel.all: 'All',
                  _LogLevel.warnings: 'Warnings+',
                  _LogLevel.errors: 'Errors',
                }.entries)
                  ChoiceChip(
                    label: Text(entry.value),
                    selected: _level == entry.key,
                    onSelected: (_) => setState(() => _level = entry.key),
                  ),
              ],
            ),
          ),
          if (_loading) const LinearProgressIndicator(minHeight: 2),
          Expanded(
            child: _message != null && _all.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(_message!, textAlign: TextAlign.center),
                    ),
                  )
                : RefreshIndicator(
                    onRefresh: _load,
                    child: ListView.separated(
                      padding: const EdgeInsets.all(12),
                      itemCount: visible.length,
                      separatorBuilder: (_, _) => const Divider(height: 8),
                      itemBuilder: (context, i) => SelectableText(
                        visible[i],
                        style: theme.textTheme.bodySmall?.copyWith(
                          fontFamily: 'monospace',
                          color: _colorFor(visible[i], theme.colorScheme),
                        ),
                      ),
                    ),
                  ),
          ),
        ],
      ),
    );
  }
}
