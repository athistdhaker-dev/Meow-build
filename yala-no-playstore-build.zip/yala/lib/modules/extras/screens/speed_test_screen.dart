// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _Result {
  const _Result({
    required this.mbps,
    required this.bytes,
    required this.seconds,
    required this.latencyMs,
    required this.server,
    required this.time,
  });
  final double mbps;
  final int bytes;
  final double seconds;
  final double? latencyMs;
  final String server;
  final DateTime time;
}

/// Router-side WAN download speed test (wget) with latency measurement.
class SpeedTestScreen extends ConsumerStatefulWidget {
  const SpeedTestScreen({super.key});

  @override
  ConsumerState<SpeedTestScreen> createState() => _SpeedTestScreenState();
}

class _SpeedTestScreenState extends ConsumerState<SpeedTestScreen> {
  static const List<(String, String)> _servers = [
    ('Tele2 10 MB', 'http://speedtest.tele2.net/10MB.zip'),
    ('Tele2 100 MB', 'http://speedtest.tele2.net/100MB.zip'),
    ('ThinkBroadband 10 MB', 'http://ipv4.download.thinkbroadband.com/10MB.zip'),
    ('Custom URL', ''),
  ];
  static final RegExp _urlRe = RegExp(r'^https?://[A-Za-z0-9._~:/?#@!&()*+,;=%-]+$');

  final TextEditingController _customCtrl = TextEditingController();
  final List<_Result> _results = [];
  int _server = 0;
  bool _running = false;
  String _status = '';

  @override
  void dispose() {
    _customCtrl.dispose();
    super.dispose();
  }

  Future<void> _start() async {
    final isCustom = _server == _servers.length - 1;
    final url = isCustom ? _customCtrl.text.trim() : _servers[_server].$2;
    if (!_urlRe.hasMatch(url)) {
      extrasToast(context, 'Enter a valid http(s) URL', error: true);
      return;
    }
    setState(() {
      _running = true;
      _status = 'Measuring latency…';
    });
    final shell = ExtrasShell(ref.read(appStateProvider));

    final pingOut = await shell.run('ping -c 4 -W 2 1.1.1.1 2>&1 | tail -n 3; true');
    final lat = RegExp(r'=\s*[\d.]+/([\d.]+)/').firstMatch(pingOut);
    final latency = lat == null ? null : double.tryParse(lat.group(1)!);

    if (!mounted) return;
    setState(() => _status = 'Downloading test file…');

    final script =
        'F=/tmp/yala_speedtest.bin; rm -f "\$F"; '
        'T=""; command -v timeout >/dev/null 2>&1 && T="timeout 30"; '
        'S=\$(cut -d" " -f1 /proc/uptime); '
        '\$T wget -T 20 -q -O "\$F" ${ExtrasShell.q(url)} >/dev/null 2>&1; '
        'E=\$(cut -d" " -f1 /proc/uptime); '
        'B=\$(wc -c < "\$F" 2>/dev/null || echo 0); '
        'rm -f "\$F"; echo "RESULT \$B \$S \$E"';
    final out = await shell.run(script);
    if (!mounted) return;

    final m = RegExp(r'RESULT\s+(\d+)\s+([\d.]+)\s+([\d.]+)').firstMatch(out);
    if (m == null) {
      setState(() {
        _running = false;
        _status = '';
      });
      extrasToast(
        context,
        'Speed test failed. The router may lack internet access or wget.',
        error: true,
      );
      return;
    }
    final bytes = int.parse(m.group(1)!);
    final secs = (double.tryParse(m.group(3)!) ?? 0) - (double.tryParse(m.group(2)!) ?? 0);
    if (bytes <= 0 || secs <= 0) {
      setState(() {
        _running = false;
        _status = '';
      });
      extrasToast(context, 'No data received. Try another server.', error: true);
      return;
    }
    final mbps = bytes * 8 / secs / 1000000;
    setState(() {
      _results.insert(
        0,
        _Result(
          mbps: mbps,
          bytes: bytes,
          seconds: secs,
          latencyMs: latency,
          server: isCustom ? 'Custom' : _servers[_server].$1,
          time: DateTime.now(),
        ),
      );
      if (_results.length > 10) _results.removeLast();
      _running = false;
      _status = '';
    });
  }

  String _two(int n) => n.toString().padLeft(2, '0');

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final last = _results.isEmpty ? null : _results.first;
    return Scaffold(
      appBar: AppBar(title: const Text('Speed Test')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Card(
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                children: [
                  Text(
                    last == null ? '—' : last.mbps.toStringAsFixed(1),
                    style: theme.textTheme.displayLarge?.copyWith(
                      fontWeight: FontWeight.bold,
                      color: theme.colorScheme.primary,
                    ),
                  ),
                  Text('Mbit/s download', style: theme.textTheme.bodyMedium),
                  const SizedBox(height: 8),
                  Text(
                    last?.latencyMs == null
                        ? 'Latency: —'
                        : 'Latency: ${last!.latencyMs!.toStringAsFixed(1)} ms (1.1.1.1)',
                    style: theme.textTheme.bodyMedium,
                  ),
                  const SizedBox(height: 16),
                  if (_running) ...[
                    const LinearProgressIndicator(),
                    const SizedBox(height: 8),
                    Text(_status, style: theme.textTheme.bodySmall),
                  ] else
                    FilledButton.icon(
                      onPressed: _start,
                      icon: const Icon(Icons.speed_rounded),
                      label: const Text('Start test'),
                    ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 12),
          DropdownButtonFormField<int>(
            initialValue: _server,
            decoration: const InputDecoration(
              labelText: 'Test server',
              border: OutlineInputBorder(),
            ),
            items: [
              for (var i = 0; i < _servers.length; i++)
                DropdownMenuItem(value: i, child: Text(_servers[i].$1)),
            ],
            onChanged: _running ? null : (v) => setState(() => _server = v ?? 0),
          ),
          if (_server == _servers.length - 1) ...[
            const SizedBox(height: 12),
            TextField(
              controller: _customCtrl,
              keyboardType: TextInputType.url,
              decoration: const InputDecoration(
                labelText: 'File URL (http:// recommended)',
                border: OutlineInputBorder(),
              ),
            ),
          ],
          const SizedBox(height: 16),
          if (_results.isNotEmpty) ...[
            Text('History', style: theme.textTheme.titleMedium),
            const SizedBox(height: 8),
            for (final r in _results)
              Card(
                child: ListTile(
                  leading: const Icon(Icons.history_rounded),
                  title: Text('${r.mbps.toStringAsFixed(1)} Mbit/s  •  ${r.server}'),
                  subtitle: Text(
                    '${(r.bytes / 1048576).toStringAsFixed(1)} MB in '
                    '${r.seconds.toStringAsFixed(1)} s'
                    '${r.latencyMs == null ? '' : '  •  ${r.latencyMs!.toStringAsFixed(0)} ms'}',
                  ),
                  trailing: Text('${_two(r.time.hour)}:${_two(r.time.minute)}'),
                ),
              ),
          ],
          const SizedBox(height: 12),
          Text(
            'The test downloads a file on the router itself, so it measures '
            'the WAN link (not your Wi-Fi) and uses mobile/ISP data. '
            'Upload speed is not measured. HTTPS URLs need ca-bundle on the '
            'router.',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.onSurfaceVariant,
            ),
          ),
        ],
      ),
    );
  }
}
