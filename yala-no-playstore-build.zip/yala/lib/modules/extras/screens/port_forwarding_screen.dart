// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _Redirect {
  const _Redirect({
    required this.id,
    required this.name,
    required this.proto,
    required this.srcPort,
    required this.destIp,
    required this.destPort,
    required this.enabled,
  });

  final String id;
  final String name;
  final String proto;
  final String srcPort;
  final String destIp;
  final String destPort;
  final bool enabled;
}

/// Port forwarding (UCI `firewall` redirect rules) manager.
class PortForwardingScreen extends ConsumerStatefulWidget {
  const PortForwardingScreen({super.key});

  @override
  ConsumerState<PortForwardingScreen> createState() =>
      _PortForwardingScreenState();
}

class _PortForwardingScreenState extends ConsumerState<PortForwardingScreen> {
  List<_Redirect> _rules = const [];
  bool _loading = false;
  bool _busy = false;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  static String _unquote(String v) =>
      v.trim().replaceAll("' '", ' ').replaceAll("'", '');

  List<_Redirect> _parse(String out) {
    final types = <String, String>{};
    final vals = <String, Map<String, String>>{};
    final order = <String>[];
    final secRe = RegExp(r'^firewall\.([^.=\s]+)=(\S+)$');
    final optRe = RegExp(r'^firewall\.([^.=\s]+)\.([A-Za-z0-9_]+)=(.*)$');
    for (final raw in out.split('\n')) {
      final line = raw.trim();
      final s = secRe.firstMatch(line);
      if (s != null) {
        final id = s.group(1)!;
        types[id] = _unquote(s.group(2)!);
        order.add(id);
        continue;
      }
      final o = optRe.firstMatch(line);
      if (o != null) {
        (vals[o.group(1)!] ??= {})[o.group(2)!] = _unquote(o.group(3)!);
      }
    }
    final rules = <_Redirect>[];
    for (final id in order) {
      if (types[id] != 'redirect') continue;
      final v = vals[id] ?? const <String, String>{};
      final target = (v['target'] ?? 'DNAT').toUpperCase();
      if (target != 'DNAT') continue;
      rules.add(
        _Redirect(
          id: id,
          name: (v['name'] ?? '').isEmpty ? 'Redirect' : v['name']!,
          proto: v['proto'] ?? 'tcp udp',
          srcPort: v['src_dport'] ?? '?',
          destIp: v['dest_ip'] ?? '?',
          destPort: v['dest_port'] ?? v['src_dport'] ?? '?',
          enabled: (v['enabled'] ?? '1') != '0',
        ),
      );
    }
    return rules;
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final out = await ExtrasShell(
      ref.read(appStateProvider),
    ).run('uci -q show firewall 2>&1; true');
    if (!mounted) return;
    setState(() {
      _rules = _parse(out);
      _loading = false;
    });
  }

  Future<void> _apply(String script, String okMessage) async {
    setState(() => _busy = true);
    final app = ref.read(appStateProvider);
    final shell = ExtrasShell(app);
    final res = await shell.attempt(script);
    if (res.ok) {
      try {
        await app.manageServiceAction('firewall', 'reload');
      } catch (_) {}
    }
    if (!mounted) return;
    setState(() => _busy = false);
    extrasToast(
      context,
      res.ok ? okMessage : 'Failed: ${res.output}',
      error: !res.ok,
    );
    await _load();
  }

  Future<void> _toggle(_Redirect r) async {
    if (!ExtrasShell.isUciId(r.id)) return;
    final v = r.enabled ? '0' : '1';
    await _apply(
      'uci set ${ExtrasShell.q('firewall.${r.id}.enabled=$v')} && '
      'uci commit firewall',
      r.enabled ? 'Rule disabled' : 'Rule enabled',
    );
  }

  Future<void> _delete(_Redirect r) async {
    if (!ExtrasShell.isUciId(r.id)) return;
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete rule?'),
        content: Text('Remove port forward "${r.name}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Delete'),
          ),
        ],
      ),
    );
    if (yes != true) return;
    await _apply(
      'uci delete ${ExtrasShell.q('firewall.${r.id}')} && uci commit firewall',
      'Rule deleted',
    );
  }

  Future<void> _addDialog() async {
    final nameCtrl = TextEditingController();
    final extCtrl = TextEditingController();
    final ipCtrl = TextEditingController();
    final intCtrl = TextEditingController();
    var proto = 'tcp udp';
    String? error;

    final ok = await showDialog<bool>(
      context: context,
      builder: (ctx) => StatefulBuilder(
        builder: (ctx, setLocal) => AlertDialog(
          title: const Text('New port forward'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                TextField(
                  controller: nameCtrl,
                  decoration: const InputDecoration(labelText: 'Name'),
                ),
                DropdownButtonFormField<String>(
                  initialValue: proto,
                  decoration: const InputDecoration(labelText: 'Protocol'),
                  items: const [
                    DropdownMenuItem(value: 'tcp udp', child: Text('TCP + UDP')),
                    DropdownMenuItem(value: 'tcp', child: Text('TCP')),
                    DropdownMenuItem(value: 'udp', child: Text('UDP')),
                  ],
                  onChanged: (v) => setLocal(() => proto = v ?? proto),
                ),
                TextField(
                  controller: extCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'External port',
                    hintText: '8080 or 8000-8010',
                  ),
                ),
                TextField(
                  controller: ipCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Internal IP',
                    hintText: '192.168.1.50',
                  ),
                ),
                TextField(
                  controller: intCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                    labelText: 'Internal port',
                    hintText: 'Same as external if empty',
                  ),
                ),
                if (error != null)
                  Padding(
                    padding: const EdgeInsets.only(top: 12),
                    child: Text(
                      error!,
                      style: TextStyle(color: Theme.of(ctx).colorScheme.error),
                    ),
                  ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.of(ctx).pop(false),
              child: const Text('Cancel'),
            ),
            FilledButton(
              onPressed: () {
                final name = nameCtrl.text.trim();
                final ext = extCtrl.text.trim();
                final ip = ipCtrl.text.trim();
                final intPort = intCtrl.text.trim().isEmpty
                    ? ext
                    : intCtrl.text.trim();
                String? e;
                if (!ExtrasShell.isLabel(name)) {
                  e = 'Name: 1-32 letters, digits, space, . _ -';
                } else if (!ExtrasShell.isPortOrRange(ext)) {
                  e = 'External port must be 1-65535 (or a range)';
                } else if (!ExtrasShell.isIpv4(ip)) {
                  e = 'Enter a valid internal IPv4 address';
                } else if (!ExtrasShell.isPortOrRange(intPort)) {
                  e = 'Internal port must be 1-65535 (or a range)';
                }
                if (e != null) {
                  setLocal(() => error = e);
                  return;
                }
                Navigator.of(ctx).pop(true);
              },
              child: const Text('Add'),
            ),
          ],
        ),
      ),
    );

    final name = nameCtrl.text.trim();
    final ext = extCtrl.text.trim();
    final ip = ipCtrl.text.trim();
    final intPort = intCtrl.text.trim().isEmpty ? ext : intCtrl.text.trim();
    // Dispose after the dialog's exit animation has finished.
    Future<void>.delayed(const Duration(milliseconds: 600), () {
      nameCtrl.dispose();
      extCtrl.dispose();
      ipCtrl.dispose();
      intCtrl.dispose();
    });
    if (ok != true || !mounted) return;

    // All values were validated against strict patterns above, so they are
    // safe inside double quotes.
    await _apply(
      [
        r'SEC=$(uci add firewall redirect)',
        r'uci set "firewall.$SEC.target=DNAT"',
        r'uci set "firewall.$SEC.src=wan"',
        r'uci set "firewall.$SEC.dest=lan"',
        'uci set "firewall.\$SEC.name=$name"',
        'uci set "firewall.\$SEC.proto=$proto"',
        'uci set "firewall.\$SEC.src_dport=$ext"',
        'uci set "firewall.\$SEC.dest_ip=$ip"',
        'uci set "firewall.\$SEC.dest_port=$intPort"',
        r'uci set "firewall.$SEC.enabled=1"',
        'uci commit firewall',
      ].join(' && '),
      'Port forward added',
    );
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Port Forwarding'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: (_loading || _busy) ? null : _load,
          ),
        ],
      ),
      floatingActionButton: FloatingActionButton.extended(
        onPressed: _busy ? null : _addDialog,
        icon: const Icon(Icons.add),
        label: const Text('Add rule'),
      ),
      body: Stack(
        children: [
          if (_loading && _rules.isEmpty)
            const Center(child: CircularProgressIndicator())
          else if (_rules.isEmpty)
            const Center(
              child: Padding(
                padding: EdgeInsets.all(24),
                child: Text(
                  'No port forwards configured.\nTap "Add rule" to create one.',
                  textAlign: TextAlign.center,
                ),
              ),
            )
          else
            RefreshIndicator(
              onRefresh: _load,
              child: ListView.builder(
                padding: const EdgeInsets.fromLTRB(12, 12, 12, 96),
                itemCount: _rules.length,
                itemBuilder: (context, i) {
                  final r = _rules[i];
                  return Card(
                    child: ListTile(
                      leading: Icon(
                        Icons.call_split_rounded,
                        color: r.enabled
                            ? theme.colorScheme.primary
                            : theme.colorScheme.outline,
                      ),
                      title: Text(r.name),
                      subtitle: Text(
                        '${r.proto.toUpperCase()}  WAN:${r.srcPort}  →  '
                        '${r.destIp}:${r.destPort}',
                      ),
                      trailing: Row(
                        mainAxisSize: MainAxisSize.min,
                        children: [
                          Switch(
                            value: r.enabled,
                            onChanged: _busy ? null : (_) => _toggle(r),
                          ),
                          IconButton(
                            tooltip: 'Delete',
                            icon: const Icon(Icons.delete_outline),
                            onPressed: _busy ? null : () => _delete(r),
                          ),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
          if (_busy) const LinearProgressIndicator(minHeight: 3),
        ],
      ),
    );
  }
}
