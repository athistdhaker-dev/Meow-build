// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _Entry {
  const _Entry(this.command, this.output);
  final String command;
  final String output;
}

/// Simple non-interactive command console that runs through the existing
/// authenticated router session (no SSH credentials needed).
class TerminalScreen extends ConsumerStatefulWidget {
  const TerminalScreen({super.key});

  @override
  ConsumerState<TerminalScreen> createState() => _TerminalScreenState();
}

class _TerminalScreenState extends ConsumerState<TerminalScreen> {
  static const List<String> _quick = [
    'uptime',
    'free -h',
    'df -h',
    'ifstatus wan',
    'ip -br addr',
    'logread | tail -n 30',
    'cat /etc/openwrt_release',
  ];
  static final RegExp _danger = RegExp(
    r'\b(reboot|poweroff|halt|firstboot|sysupgrade|mtd|dd|mkfs|rm\s+-[a-z]*r)\b',
  );
  static const int _maxEntries = 30;
  static const int _maxOutputChars = 20000;

  final TextEditingController _ctrl = TextEditingController();
  final ScrollController _scroll = ScrollController();
  final List<_Entry> _history = [];
  bool _running = false;

  @override
  void dispose() {
    _ctrl.dispose();
    _scroll.dispose();
    super.dispose();
  }

  Future<bool> _confirmDanger(String cmd) async {
    final yes = await showDialog<bool>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Potentially destructive command'),
        content: Text(
          '"$cmd" can reboot the router, erase data or break the '
          'configuration. Run it anyway?',
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(false),
            child: const Text('Cancel'),
          ),
          FilledButton(
            style: FilledButton.styleFrom(
              backgroundColor: Theme.of(ctx).colorScheme.error,
              foregroundColor: Theme.of(ctx).colorScheme.onError,
            ),
            onPressed: () => Navigator.of(ctx).pop(true),
            child: const Text('Run'),
          ),
        ],
      ),
    );
    return yes == true;
  }

  Future<void> _run([String? preset]) async {
    final cmd = (preset ?? _ctrl.text).trim();
    if (cmd.isEmpty || _running) return;
    if (_danger.hasMatch(cmd) && !await _confirmDanger(cmd)) return;
    if (!mounted) return;
    setState(() => _running = true);
    final out = await ExtrasShell(
      ref.read(appStateProvider),
    ).run('( $cmd ) 2>&1');
    if (!mounted) return;
    var text = out.trimRight();
    if (text.isEmpty) text = '(no output)';
    if (text.length > _maxOutputChars) {
      text = '… output truncated …\n${text.substring(text.length - _maxOutputChars)}';
    }
    setState(() {
      _history.add(_Entry(cmd, text));
      if (_history.length > _maxEntries) _history.removeAt(0);
      _running = false;
      _ctrl.clear();
    });
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (_scroll.hasClients) {
        _scroll.animateTo(
          _scroll.position.maxScrollExtent,
          duration: const Duration(milliseconds: 200),
          curve: Curves.easeOut,
        );
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Terminal'),
        actions: [
          IconButton(
            tooltip: 'Copy all',
            icon: const Icon(Icons.copy_rounded),
            onPressed: _history.isEmpty
                ? null
                : () async {
                    await Clipboard.setData(
                      ClipboardData(
                        text: _history
                            .map((e) => '\$ ${e.command}\n${e.output}')
                            .join('\n\n'),
                      ),
                    );
                    if (context.mounted) extrasToast(context, 'Copied');
                  },
          ),
          IconButton(
            tooltip: 'Clear',
            icon: const Icon(Icons.delete_sweep_outlined),
            onPressed: _history.isEmpty
                ? null
                : () => setState(_history.clear),
          ),
        ],
      ),
      body: Column(
        children: [
          SizedBox(
            height: 48,
            child: ListView(
              scrollDirection: Axis.horizontal,
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
              children: [
                for (final c in _quick)
                  Padding(
                    padding: const EdgeInsets.only(right: 8),
                    child: ActionChip(
                      label: Text(c),
                      onPressed: _running ? null : () => _run(c),
                    ),
                  ),
              ],
            ),
          ),
          Expanded(
            child: _history.isEmpty
                ? Center(
                    child: Padding(
                      padding: const EdgeInsets.all(24),
                      child: Text(
                        'Run a command on the router.\nInteractive programs '
                        '(vi, top, passwd) are not supported.',
                        textAlign: TextAlign.center,
                        style: theme.textTheme.bodyMedium?.copyWith(
                          color: theme.colorScheme.onSurfaceVariant,
                        ),
                      ),
                    ),
                  )
                : ListView.builder(
                    controller: _scroll,
                    padding: const EdgeInsets.all(12),
                    itemCount: _history.length,
                    itemBuilder: (context, i) {
                      final e = _history[i];
                      return Padding(
                        padding: const EdgeInsets.only(bottom: 12),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text(
                              '\$ ${e.command}',
                              style: theme.textTheme.bodyMedium?.copyWith(
                                fontFamily: 'monospace',
                                fontWeight: FontWeight.bold,
                                color: theme.colorScheme.primary,
                              ),
                            ),
                            const SizedBox(height: 4),
                            ExtrasMonoBox(e.output),
                          ],
                        ),
                      );
                    },
                  ),
          ),
          if (_running) const LinearProgressIndicator(minHeight: 2),
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
              child: Row(
                children: [
                  Expanded(
                    child: TextField(
                      controller: _ctrl,
                      enabled: !_running,
                      autocorrect: false,
                      enableSuggestions: false,
                      textInputAction: TextInputAction.send,
                      onSubmitted: (_) => _run(),
                      style: const TextStyle(fontFamily: 'monospace'),
                      decoration: InputDecoration(
                        isDense: true,
                        prefixText: '\$ ',
                        hintText: 'command',
                        border: OutlineInputBorder(
                          borderRadius: BorderRadius.circular(12),
                        ),
                      ),
                    ),
                  ),
                  const SizedBox(width: 8),
                  IconButton.filled(
                    tooltip: 'Run',
                    onPressed: _running ? null : _run,
                    icon: const Icon(Icons.play_arrow_rounded),
                  ),
                ],
              ),
            ),
          ),
        ],
      ),
    );
  }
}
