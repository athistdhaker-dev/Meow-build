// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _WanIface {
  const _WanIface(this.name, this.status, this.detail);
  final String name;
  final String status;
  final String detail;
}

/// Multi-WAN (mwan3) status and control.
class MultiWanScreen extends ConsumerStatefulWidget {
  const MultiWanScreen({super.key});

  @override
  ConsumerState<MultiWanScreen> createState() => _MultiWanScreenState();
}

class _MultiWanScreenState extends ConsumerState<MultiWanScreen> {
  bool _loading = true;
  bool _busy = false;
  bool _installed = true;
  bool _running = false;
  List<_WanIface> _ifaces = const [];
  String _raw = '';

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final out = await ExtrasShell(ref.read(appStateProvider)).run(
      '[ -x /etc/init.d/mwan3 ] && echo __INSTALLED__=1 || '
      'echo __INSTALLED__=0; '
      'echo __IFACES__; mwan3 interfaces 2>&1 | head -n 40; '
      'echo __STATUS__; mwan3 status 2>&1 | head -n 120; true',
    );
    var installed = true;
    final ifaces = <_WanIface>[];
    final raw = StringBuffer();
    var section = '';
    final ifRe = RegExp(r'interface\s+(\S+)\s+is\s+(\w+)\s*(.*)');
    for (final line in out.split('\n')) {
      final t = line.trimRight();
      if (t.startsWith('__INSTALLED__=')) {
        installed = t.endsWith('1');
      } else if (t == '__IFACES__') {
        section = 'if';
      } else if (t == '__STATUS__') {
        section = 'st';
      } else if (section == 'if') {
        final m = ifRe.firstMatch(t.trim());
        if (m != null) {
          ifaces.add(_WanIface(m.group(1)!, m.group(2)!, m.group(3)!.trim()));
        }
      } else if (section == 'st') {
        raw.writeln(t);
      }
    }
    if (!mounted) return;
    setState(() {
      _installed = installed;
      _ifaces = ifaces;
      _raw = raw.toString().trim();
      _running = ifaces.isNotEmpty;
      _loading = false;
    });
  }

  Future<void> _install() async {
    setState(() => _busy = true);
    final res = await ExtrasShell(
      ref.read(appStateProvider),
    ).installPackage('mwan3');
    if (!mounted) return;
    setState(() => _busy = false);
    extrasToast(
      context,
      res.ok ? 'mwan3 installed' : 'Install failed: ${res.output}',
      error: !res.ok,
    );
    await _load();
  }

  Future<void> _action(String action) async {
    setState(() => _busy = true);
    final ok = await ExtrasShell(
      ref.read(appStateProvider),
    ).service('mwan3', action);
    if (!mounted) return;
    setState(() => _busy = false);
    extrasToast(context, ok ? 'mwan3 $action done' : 'mwan3 $action failed', error: !ok);
    await _load();
  }

  Color _statusColor(String status, ColorScheme scheme) {
    switch (status.toLowerCase()) {
      case 'online':
        return scheme.primary;
      case 'offline':
        return scheme.error;
      default:
        return scheme.tertiary;
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Scaffold(
      appBar: AppBar(
        title: const Text('Multi-WAN'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: (_loading || _busy) ? null : _load,
          ),
        ],
      ),
      body: _loading
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  if (!_installed)
                    ExtrasInstallCard(
                      title: 'mwan3 is not installed',
                      message:
                          'mwan3 provides WAN failover and load balancing '
                          'across several uplinks.',
                      package: 'mwan3',
                      busy: _busy,
                      onInstall: _install,
                    )
                  else ...[
                    Card(
                      child: Padding(
                        padding: const EdgeInsets.all(16),
                        child: Column(
                          crossAxisAlignment: CrossAxisAlignment.start,
                          children: [
                            Text('Uplinks', style: theme.textTheme.titleMedium),
                            const SizedBox(height: 8),
                            if (_ifaces.isEmpty)
                              const Text(
                                'No tracked interfaces. mwan3 may be stopped '
                                'or not configured yet.',
                              )
                            else
                              for (final i in _ifaces)
                                ListTile(
                                  contentPadding: EdgeInsets.zero,
                                  leading: Icon(
                                    Icons.alt_route_rounded,
                                    color: _statusColor(i.status, theme.colorScheme),
                                  ),
                                  title: Text(i.name),
                                  subtitle: Text(
                                    i.detail.isEmpty ? i.status : i.detail,
                                  ),
                                  trailing: Text(
                                    i.status.toUpperCase(),
                                    style: TextStyle(
                                      fontWeight: FontWeight.bold,
                                      color: _statusColor(i.status, theme.colorScheme),
                                    ),
                                  ),
                                ),
                            const SizedBox(height: 8),
                            Wrap(
                              spacing: 8,
                              runSpacing: 8,
                              children: [
                                FilledButton.tonal(
                                  onPressed: _busy
                                      ? null
                                      : () => _action(_running ? 'restart' : 'start'),
                                  child: Text(_running ? 'Restart' : 'Start'),
                                ),
                                if (_running)
                                  OutlinedButton(
                                    onPressed: _busy ? null : () => _action('stop'),
                                    child: const Text('Stop'),
                                  ),
                                OutlinedButton(
                                  onPressed: _busy ? null : () => _action('enable'),
                                  child: const Text('Enable on boot'),
                                ),
                              ],
                            ),
                            if (_busy)
                              const Padding(
                                padding: EdgeInsets.only(top: 12),
                                child: LinearProgressIndicator(minHeight: 2),
                              ),
                          ],
                        ),
                      ),
                    ),
                    const SizedBox(height: 12),
                    if (_raw.isNotEmpty)
                      ExpansionTile(
                        title: const Text('Full mwan3 status'),
                        children: [ExtrasMonoBox(_raw, maxHeight: 380)],
                      ),
                    const SizedBox(height: 12),
                    Text(
                      'Interfaces, members, policies and rules are defined in '
                      '/etc/config/mwan3. Edit them via LuCI or SSH.',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ],
                ],
              ),
            ),
    );
  }
}
