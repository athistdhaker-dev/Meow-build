// Copyright (C) 2026 @nightcodex7
// Copyright (C) 2025-2026 cogwheel0
// SPDX-License-Identifier: GPL-3.0-or-later

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:yet_another_luci_app/main.dart';
import '../extras_shell.dart';

class _Svc {
  const _Svc(this.name, this.title, this.description, this.icon);
  final String name;
  final String title;
  final String description;
  final IconData icon;
}

class _SvcState {
  const _SvcState({
    required this.installed,
    required this.enabled,
    required this.running,
  });
  final bool installed;
  final bool enabled;
  final bool running;
}

/// Control panel for DNS-level filtering / privacy packages:
/// adblock, banIP and https-dns-proxy (DNS over HTTPS).
class DnsFilteringScreen extends ConsumerStatefulWidget {
  const DnsFilteringScreen({super.key});

  @override
  ConsumerState<DnsFilteringScreen> createState() => _DnsFilteringScreenState();
}

class _DnsFilteringScreenState extends ConsumerState<DnsFilteringScreen> {
  static const List<_Svc> _services = [
    _Svc(
      'adblock',
      'Adblock',
      'Blocks ads and trackers with DNS blocklists.',
      Icons.block_rounded,
    ),
    _Svc(
      'banip',
      'banIP',
      'Blocks malicious IPs, countries and ASNs at the firewall.',
      Icons.gpp_bad_outlined,
    ),
    _Svc(
      'https-dns-proxy',
      'DNS over HTTPS',
      'Encrypts DNS lookups through https-dns-proxy.',
      Icons.lock_outline_rounded,
    ),
  ];

  Map<String, _SvcState> _state = const {};
  bool _loading = true;
  String? _busyName;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) => _load());
  }

  Future<void> _load() async {
    setState(() => _loading = true);
    final out = await ExtrasShell(ref.read(appStateProvider)).run(
      'for S in adblock banip https-dns-proxy; do '
      'if [ -x /etc/init.d/\$S ]; then '
      'EN=no; /etc/init.d/\$S enabled >/dev/null 2>&1 && EN=yes; '
      'RUN=no; /etc/init.d/\$S running >/dev/null 2>&1 && RUN=yes; '
      'echo "SVC|\$S|1|\$EN|\$RUN"; '
      'else echo "SVC|\$S|0|no|no"; fi; done; true',
    );
    final map = <String, _SvcState>{};
    for (final line in out.split('\n')) {
      final p = line.trim().split('|');
      if (p.length == 5 && p[0] == 'SVC') {
        map[p[1]] = _SvcState(
          installed: p[2] == '1',
          enabled: p[3] == 'yes',
          running: p[4] == 'yes',
        );
      }
    }
    if (!mounted) return;
    setState(() {
      _state = map;
      _loading = false;
    });
  }

  Future<void> _action(String name, String action) async {
    setState(() => _busyName = name);
    final ok = await ExtrasShell(ref.read(appStateProvider)).service(name, action);
    if (!mounted) return;
    setState(() => _busyName = null);
    extrasToast(
      context,
      ok ? '$name: $action done' : '$name: $action failed',
      error: !ok,
    );
    await _load();
  }

  Future<void> _install(String name) async {
    setState(() => _busyName = name);
    final res = await ExtrasShell(ref.read(appStateProvider)).installPackage(name);
    if (!mounted) return;
    setState(() => _busyName = null);
    extrasToast(
      context,
      res.ok ? '$name installed' : 'Install failed: ${res.output}',
      error: !res.ok,
    );
    await _load();
  }

  Future<void> _showStatus(_Svc svc) async {
    setState(() => _busyName = svc.name);
    final shell = ExtrasShell(ref.read(appStateProvider));
    final out = await shell.run(
      '/etc/init.d/${svc.name} status 2>&1 | head -n 40; true',
    );
    if (!mounted) return;
    setState(() => _busyName = null);
    await showDialog<void>(
      context: context,
      builder: (ctx) => AlertDialog(
        title: Text('${svc.title} status'),
        content: ExtrasMonoBox(
          out.trim().isEmpty ? 'No status output.' : out.trim(),
          maxHeight: 360,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.of(ctx).pop(),
            child: const Text('Close'),
          ),
        ],
      ),
    );
  }

  Widget _card(BuildContext context, _Svc svc) {
    final theme = Theme.of(context);
    final st = _state[svc.name];
    final busy = _busyName == svc.name;
    if (st == null || !st.installed) {
      return ExtrasInstallCard(
        title: '${svc.title} is not installed',
        message: svc.description,
        package: svc.name,
        busy: busy,
        onInstall: () => _install(svc.name),
      );
    }
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Icon(svc.icon, color: theme.colorScheme.primary),
                const SizedBox(width: 12),
                Expanded(
                  child: Text(svc.title, style: theme.textTheme.titleMedium),
                ),
                Chip(
                  label: Text(st.running ? 'Running' : 'Stopped'),
                  visualDensity: VisualDensity.compact,
                  backgroundColor: st.running
                      ? theme.colorScheme.primaryContainer
                      : theme.colorScheme.surfaceContainerHighest,
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(svc.description, style: theme.textTheme.bodySmall),
            SwitchListTile(
              contentPadding: EdgeInsets.zero,
              title: const Text('Start on boot'),
              value: st.enabled,
              onChanged: busy
                  ? null
                  : (v) => _action(svc.name, v ? 'enable' : 'disable'),
            ),
            Wrap(
              spacing: 8,
              runSpacing: 8,
              children: [
                FilledButton.tonal(
                  onPressed: busy
                      ? null
                      : () => _action(svc.name, st.running ? 'stop' : 'start'),
                  child: Text(st.running ? 'Stop' : 'Start'),
                ),
                OutlinedButton(
                  onPressed: busy ? null : () => _action(svc.name, 'restart'),
                  child: const Text('Restart'),
                ),
                OutlinedButton(
                  onPressed: busy ? null : () => _showStatus(svc),
                  child: const Text('Status'),
                ),
              ],
            ),
            if (busy) const Padding(
              padding: EdgeInsets.only(top: 12),
              child: LinearProgressIndicator(minHeight: 2),
            ),
          ],
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('DNS Filtering & Privacy'),
        actions: [
          IconButton(
            tooltip: 'Refresh',
            icon: const Icon(Icons.refresh_rounded),
            onPressed: _loading ? null : _load,
          ),
        ],
      ),
      body: _loading && _state.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : RefreshIndicator(
              onRefresh: _load,
              child: ListView(
                padding: const EdgeInsets.all(16),
                children: [
                  for (final s in _services) ...[
                    _card(context, s),
                    const SizedBox(height: 12),
                  ],
                  Text(
                    'Detailed lists and resolvers are configured with each '
                    'package\'s own UCI config. Installing packages needs '
                    'free flash space and internet access on the router.',
                    style: Theme.of(context).textTheme.bodySmall?.copyWith(
                      color: Theme.of(context).colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
    );
  }
}
