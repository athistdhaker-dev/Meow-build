import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;
import 'package:shared_preferences/shared_preferences.dart';
import 'legal.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  PaintingBinding.instance.imageCache
    ..maximumSizeBytes = 80 << 20
    ..maximumSize = 120;
  runApp(const MarajApp());
}

const _storage = MethodChannel('maraj/storage');

Future<double> freePercent() async {
  try {
    return (await _storage.invokeMethod<double>('freePercent')) ?? 100;
  } catch (_) {
    return 100;
  }
}

class MarajApp extends StatefulWidget {
  const MarajApp({super.key});
  @override State<MarajApp> createState() => _MarajAppState();
}
class _MarajAppState extends State<MarajApp> {
  ThemeMode mode = ThemeMode.dark;
  @override
  Widget build(BuildContext context) => MaterialApp(
    title: 'Maraj Wallpaper',
    debugShowCheckedModeBanner: false,
    themeMode: mode,
    theme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo, brightness: Brightness.light),
    darkTheme: ThemeData(useMaterial3: true, colorSchemeSeed: Colors.indigo, brightness: Brightness.dark),
    home: Home(onTheme: () => setState(() => mode = mode == ThemeMode.dark ? ThemeMode.light : ThemeMode.dark)),
  );
}

class Wall {
  final String thumb, full, res, id;
  Wall(this.thumb, this.full, this.res, {String? id}) : id = id ?? full;
}

const _hd = '1920x1080', _2k = '2560x1440', _4k = '3840x2160';
const cats = <String, List<String>>{
  'Trending': ['', 'toplist', _hd], 'Latest': ['', 'date_added', _hd],
  'Top Rated': ['', 'toplist', _2k], 'Random': ['', 'random', _hd],
  '2K': ['', 'toplist', _2k], '4K': ['', 'toplist', _4k],
  'AMOLED': ['black', 'toplist', _hd], 'Nature': ['nature', 'toplist', _hd],
  'Mountains': ['mountains', 'toplist', _hd], 'Ocean': ['ocean', 'toplist', _hd],
  'Sunset': ['sunset', 'toplist', _hd], 'Space': ['space', 'toplist', _hd],
  'City': ['city', 'toplist', _hd], 'Architecture': ['architecture', 'toplist', _hd],
  'Cars': ['cars', 'toplist', _hd], 'Animals': ['animals', 'toplist', _hd],
  'Anime': ['anime', 'toplist', _hd], 'Gaming': ['game', 'toplist', _hd],
  'Fantasy': ['fantasy', 'toplist', _hd], 'Technology': ['technology', 'toplist', _hd],
  'Abstract': ['abstract', 'toplist', _hd], 'Minimal': ['minimal', 'toplist', _hd],
};

class SearchFilters {
  String query = '';
  String sort = 'toplist';
  String min = _hd;
  String ratio = '16x9';
  String? color;
  String category = '111';
  String purity = '100';
  SearchFilters copy() => SearchFilters()
    ..query=query ..sort=sort ..min=min ..ratio=ratio ..color=color ..category=category ..purity=purity;
}

Future<List<Wall>> fetchWalls(SearchFilters f, int page) async {
  final params = <String,String>{
    'q': f.query, 'categories': f.category, 'purity': f.purity,
    'sorting': f.sort, 'atleast': f.min, 'page': '$page'
  };
  if (f.ratio.isNotEmpty) params['ratios'] = f.ratio;
  if (f.color != null) params['colors'] = f.color!;
  final r = await http.get(Uri.https('wallhaven.cc', '/api/v1/search', params))
      .timeout(const Duration(seconds: 20));
  if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
  return (jsonDecode(r.body)['data'] as List).map((e) => Wall(
    e['thumbs']['large'], e['path'], e['resolution'], id: '${e['id']}')).toList();
}

class FavoriteStore {
  static const key = 'favorites_v2';
  static Future<Set<String>> load() async {
    final p = await SharedPreferences.getInstance();
    return (p.getStringList(key) ?? <String>[]).toSet();
  }
  static Future<void> toggle(String id) async {
    final p = await SharedPreferences.getInstance();
    final s = (p.getStringList(key) ?? <String>[]).toSet();
    s.contains(id) ? s.remove(id) : s.add(id);
    await p.setStringList(key, s.toList());
  }
}

class DownloadJob {
  final Wall wall;
  double progress;
  String status;
  DownloadJob(this.wall, {this.progress=0, this.status='Queued'});
}

class DownloadManager {
  static final DownloadManager instance = DownloadManager._();
  DownloadManager._();
  final jobs = <DownloadJob>[];
  bool running = false;
  final listeners = <VoidCallback>[];
  void addListener(VoidCallback f) => listeners.add(f);
  void removeListener(VoidCallback f) => listeners.remove(f);
  void notify() { for (final f in [...listeners]) f(); }
  void enqueue(Wall w) {
    if (jobs.any((j) => j.wall.id == w.id && j.status != 'Failed')) return;
    jobs.add(DownloadJob(w));
    notify();
    _run();
  }
  Future<void> _run() async {
    if (running) return;
    running = true;
    try {
      if (!await Gal.hasAccess(toAlbum: true) && !await Gal.requestAccess(toAlbum: true)) {
        for (final j in jobs.where((j) => j.status == 'Queued')) j.status='Permission denied';
        notify(); return;
      }
      for (final job in jobs.where((j) => j.status == 'Queued').toList()) {
        job.status='Downloading'; notify();
        try {
          if (await freePercent() < 20) throw Exception('Storage below 20%');
          final req = http.Request('GET', Uri.parse(job.wall.full));
          final res = await http.Client().send(req).timeout(const Duration(seconds: 60));
          if (res.statusCode != 200) throw Exception('HTTP ${res.statusCode}');
          final total = res.contentLength ?? 0;
          final data = <int>[];
          await for (final chunk in res.stream) {
            data.addAll(chunk);
            if (total > 0) job.progress = data.length / total;
            notify();
          }
          await Gal.putImageBytes(Uint8List.fromList(data), album: 'Maraj Wallpaper');
          job.progress=1; job.status='Completed'; notify();
        } catch (e) {
          job.status='Failed: $e'; notify();
        }
      }
    } finally { running=false; }
  }
  void retry(DownloadJob j) { j.progress=0; j.status='Queued'; notify(); _run(); }
  void clearCompleted() { jobs.removeWhere((j) => j.status == 'Completed'); notify(); }
}

class Home extends StatefulWidget {
  final VoidCallback onTheme;
  const Home({super.key, required this.onTheme});
  @override State<Home> createState() => _HomeState();
}
class _HomeState extends State<Home> {
  String cat='Trending';
  final items=<Wall>[];
  int page=1; bool loading=false; String? error;
  SearchFilters filters=SearchFilters();
  Set<String> favorites={};
  @override void initState(){super.initState(); FavoriteStore.load().then((v){if(mounted)setState(()=>favorites=v);}); load(reset:true);}
  Future<void> load({bool reset=false}) async {
    if(loading) return;
    if(reset){items.clear();page=1;}
    setState(()=>loading=true); error=null;
    try {
      final c=cats[cat]!;
      final f=filters.copy()..query=c[0]..sort=c[1]..min=c[2];
      items.addAll(await fetchWalls(f,page++));
    } catch(e){error='Load nahi hua: $e';}
    if(mounted)setState(()=>loading=false);
  }
  Future<void> openSearch() async {
    final r=await showDialog<SearchFilters>(context:context,builder:(_)=>FilterDialog(initial:filters));
    if(r!=null){filters=r;cat='Search';cats.containsKey(cat);setState((){});await load(reset:true);}
  }
  @override Widget build(BuildContext context)=>Scaffold(
    appBar: AppBar(
      title: Row(children:[ClipRRect(borderRadius:BorderRadius.circular(10),child:Image.asset('assets/logo.png',width:42,height:42)),const SizedBox(width:12),const Text('Maraj Wallpaper')]),
      actions:[
        IconButton(tooltip:'Search & filters',onPressed:openSearch,icon:const Icon(Icons.search)),
        IconButton(tooltip:'Downloads',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const DownloadsScreen())),icon:const Icon(Icons.download)),
        IconButton(tooltip:'Theme',onPressed:widget.onTheme,icon:const Icon(Icons.brightness_6)),
        IconButton(tooltip:'About',onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const InfoScreen())),icon:const Icon(Icons.info_outline)),
      ],
    ),
    body:Padding(padding:const EdgeInsets.fromLTRB(32,8,32,0),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      SizedBox(height:52,child:ListView(scrollDirection:Axis.horizontal,children:[
        for(final k in cats.keys) Padding(padding:const EdgeInsets.only(right:8),child:ChoiceChip(label:Text(k),selected:cat==k,onSelected:(_){cat=k;load(reset:true);}))
      ])),
      if(error!=null) Padding(padding:const EdgeInsets.all(8),child:Text(error!,style:TextStyle(color:Theme.of(context).colorScheme.error))),
      Expanded(child:GridView.builder(
        padding:const EdgeInsets.only(bottom:40,top:8),
        gridDelegate:const SliverGridDelegateWithMaxCrossAxisExtent(maxCrossAxisExtent:360,crossAxisSpacing:16,mainAxisSpacing:16,childAspectRatio:16/9),
        itemCount:items.length,itemBuilder:(_,i){
          if(i>=items.length-4) Future.microtask(load);
          return Tile(wall:items[i],favorite:favorites.contains(items[i].id),onFavorite:() async {await FavoriteStore.toggle(items[i].id);setState(()=>favorites.contains(items[i].id)?favorites.remove(items[i].id):favorites.add(items[i].id));},
            onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>Viewer(items:items,start:i,favorites:favorites,onFavorite:(id)async{await FavoriteStore.toggle(id);final s=await FavoriteStore.load();if(mounted)setState(()=>favorites=s);}))));
        })),
      if(loading)const LinearProgressIndicator(),
    ])),
  );
}

class Tile extends StatefulWidget {
  final Wall wall; final VoidCallback onTap,onFavorite; final bool favorite;
  const Tile({super.key,required this.wall,required this.onTap,required this.onFavorite,required this.favorite});
  @override State<Tile> createState()=>_TileState();
}
class _TileState extends State<Tile>{
  bool focused=false;
  @override Widget build(BuildContext context)=>AnimatedScale(scale:focused?1.025:1,duration:const Duration(milliseconds:120),child:InkWell(
    onTap:widget.onTap,onFocusChange:(v)=>setState(()=>focused=v),borderRadius:BorderRadius.circular(14),
    child:Stack(children:[Container(decoration:BoxDecoration(borderRadius:BorderRadius.circular(14),border:Border.all(color:focused?Theme.of(context).colorScheme.primary:Colors.transparent,width:3)),clipBehavior:Clip.antiAlias,
      child:Image.network(widget.wall.thumb,cacheWidth:520,fit:BoxFit.cover,width:double.infinity,height:double.infinity,errorBuilder:(_,__,___)=>const ColoredBox(color:Colors.black26))),
      Positioned(right:6,top:6,child:IconButton(onPressed:widget.onFavorite,icon:Icon(widget.favorite?Icons.favorite:Icons.favorite_border),style:IconButton.styleFrom(backgroundColor:Colors.black54,foregroundColor:Colors.white))),
      Positioned(left:10,bottom:8,child:Container(padding:const EdgeInsets.symmetric(horizontal:7,vertical:3),decoration:BoxDecoration(color:Colors.black54,borderRadius:BorderRadius.circular(8)),child:Text(widget.wall.res))),
    ])));
}

class FilterDialog extends StatefulWidget {
  final SearchFilters initial;
  const FilterDialog({super.key,required this.initial});
  @override State<FilterDialog> createState()=>_FilterDialogState();
}
class _FilterDialogState extends State<FilterDialog>{
  late SearchFilters f;
  final q=TextEditingController();
  @override void initState(){super.initState();f=widget.initial.copy();q.text=f.query;}
  @override void dispose(){q.dispose();super.dispose();}
  @override Widget build(BuildContext context)=>AlertDialog(
    title:const Text('Advanced Search'),content:SizedBox(width:560,child:SingleChildScrollView(child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[
      TextField(controller:q,autofocus:true,decoration:const InputDecoration(labelText:'Search tags / keywords',prefixIcon:Icon(Icons.search)),onSubmitted:(_){f.query=q.text;}),
      const SizedBox(height:12),const Text('Sort'),
      Wrap(spacing:8,children:[for(final x in {'toplist':'Top rated','date_added':'Latest','random':'Random','views':'Most viewed','favorites':'Most favorited'}.entries)ChoiceChip(label:Text(x.value),selected:f.sort==x.key,onSelected:(_)=>setState(()=>f.sort=x.key))]),
      const SizedBox(height:12),const Text('Minimum resolution'),
      Wrap(spacing:8,children:[for(final x in [_hd,_2k,_4k])ChoiceChip(label:Text(x),selected:f.min==x,onSelected:(_)=>setState(()=>f.min=x))]),
      const SizedBox(height:12),const Text('Aspect ratio'),
      Wrap(spacing:8,children:[for(final x in {'16x9':'16:9','16x10':'16:10','9x16':'9:16','':'Any'}.entries)ChoiceChip(label:Text(x.value),selected:f.ratio==x.key,onSelected:(_)=>setState(()=>f.ratio=x.key))]),
      const SizedBox(height:12),const Text('Color'),
      Wrap(spacing:8,children:[for(final x in {'660000':'Red','0033cc':'Blue','009900':'Green','9900cc':'Purple','000000':'Black','ffffff':'White'}.entries)ChoiceChip(label:Text(x.value),selected:f.color==x.key,onSelected:(_)=>setState(()=>f.color=f.color==x.key?null:x.key))]),
    ]))),actions:[TextButton(onPressed:()=>Navigator.pop(context),child:const Text('Cancel')),FilledButton(onPressed:(){f.query=q.text;Navigator.pop(context,f);},child:const Text('Search'))]);
}

class Viewer extends StatefulWidget {
  final List<Wall> items; final int start; final Set<String> favorites; final Future<void> Function(String) onFavorite;
  const Viewer({super.key,required this.items,required this.start,required this.favorites,required this.onFavorite});
  @override State<Viewer> createState()=>_ViewerState();
}
class _ViewerState extends State<Viewer>{
  late int i=widget.start; Timer? timer; bool auto=false; String status='';
  void say(String s){if(mounted)setState(()=>status=s);}
  void go(int d){setState(()=>i=(i+d+widget.items.length)%widget.items.length);precacheImage(NetworkImage(widget.items[i].full),context);}
  void toggle(){setState(()=>auto=!auto);timer?.cancel();if(auto)timer=Timer.periodic(const Duration(seconds:10),(_)=>go(1));}
  @override void dispose(){timer?.cancel();super.dispose();}
  @override Widget build(BuildContext context){final w=widget.items[i];final fav=widget.favorites.contains(w.id);return Scaffold(backgroundColor:Colors.black,body:Focus(
    autofocus:true,onKeyEvent:(_,e){if(e is! KeyDownEvent)return KeyEventResult.ignored;final k=e.logicalKey;
      if(k==LogicalKeyboardKey.arrowRight)go(1);else if(k==LogicalKeyboardKey.arrowLeft)go(-1);else if(k==LogicalKeyboardKey.arrowUp)toggle();else if(k==LogicalKeyboardKey.select||k==LogicalKeyboardKey.enter)DownloadManager.instance.enqueue(w);else return KeyEventResult.ignored;setState((){});return KeyEventResult.handled;},
    child:Stack(fit:StackFit.expand,children:[
      AnimatedSwitcher(duration:const Duration(milliseconds:350),child:Image.network(w.full,key:ValueKey(w.full),cacheWidth:1920,fit:BoxFit.contain,errorBuilder:(_,__,___)=>const Center(child:Text('Image load nahi hui')))),
      Positioned(top:18,right:18,child:Row(children:[
        IconButton(onPressed:()=>widget.onFavorite(w.id),icon:Icon(fav?Icons.favorite:Icons.favorite_border),style:IconButton.styleFrom(backgroundColor:Colors.black54,foregroundColor:Colors.white)),
        IconButton(onPressed:()=>DownloadManager.instance.enqueue(w),icon:const Icon(Icons.download),style:IconButton.styleFrom(backgroundColor:Colors.black54,foregroundColor:Colors.white)),
      ])),
      Positioned(left:24,bottom:18,child:Container(padding:const EdgeInsets.all(10),color:Colors.black54,child:Text('${i+1}/${widget.items.length} • ${w.res} • ◀ ▶ • OK Download • ▲ Slideshow ${auto?"ON":"OFF"}${status.isEmpty?"":"\n$status"}',style:const TextStyle(fontSize:16,color:Colors.white)))),
    ])));
  }
}

class DownloadsScreen extends StatefulWidget{const DownloadsScreen({super.key});@override State<DownloadsScreen> createState()=>_DownloadsScreenState();}
class _DownloadsScreenState extends State<DownloadsScreen>{
  final dm=DownloadManager.instance;
  @override void initState(){super.initState();dm.addListener(_refresh);}
  void _refresh(){if(mounted)setState((){});}
  @override void dispose(){dm.removeListener(_refresh);super.dispose();}
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('Download Manager'),actions:[TextButton(onPressed:dm.clearCompleted,child:const Text('Clear completed'))]),body:dm.jobs.isEmpty?const Center(child:Text('No downloads yet')):ListView.builder(itemCount:dm.jobs.length,itemBuilder:(_,i){final j=dm.jobs[i];return ListTile(
    leading:Image.network(j.wall.thumb,width:100,height:60,fit:BoxFit.cover,errorBuilder:(_,__,___)=>const Icon(Icons.image)),
    title:Text(j.wall.res),subtitle:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[LinearProgressIndicator(value:j.progress),Text(j.status)]),
    trailing:j.status.startsWith('Failed')?IconButton(onPressed:()=>dm.retry(j),icon:const Icon(Icons.refresh)):Text('${(j.progress*100).round()}%'),
  );}));
}

class InfoScreen extends StatelessWidget{
  const InfoScreen({super.key});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:const Text('About & Legal')),body:ListView(padding:const EdgeInsets.all(32),children:[
    ListTile(autofocus:true,title:const Text('Privacy Policy'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DocPage(title:'Privacy Policy',body:kPrivacy)))),
    ListTile(title:const Text('Terms & Conditions'),onTap:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>DocPage(title:'Terms & Conditions',body:kTerms)))),
    ListTile(title:const Text('Open-source licenses'),onTap:()=>showLicensePage(context:context,applicationName:kAppName,applicationVersion:kVersion)),
    const ListTile(title:Text('$kAppName v$kVersion'),subtitle:Text('Wallpapers: Wallhaven.cc')),
  ]);
}
class DocPage extends StatelessWidget{
  final String title,body; const DocPage({super.key,required this.title,required this.body});
  @override Widget build(BuildContext context)=>Scaffold(appBar:AppBar(title:Text(title)),body:SingleChildScrollView(padding:const EdgeInsets.all(32),child:Text(body,style:const TextStyle(fontSize:20,height:1.5))));
}
