package com.vivekkaushik.wrtpulse.ops

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class NetUsageTest {
    private val sample = listOf(
        "CFG 100 5",
        "NOW 2026-10-12",
        "IFACE eth1",
        "DAYS",
        """{"vnstatversion":"2.12","jsonversion":"2","interfaces":[{"name":"eth1","created":{"date":{"year":2026,"month":9,"day":1}},"traffic":{"total":{"rx":5000000000,"tx":1000000000},"day":[""" +
            """{"id":1,"date":{"year":2026,"month":10,"day":4},"rx":1000,"tx":500},""" +
            """{"id":2,"date":{"year":2026,"month":10,"day":5},"rx":2000,"tx":1000},""" +
            """{"id":3,"date":{"year":2026,"month":10,"day":12},"rx":4000,"tx":2000}]}}]}""",
        "",
        "MONTHS",
        """{"jsonversion":"2","interfaces":[{"name":"eth1","traffic":{"month":[{"id":1,"date":{"year":2026,"month":9},"rx":10,"tx":5}]}}]}""",
        "",
        "END",
    ).joinToString("\n")

    @Test
    fun cycleStartsOnTheConfiguredDay() {
        val ok = NetUsage.parse(sample) as NetUsage.Read.Ok
        val u = ok.summary
        assertEquals(4000L, u.todayRx)
        assertEquals(2000L, u.todayTx)
        // Cycle began 5 Oct: the 5th and the 12th count, the 4th does not.
        assertEquals(6000L, u.cycleRx)
        assertEquals(3000L, u.cycleTx)
        assertEquals(100, u.capGb)
        assertEquals(8, u.cycleElapsedDays)
        assertEquals(31, u.cycleLengthDays)
        assertEquals(5_000_000_000L, u.totalRx)
        assertEquals("2026-09-01", u.since)
        assertEquals(1, u.recentMonths.size)
        assertFalse(u.isCalendarMonth)
    }

    @Test
    fun beforeTheCycleDayTheCycleBeganLastMonth() {
        val early = sample.replace("NOW 2026-10-12", "NOW 2026-10-03").replace("CFG 100 5", "CFG 0 5")
        val u = (NetUsage.parse(early) as NetUsage.Read.Ok).summary
        // Started 5 Sep, so every October day listed counts.
        assertEquals(7000L, u.cycleRx)
        assertEquals(0, u.capGb)
    }

    @Test
    fun missingTrackerIsReported() {
        assertTrue(NetUsage.parse("NONE\n") is NetUsage.Read.NotInstalled)
        assertTrue(NetUsage.parse("NOVNSTAT\n") is NetUsage.Read.NoVnstat)
    }

    @Test
    fun oldVnstatReportsKibibytes() {
        val v1 = sample.replace("\"jsonversion\":\"2\"", "\"jsonversion\":\"1\"")
        val u = (NetUsage.parse(v1) as NetUsage.Read.Ok).summary
        assertEquals(4000L * 1024, u.todayRx)
    }

    @Test
    fun installerBannerMeansDone() {
        assertTrue(NetUsage.installSucceeded("... NetUsage v2.5.0 installed successfully ..."))
        assertFalse(NetUsage.installSucceeded("[ERROR] vnstat could not be installed."))
    }
}
