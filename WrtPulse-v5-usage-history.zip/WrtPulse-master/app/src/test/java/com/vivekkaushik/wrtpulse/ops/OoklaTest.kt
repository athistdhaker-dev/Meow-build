package com.vivekkaushik.wrtpulse.ops

import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class OoklaTest {
    private val resultLine = """{"type":"result","timestamp":"2026-10-12T01:00:00Z","ping":{"jitter":0.8,"latency":9.5,"low":8.1,"high":12.0},""" +
        """"download":{"bandwidth":12500000,"bytes":150000000,"elapsed":12000},"upload":{"bandwidth":2500000,"bytes":30000000,"elapsed":12000},""" +
        """"packetLoss":0,"isp":"Example ISP","interface":{"internalIp":"192.168.1.2","name":"eth1","externalIp":"203.0.113.9"},""" +
        """"server":{"id":1,"name":"Example Net","location":"Mumbai","country":"India"},"result":{"id":"abc","url":"https://www.speedtest.net/result/c/abc"}}"""

    @Test
    fun resultLineBecomesMbps() {
        val parsed = Ookla.parseResult("{\"type\":\"log\",\"level\":\"info\",\"message\":\"hi\"}\n$resultLine\n")
        val ok = parsed as Ookla.Parsed.Ok
        assertEquals(100f, ok.result.downMbps, 0.01f)   // 12.5 MB/s = 100 Mbps
        assertEquals(20f, ok.result.upMbps, 0.01f)
        assertEquals(9.5f, ok.result.pingMs, 0.01f)
        assertEquals("Example Net · Mumbai, India", ok.result.server)
        assertEquals("https://www.speedtest.net/result/c/abc", ok.result.resultUrl)
    }

    @Test
    fun errorLogBecomesTheMessage() {
        val out = "{\"type\":\"log\",\"level\":\"error\",\"message\":\"Cannot reach the server\"}\n"
        assertEquals(Ookla.Parsed.Failed("Cannot reach the server"), Ookla.parseResult(out))
    }

    @Test
    fun noJsonIsAFailure() {
        assertTrue(Ookla.parseResult("sh: speedtest: not found") is Ookla.Parsed.Failed)
    }

    @Test
    fun architecturesMapToOoklaBuilds() {
        assertEquals("aarch64", Ookla.buildFor("aarch64"))
        assertEquals("armhf", Ookla.buildFor("armv7l"))
        assertEquals("x86_64", Ookla.buildFor("x86_64"))
        assertNull(Ookla.buildFor("mips"))
        assertNull(Ookla.buildFor("mipsel"))
    }

    @Test
    fun findOutputIsRead() {
        assertEquals(Ookla.Found.Installed("/usr/bin/speedtest"), Ookla.parseFind("/usr/bin/speedtest\n"))
        assertEquals(Ookla.Found.Missing("aarch64"), Ookla.parseFind("none\naarch64\n"))
        assertEquals(Ookla.Found.Unsupported("mips"), Ookla.parseFind("none\nmips\n"))
    }

    @Test
    fun runRefusesAnOddPath() {
        assertNotNull(Ookla.run("/tmp/wrtpulse-ookla/speedtest"))
        assertNull(Ookla.run("/tmp/x; reboot"))
    }
}
