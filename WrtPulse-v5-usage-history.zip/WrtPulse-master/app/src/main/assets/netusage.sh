#!/bin/sh
#
# NetUsage v2.4 - Router Data Usage Dashboard for OpenWrt
# ----------------------------------------------------
# LuCI page under Status -> Data Usage, backed by vnstat (+ nlbwmon for devices).
#
# Tabs:  Daily | Monthly | Per device (daily + monthly) | Device control | Speed tests | Settings
# Device control: block / pause by MAC (own nftables table, survives reboot),
#   per-device live speed and daily / monthly limits with optional auto pause.
# Also:  billing-cycle cap + projection, live speed, vnstat unit auto-detect.
# Speed tests: Ookla CLI, history log, CSV export, optional scheduled runs.
# Reboot-safe: vnstat DB lives on flash (/etc/vnstat), per-device buffer is
# flushed at shutdown. UI: liquid-glass colourful theme.
#
# Per-device stats: nlbwmon counters are sampled every 5 min by a cron job
# (/usr/bin/netusage-collect) and stored per day in /etc/netusage/devices.db.
#
# Base project: https://github.com/RichardDawkinsIN/OpenWRT-NetUsage-Tracker (MIT)
#
set -e

SCRIPT_VERSION="2.5.0"

log()  { printf '[INFO]  %s\n' "$1"; }
warn() { printf '[WARN]  %s\n' "$1"; }
ok()   { printf '[OK]    %s\n' "$1"; }
err()  { printf '[ERROR] %s\n' "$1" >&2; }

if [ "$1" = "--uninstall" ]; then
	log "Removing NetUsage (vnstat, nlbwmon, the speedtest CLI and /etc/netusage data are left in place)..."
	nft delete table inet netusage 2>/dev/null || true
	[ -x /etc/init.d/netusage ] && /etc/init.d/netusage disable 2>/dev/null
	rm -f /etc/init.d/netusage
	rm -f /usr/libexec/rpcd/netusage /usr/bin/netusage-collect /usr/bin/netusage-speedtest /usr/bin/netusage-devctl \
	      /usr/share/rpcd/acl.d/luci-app-netusage.json \
	      /usr/share/luci/menu.d/luci-app-netusage.json \
	      /www/luci-static/resources/view/netusage.js
	[ -f /etc/crontabs/root ] && sed -i '/netusage-collect/d;/netusage-speedtest/d;/netusage-devctl/d' /etc/crontabs/root
	/etc/init.d/cron restart 2>/dev/null || true
	/etc/init.d/rpcd restart
	rm -f /tmp/luci-indexcache* 2>/dev/null || true
	rm -rf /tmp/luci-modulecache/* 2>/dev/null || true
	ok "Removed. Delete /etc/config/netusage and /etc/netusage manually if unwanted."
	exit 0
fi

log "NetUsage installer v${SCRIPT_VERSION}"

log "Removing legacy Lua-based install (if present)..."
rm -f /usr/lib/lua/luci/controller/netusage.lua 2>/dev/null || true
rm -rf /usr/lib/lua/luci/view/netusage 2>/dev/null || true

log "Detecting WAN interface..."
WAN_IFACE=$(ubus call network.interface.wan status 2>/dev/null | jsonfilter -e '@.l3_device' 2>/dev/null)
[ -z "$WAN_IFACE" ] && WAN_IFACE=$(ip route show default 2>/dev/null | awk '{print $5; exit}')
[ -z "$WAN_IFACE" ] && WAN_IFACE="eth1"
ok "WAN interface detected: ${WAN_IFACE}"

log "Installing vnstat..."
if command -v apk >/dev/null 2>&1; then
	PKG_MGR="apk"
	apk update || warn "apk update failed, trying install anyway"
	command -v vnstat >/dev/null 2>&1 || apk add vnstat || apk add vnstat2 || true
elif command -v opkg >/dev/null 2>&1; then
	PKG_MGR="opkg"
	opkg update || warn "opkg update failed, trying install anyway"
	command -v vnstat >/dev/null 2>&1 || opkg install vnstat || opkg install vnstat2 || true
else
	err "No supported package manager found (apk or opkg required)."
	exit 1
fi
if ! command -v vnstat >/dev/null 2>&1; then
	err "vnstat could not be installed. Check internet / package feeds and retry."
	exit 1
fi
ok "vnstat installed via ${PKG_MGR}"

log "Making vnstat data survive reboots..."
VCONF=/etc/vnstat.conf
VDIR=$(sed -n -E 's/^[[:space:]]*DatabaseDir[[:space:]]+"?([^"]*)"?.*/\1/p' "$VCONF" 2>/dev/null | tail -n 1)
[ -n "$VDIR" ] || VDIR=/var/lib/vnstat
case "$VDIR" in
	/etc/*|/overlay/*|/mnt/*|/opt/*)
		ok "vnstat database already on persistent storage (${VDIR})"
		;;
	*)
		log "vnstat database is in ${VDIR} (RAM, wiped on reboot) - moving to /etc/vnstat"
		/etc/init.d/vnstat stop >/dev/null 2>&1 || true
		mkdir -p /etc/vnstat
		if [ -d "$VDIR" ] && [ -n "$(ls -A "$VDIR" 2>/dev/null)" ]; then
			if [ ! -f /etc/vnstat/vnstat.db ] || [ "$VDIR/vnstat.db" -nt /etc/vnstat/vnstat.db ]; then
				cp -a "$VDIR"/. /etc/vnstat/ 2>/dev/null || true
			fi
		fi
		touch "$VCONF"
		sed -i -E '/^[[:space:]]*#?[[:space:]]*(DatabaseDir|SaveInterval)[[:space:]]/d' "$VCONF"
		echo 'DatabaseDir "/etc/vnstat"' >> "$VCONF"
		echo 'SaveInterval 15' >> "$VCONF"
		chown -R vnstat:vnstat /etc/vnstat 2>/dev/null || true
		ok "vnstat database now in /etc/vnstat (saved every 15 min and at shutdown)"
		;;
esac

log "Configuring vnstat for interface ${WAN_IFACE}..."
mkdir -p /etc/vnstat
vnstat --add -i "$WAN_IFACE" >/dev/null 2>&1 || vnstat --create -i "$WAN_IFACE" >/dev/null 2>&1 || true
/etc/init.d/vnstat enable
/etc/init.d/vnstat restart 2>/dev/null || /etc/init.d/vnstat start
ok "vnstat service enabled and running"

log "Installing nlbwmon (per-device usage)..."
DEV_OK=1
if ! command -v nlbw >/dev/null 2>&1; then
	if [ "$PKG_MGR" = "apk" ]; then
		apk add nlbwmon || DEV_OK=0
	else
		opkg install nlbwmon || DEV_OK=0
	fi
fi
if [ "$DEV_OK" = "1" ] && command -v nlbw >/dev/null 2>&1; then
	/etc/init.d/nlbwmon enable
	/etc/init.d/nlbwmon restart 2>/dev/null || /etc/init.d/nlbwmon start
	ok "nlbwmon running"
	NLBW_RI=$(uci -q get "nlbwmon.@nlbwmon[0].refresh_interval" 2>/dev/null || true)
	if [ "$NLBW_RI" != "5s" ]; then
		if uci -q set "nlbwmon.@nlbwmon[0].refresh_interval=5s" && uci -q commit nlbwmon; then
			/etc/init.d/nlbwmon restart >/dev/null 2>&1 || true
			ok "nlbwmon refresh interval set to 5s (live per-device speed)"
		else
			warn "Could not set the nlbwmon refresh interval - per-device live speed will update slowly."
		fi
	fi
else
	DEV_OK=0
	warn "nlbwmon not installed - the Per device tab will stay empty."
fi

log "Setting up Ookla speedtest CLI (Speed tests tab)..."
ST_OK=0
if command -v ookla-speedtest >/dev/null 2>&1 || { command -v speedtest >/dev/null 2>&1 && speedtest --version 2>&1 | grep -qi ookla; }; then
	ST_OK=1
else
	case "$(uname -m)" in
		aarch64|arm64)        ST_ARCH="aarch64" ;;
		armv7*|armv8l)        ST_ARCH="armhf" ;;
		armv6*|armv5*)        ST_ARCH="armel" ;;
		x86_64)               ST_ARCH="x86_64" ;;
		i386|i486|i586|i686)  ST_ARCH="i386" ;;
		*)                    ST_ARCH="" ;;
	esac
	if [ -z "$ST_ARCH" ]; then
		warn "No Ookla CLI build for CPU '$(uname -m)' (MIPS is not supported) - Speed tests tab disabled."
	else
		ST_TMP=/tmp/nu-speedtest
		rm -rf "$ST_TMP"; mkdir -p "$ST_TMP"
		ST_URL="https://install.speedtest.net/app/cli/ookla-speedtest-1.2.0-linux-${ST_ARCH}.tgz"
		if command -v curl >/dev/null 2>&1; then
			curl -fsSL "$ST_URL" -o "$ST_TMP/st.tgz" || true
		else
			wget -q -O "$ST_TMP/st.tgz" "$ST_URL" || true
		fi
		if [ -s "$ST_TMP/st.tgz" ] && tar -xzf "$ST_TMP/st.tgz" -C "$ST_TMP" 2>/dev/null && [ -f "$ST_TMP/speedtest" ]; then
			cp "$ST_TMP/speedtest" /usr/bin/ookla-speedtest && chmod +x /usr/bin/ookla-speedtest && ST_OK=1
		else
			warn "Could not download the Ookla CLI (needs HTTPS support, e.g. ca-bundle) - Speed tests tab disabled."
		fi
		rm -rf "$ST_TMP"
	fi
fi
if [ "$ST_OK" = "1" ]; then
	ST_BIN=$(command -v ookla-speedtest || command -v speedtest || true)
	if [ -z "$ST_BIN" ] || ! "$ST_BIN" --version >/dev/null 2>&1; then
		ST_OK=0
		rm -f /usr/bin/ookla-speedtest
		warn "Ookla CLI does not run on this router - Speed tests tab disabled."
	else
		ok "Ookla speedtest CLI ready"
	fi
fi

log "Writing UCI configuration..."
if [ ! -f /etc/config/netusage ]; then
	cat > /etc/config/netusage <<EOF
config netusage 'main'
	option iface '$WAN_IFACE'
	option cap_gb '0'
	option cycle_day '1'
	option st_hours '0'
EOF
	ok "Config created at /etc/config/netusage"
else
	ok "Existing /etc/config/netusage kept"
fi

log "Installing per-device collector..."
mkdir -p /etc/netusage
touch /etc/netusage/devices.db
cat > /usr/bin/netusage-collect <<'COLEOF'
#!/bin/sh
# Samples nlbwmon per-MAC counters every 5 min and adds the deltas to today's
# totals in RAM. The RAM buffer is merged into flash (DB) about once an hour,
# at shutdown (/etc/init.d/netusage) and on "netusage-collect --flush".
# A baseline snapshot is kept on flash too, so a reboot neither loses the
# traffic since the last sample nor double counts persisted nlbwmon counters.
# DB line format:  YYYY-MM-DD  mac  rx_bytes  tx_bytes

DB="${NU_DB:-/etc/netusage/devices.db}"
SNAP="${NU_SNAP:-/etc/netusage/last.snap}"
CUR=/tmp/netusage-cur
LAST=/tmp/netusage-last
PEND="${NU_PEND:-/tmp/netusage-pending}"
CTL="${NU_CTL:-/etc/netusage/devctl.db}"
LIM="${NU_LIM:-/etc/netusage/limits.db}"
DEVCTL="${NU_DEVCTL:-/usr/bin/netusage-devctl}"
TODAY=$(date +%Y-%m-%d)
FORCE=0
[ "$1" = "--flush" ] && FORCE=1

mkdir -p "$(dirname "$DB")"
[ -f "$DB" ] || : > "$DB"

# /tmp is empty after a reboot: restore the baseline saved at the last flush
if [ ! -f "$LAST" ] && [ -f "$SNAP" ]; then cp "$SNAP" "$LAST"; fi

flush() {
	if [ -f "$PEND" ] && [ "$(wc -l < "$PEND" | tr -d ' ')" -gt 1 ]; then
		PDAY=$(head -n 1 "$PEND")
		CUTOFF=$(date -d "@$(( $(date +%s) - 34560000 ))" +%Y-%m-%d 2>/dev/null || echo 0000-00-00)
		awk -v day="$PDAY" -v cutoff="$CUTOFF" '
			FNR == NR { if (FNR > 1) { prx[$1] += $2; ptx[$1] += $3 } next }
			{ if ($1 < cutoff) next
			  if ($1 == day && ($2 in prx)) { $3 += prx[$2]; $4 += ptx[$2]; done[$2] = 1 }
			  printf "%s %s %.0f %.0f\n", $1, $2, $3, $4 }
			END { for (m in prx) if (!(m in done)) printf "%s %s %.0f %.0f\n", day, m, prx[m], ptx[m] }
		' "$PEND" "$DB" > "$DB.tmp" && mv "$DB.tmp" "$DB" && printf '%s\n' "$PDAY" > "$PEND"
	fi
	if [ -f "$LAST" ]; then cp "$LAST" "$SNAP"; fi
	return 0
}

# Per-device limits (/etc/netusage/limits.db: mac|daily_mb|monthly_mb|warn/pause|snooze_until).
# Devices over their limit with action "pause" are paused until the day / month ends.
enforce_limits() {
	[ -s "$LIM" ] && [ -x "$DEVCTL" ] || return 0
	[ -f "$CTL" ] || : > "$CTL"
	PF="$PEND"; [ -f "$PF" ] || PF=/dev/null
	NOW=$(date +%s)
	MONTH=${TODAY%-*}
	HITS=$(awk -v today="$TODAY" -v month="$MONTH" -v now="$NOW" -v limf="$LIM" -v dbf="$DB" -v pendf="$PF" -v ctlf="$CTL" '
		FILENAME == limf  { split($0, f, "|"); if (f[1] != "") { d[f[1]] = f[2] + 0; m[f[1]] = f[3] + 0; a[f[1]] = f[4]; s[f[1]] = f[5] + 0 } next }
		FILENAME == ctlf  { split($0, f, "|"); if (f[1] != "" && (f[3] == 0 || f[3] > now)) busy[f[1]] = 1; next }
		FILENAME == dbf   { split($0, f, " "); if (f[1] == today) td[f[2]] += f[3] + f[4]; if (substr(f[1], 1, 7) == month) mo[f[2]] += f[3] + f[4]; next }
		FILENAME == pendf { if (FNR == 1) { pday = $1; next } split($0, f, " "); if (pday == today) td[f[1]] += f[2] + f[3]; if (substr(pday, 1, 7) == month) mo[f[1]] += f[2] + f[3]; next }
		END { for (k in d) {
			if (a[k] != "pause" || busy[k] || s[k] > now) continue
			dh = (d[k] > 0 && td[k] >= d[k] * 1048576); mh = (m[k] > 0 && mo[k] >= m[k] * 1048576)
			if (dh || mh) print k, (mh ? "month" : "day") } }
	' "$LIM" "$CTL" "$DB" "$PF")
	[ -n "$HITS" ] || return 0
	printf '%s\n' "$HITS" | while read -r MAC WHY; do
		if [ "$WHY" = "month" ]; then
			Y=${TODAY%%-*}; M=${TODAY#*-}; M=${M%%-*}; M=$(echo "$M" | sed 's/^0//')
			if [ "$M" -ge 12 ]; then Y=$((Y + 1)); M=1; else M=$((M + 1)); fi
			EXP=$(date -d "$(printf '%04d-%02d-01' "$Y" "$M") 00:00:00" +%s 2>/dev/null)
		else
			D0=$(date -d "$TODAY 00:00:00" +%s 2>/dev/null)
			case "$D0" in ''|*[!0-9]*) continue ;; esac
			EXP=$((D0 + 86400))
		fi
		case "$EXP" in ''|*[!0-9]*) continue ;; esac
		"$DEVCTL" autopause "$MAC" "$EXP" >/dev/null 2>&1
	done
}

sample() {
	command -v nlbw >/dev/null 2>&1 || return 1
	JSON=$(nlbw -c json -g mac 2>/dev/null)
	[ -n "$JSON" ] || return 1
	COLS=$(jsonfilter -s "$JSON" -e '@.columns[*]' | tr '\n' ' ')
	jsonfilter -s "$JSON" -e '@.data[*]' | awk -v cols="$COLS" '
		BEGIN { n = split(cols, c, " "); for (i = 1; i <= n; i++) {
			if (c[i] == "mac") im = i; if (c[i] == "rx_bytes") ir = i; if (c[i] == "tx_bytes") it = i } }
		{ gsub(/\[|\]|"| /, ""); split($0, f, ",");
		  if (im && ir && it) printf "%s %.0f %.0f\n", tolower(f[im]), f[ir], f[it] }' > "$CUR"
	[ -s "$CUR" ]
}

if sample; then
	if [ -f "$PEND" ] && [ "$(head -n 1 "$PEND")" != "$TODAY" ]; then
		flush
		printf '%s\n' "$TODAY" > "$PEND"
	fi
	[ -f "$PEND" ] || printf '%s\n' "$TODAY" > "$PEND"
	if [ -f "$LAST" ]; then
		awk '
			FNR == NR { pr[$1] = $2; pt[$1] = $3; next }
			{ dr = $2; dt = $3
			  if ($1 in pr) { dr = $2 - pr[$1]; dt = $3 - pt[$1]; if (dr < 0 || dt < 0) { dr = $2; dt = $3 } }
			  if (dr > 0 || dt > 0) printf "%s %.0f %.0f\n", $1, dr, dt }
		' "$LAST" "$CUR" >> "$PEND"
	fi
	cp "$CUR" "$LAST"
	enforce_limits
fi

if [ "$FORCE" = "1" ] || [ "$(date +%M)" -lt 5 ] || [ ! -s "$DB" ]; then
	flush
fi
exit 0
COLEOF
chmod +x /usr/bin/netusage-collect

mkdir -p /etc/crontabs
touch /etc/crontabs/root
grep -q netusage-collect /etc/crontabs/root || echo '*/5 * * * * /usr/bin/netusage-collect' >> /etc/crontabs/root
/etc/init.d/cron enable 2>/dev/null || true
/etc/init.d/cron restart 2>/dev/null || true
ok "Collector scheduled every 5 minutes"

cat > /etc/init.d/netusage <<'INITEOF'
#!/bin/sh /etc/rc.common
# Writes buffered per-device usage to flash before shutdown / reboot.
START=98
STOP=5
start() { /usr/bin/netusage-devctl apply; }
stop() { /usr/bin/netusage-collect --flush; }
shutdown() { /usr/bin/netusage-collect --flush; }
INITEOF
chmod +x /etc/init.d/netusage
/etc/init.d/netusage enable 2>/dev/null || true
ok "Shutdown flush hook installed (/etc/init.d/netusage)"

log "Installing device control (block / pause by MAC)..."
if ! command -v nft >/dev/null 2>&1; then warn "nft not found - Device control needs firewall4 / nftables."; fi
cat > /usr/bin/netusage-devctl <<'DCEOF'
#!/bin/sh
# netusage-devctl - block / pause LAN devices by MAC address using an own
# nftables table (inet netusage), so firewall reloads do not touch it.
# State lives in /etc/netusage/devctl.db and is re-applied at boot:
#   mac|mode|expiry|name|src
#   mode   block = no internet and no router access
#          pause = no internet only (router and LAN stay reachable)
#   expiry unix time when the entry ends, 0 = until unblocked
#   src    user | limit
#
#   netusage-devctl block MAC [NAME]
#   netusage-devctl pause MAC MINUTES [NAME]     (MINUTES 0 = until unblocked)
#   netusage-devctl unblock MAC
#   netusage-devctl autopause MAC EXPIRY_EPOCH   (used by per-device limits)
#   netusage-devctl limit MAC DAILY_MB MONTHLY_MB warn|pause
#   netusage-devctl list | clear | apply | tick

DB="${NU_CTL:-/etc/netusage/devctl.db}"
LIM="${NU_LIM:-/etc/netusage/limits.db}"
LEASES="${NU_LEASES:-/tmp/dhcp.leases}"
NFT="${NU_NFT:-nft}"
LASTR="${NU_NFTLAST:-/tmp/netusage-nft.last}"

mkdir -p "$(dirname "$DB")"
[ -f "$DB" ] || : > "$DB"
[ -f "$LIM" ] || : > "$LIM"

die() { echo "$1" >&2; exit 1; }
lower() { printf '%s' "$1" | tr 'A-Z' 'a-z'; }
valid_mac() { printf '%s' "$1" | grep -Eq '^[0-9a-f]{2}(:[0-9a-f]{2}){5}$'; }
clean_name() { printf '%s' "$1" | tr -cd 'A-Za-z0-9._ -' | cut -c1-40; }

name_of() {
	awk -v m="$1" 'tolower($2) == m && $4 != "*" { print $4; exit }' "$LEASES" 2>/dev/null
}

ips4_of() {
	{
		awk -v m="$1" 'tolower($2) == m { print $3 }' "$LEASES" 2>/dev/null
		ip -4 neigh show 2>/dev/null | awk -v m="$1" '{ for (i = 1; i < NF; i++) if ($i == "lladdr" && tolower($(i + 1)) == m) { print $1; break } }'
	} | sort -u
}

ips6_of() {
	ip -6 neigh show 2>/dev/null | awk -v m="$1" '{ for (i = 1; i < NF; i++) if ($i == "lladdr" && tolower($(i + 1)) == m && $1 !~ /^fe80/) { print $1; break } }' | sort -u
}

prune() {
	NOW=$(date +%s)
	awk -F'|' -v now="$NOW" '$3 != 0 && $3 <= now { next } { print }' "$DB" > "$DB.tmp"
	if [ "$(cat "$DB.tmp")" != "$(cat "$DB")" ]; then mv "$DB.tmp" "$DB"; else rm -f "$DB.tmp"; fi
}

drop_entry() {
	grep -v "^$1|" "$DB" > "$DB.tmp"
	mv "$DB.tmp" "$DB"
}

add_entry() {
	printf '%s|%s|%s|%s|%s\n' "$1" "$2" "$3" "$4" "$5" >> "$DB"
}

build_rules() {
	NOW=$(date +%s)
	BLK=""; PAU=""; I4=""; I6=""
	while IFS='|' read -r mac mode exp name src; do
		[ -n "$mac" ] || continue
		if [ "$exp" != "0" ] && [ "$exp" -le "$NOW" ] 2>/dev/null; then continue; fi
		if [ "$mode" = "block" ]; then BLK="${BLK:+$BLK, }$mac"; else PAU="${PAU:+$PAU, }$mac"; fi
		for a in $(ips4_of "$mac"); do I4="${I4:+$I4, }$a"; done
		for a in $(ips6_of "$mac"); do I6="${I6:+$I6, }$a"; done
	done < "$DB"
	[ -n "$BLK$PAU" ] || return 0
	E_BLK=""; E_PAU=""; E_I4=""; E_I6=""
	[ -n "$BLK" ] && E_BLK="elements = { $BLK }"
	[ -n "$PAU" ] && E_PAU="elements = { $PAU }"
	[ -n "$I4" ] && E_I4="elements = { $I4 }"
	[ -n "$I6" ] && E_I6="elements = { $I6 }"
	cat <<RULES
table inet netusage {
	set blk_mac {
		type ether_addr
		$E_BLK
	}
	set pau_mac {
		type ether_addr
		$E_PAU
	}
	set blk_ip4 {
		type ipv4_addr
		$E_I4
	}
	set blk_ip6 {
		type ipv6_addr
		$E_I6
	}
	chain fwd {
		type filter hook forward priority -10; policy accept;
		ether saddr @blk_mac counter drop
		ether saddr @pau_mac counter drop
		ip daddr @blk_ip4 counter drop
		ip6 daddr @blk_ip6 counter drop
	}
	chain inp {
		type filter hook input priority -10; policy accept;
		ether saddr @blk_mac counter drop
	}
}
RULES
}

apply() {
	command -v "$NFT" >/dev/null 2>&1 || die "nft not found (firewall4 / nftables required)"
	prune
	RULES=$(build_rules)
	{
		echo "table inet netusage"
		echo "delete table inet netusage"
		[ -n "$RULES" ] && echo "$RULES"
	} | "$NFT" -f - || die "nft could not load the rules"
	if [ -n "$RULES" ]; then printf '%s' "$RULES" > "$LASTR"; else rm -f "$LASTR"; fi
	return 0
}

flush_ct() {
	command -v conntrack >/dev/null 2>&1 || return 0
	for a in $(ips4_of "$1"); do
		conntrack -D -s "$a" >/dev/null 2>&1
		conntrack -D -d "$a" >/dev/null 2>&1
	done
	for a in $(ips6_of "$1"); do
		conntrack -f ipv6 -D -s "$a" >/dev/null 2>&1
		conntrack -f ipv6 -D -d "$a" >/dev/null 2>&1
	done
	return 0
}

need_mac() {
	MAC=$(lower "$1")
	valid_mac "$MAC" || die "invalid MAC address"
}

case "$1" in
	block)
		need_mac "$2"
		NM=$(clean_name "$3"); [ -n "$NM" ] || NM=$(name_of "$MAC")
		drop_entry "$MAC"
		add_entry "$MAC" block 0 "$NM" user
		apply && flush_ct "$MAC"
		;;
	pause)
		need_mac "$2"
		MIN="$3"; case "$MIN" in ''|*[!0-9]*) MIN=0 ;; esac
		EXP=0; [ "$MIN" -gt 0 ] && EXP=$(( $(date +%s) + MIN * 60 ))
		NM=$(clean_name "$4"); [ -n "$NM" ] || NM=$(name_of "$MAC")
		drop_entry "$MAC"
		add_entry "$MAC" pause "$EXP" "$NM" user
		apply && flush_ct "$MAC"
		;;
	autopause)
		need_mac "$2"
		EXP="$3"; case "$EXP" in ''|*[!0-9]*) die "bad expiry" ;; esac
		if grep -q "^$MAC|" "$DB"; then exit 0; fi
		add_entry "$MAC" pause "$EXP" "$(name_of "$MAC")" limit
		apply && flush_ct "$MAC"
		;;
	unblock)
		need_mac "$2"
		drop_entry "$MAC"
		EOD=$(date -d "$(date +%Y-%m-%d) 23:59:59" +%s 2>/dev/null || echo 0)
		awk -F'|' -v OFS='|' -v m="$MAC" -v u="$EOD" '$1 == m { $5 = u } { print }' "$LIM" > "$LIM.tmp" && mv "$LIM.tmp" "$LIM"
		apply
		;;
	clear)
		: > "$DB"
		apply
		;;
	limit)
		need_mac "$2"
		D="$3"; case "$D" in ''|*[!0-9]*) D=0 ;; esac
		M="$4"; case "$M" in ''|*[!0-9]*) M=0 ;; esac
		A="$5"; [ "$A" = "pause" ] || A=warn
		grep -v "^$MAC|" "$LIM" > "$LIM.tmp"
		mv "$LIM.tmp" "$LIM"
		if [ "$D" -gt 0 ] || [ "$M" -gt 0 ]; then printf '%s|%s|%s|%s|0\n' "$MAC" "$D" "$M" "$A" >> "$LIM"; fi
		;;
	list)
		prune
		cat "$DB"
		;;
	apply)
		apply
		;;
	tick)
		if [ ! -s "$DB" ] && [ ! -f "$LASTR" ]; then exit 0; fi
		prune
		RULES=$(build_rules)
		if [ "$RULES" != "$(cat "$LASTR" 2>/dev/null)" ]; then apply; fi
		;;
	*)
		die "usage: netusage-devctl block|pause|unblock|autopause|limit|list|clear|apply|tick"
		;;
esac
exit 0
DCEOF
chmod +x /usr/bin/netusage-devctl
mkdir -p /etc/crontabs
touch /etc/crontabs/root
grep -q netusage-devctl /etc/crontabs/root || echo '* * * * * /usr/bin/netusage-devctl tick' >> /etc/crontabs/root
/etc/init.d/cron restart 2>/dev/null || true
ok "Device control installed"

log "Installing speed test runner..."
cat > /usr/bin/netusage-speedtest <<'STEOF'
#!/bin/sh
# Runs one Ookla speed test and appends the result to the history file.
# History line:  epoch|server|isp|ping_ms|down_mbps|up_mbps|loss_pct|result_url

DB="${NU_STDB:-/etc/netusage/speedtests.db}"
LOCK="${NU_STLOCK:-/tmp/netusage-speedtest.lock}"
ERRF="${NU_STERR:-/tmp/netusage-speedtest.err}"

BIN=$(command -v ookla-speedtest || command -v speedtest)
if [ -z "$BIN" ]; then
	echo "speedtest CLI not installed" > "$ERRF"
	exit 1
fi

if [ -f "$LOCK" ] && kill -0 "$(cat "$LOCK" 2>/dev/null)" 2>/dev/null; then
	exit 0
fi
echo $$ > "$LOCK"
trap 'rm -f "$LOCK"' EXIT INT TERM

: > "$ERRF"
OUT=$("$BIN" --accept-license --accept-gdpr --format=json 2>&1)
RES=$(printf '%s\n' "$OUT" | grep '"type":"result"' | tail -n 1)
if [ -z "$RES" ]; then
	LOGL=$(printf '%s\n' "$OUT" | grep '"level":"error"' | tail -n 1)
	if [ -n "$LOGL" ]; then
		MSG=$(jsonfilter -s "$LOGL" -e '@.message' 2>/dev/null)
	else
		MSG=$(printf '%s\n' "$OUT" | tail -n 1)
	fi
	[ -n "$MSG" ] || MSG="speedtest returned no result"
	printf '%s\n' "$MSG" | cut -c1-200 > "$ERRF"
	exit 1
fi

j() { jsonfilter -s "$RES" -e "$1" 2>/dev/null; }
PING=$(j '@.ping.latency')
DL=$(j '@.download.bandwidth')
UL=$(j '@.upload.bandwidth')
LOSS=$(j '@.packetLoss')
ISP=$(j '@.isp')
SNAME=$(j '@.server.name')
SLOC=$(j '@.server.location')
URL=$(j '@.result.url')

if [ -z "$DL" ] || [ -z "$UL" ]; then
	echo "incomplete speedtest result" > "$ERRF"
	exit 1
fi

LINE=$(awk -v p="$PING" -v d="$DL" -v u="$UL" -v l="$LOSS" -v n="$SNAME" -v loc="$SLOC" -v i="$ISP" -v url="$URL" -v ts="$(date +%s)" '
	function clean(s) { gsub(/[^A-Za-z0-9 ._:\/()+,&-]/, "", s); return s }
	BEGIN {
		srv = clean(n); if (loc != "") srv = srv " - " clean(loc)
		printf "%d|%s|%s|%.1f|%.1f|%.1f|%s|%s\n", ts, srv, clean(i), p + 0, d * 8 / 1e6, u * 8 / 1e6, (l == "" ? "-" : sprintf("%.1f", l + 0)), clean(url)
	}')

mkdir -p "$(dirname "$DB")"
echo "$LINE" >> "$DB"
N=$(wc -l < "$DB" | tr -d ' ')
if [ "$N" -gt 300 ]; then
	tail -n 300 "$DB" > "$DB.tmp" && mv "$DB.tmp" "$DB"
fi
exit 0
STEOF
chmod +x /usr/bin/netusage-speedtest
ok "Speed test runner installed"

log "Installing rpcd backend script..."
mkdir -p /usr/libexec/rpcd
cat > /usr/libexec/rpcd/netusage <<'RPCEOF'
#!/bin/sh

get_iface() {
	I=$(uci -q get netusage.main.iface)
	case "$I" in ''|*[!A-Za-z0-9_.-]*) I="eth1" ;; esac
	echo "$I"
}
get_num() {
	V=$(uci -q get "netusage.main.$1")
	case "$V" in ''|*[!0-9]*) V="$2" ;; esac
	echo "$V"
}

case "$1" in
	list)
		echo '{ "data": {}, "live": {}, "config": {}, "devices": {}, "speedtests": {}, "speedtest_run": {}, "speedtest_clear": {}, "devctl": {}, "devlive": {}, "devctl_set": { "mac": "str", "action": "str", "minutes": 0, "name": "str" }, "devlimit_set": { "mac": "str", "daily_mb": 0, "monthly_mb": 0, "action": "str" }, "setconfig": { "iface": "str", "cap_gb": 0, "cycle_day": 0, "st_hours": 0 } }'
		;;
	call)
		case "$2" in
			data)
				OUT=$(vnstat -i "$(get_iface)" --json 2>/dev/null)
				if [ -n "$OUT" ]; then echo "$OUT"; else echo '{"error":"no data"}'; fi
				;;
			live)
				IFACE=$(get_iface)
				LINE=$(grep -E "^ *${IFACE}:" /proc/net/dev 2>/dev/null | sed 's/.*://')
				echo "$LINE" | awk -v ts="$(date +%s)" '{ printf "{\"rx\":%.0f,\"tx\":%.0f,\"ts\":%d}\n", $1+0, $9+0, ts }'
				;;
			config)
				printf '{"iface":"%s","cap_gb":%s,"cycle_day":%s,"st_hours":%s}\n' \
					"$(get_iface)" "$(get_num cap_gb 0)" "$(get_num cycle_day 1)" "$(get_num st_hours 0)"
				;;
			devices)
				CUT=$(date -d "@$(( $(date +%s) - 2678400 ))" +%Y-%m-%d 2>/dev/null || echo 0000-00-00)
				LEASES="${NU_LEASES:-/tmp/dhcp.leases}"
				[ -f "$LEASES" ] || LEASES=/dev/null
				NAMES=$(awk 'NF >= 4 { n = $4; gsub(/[^A-Za-z0-9._-]/, "", n); sep = (c++ ? "," : ""); printf "%s\"%s\":\"%s\"", sep, tolower($2), n }' "$LEASES")
				PF="${NU_PEND:-/tmp/netusage-pending}"; [ -f "$PF" ] || PF=/dev/null
				DBF="${NU_DB:-/etc/netusage/devices.db}"; [ -f "$DBF" ] || DBF=/dev/null
				BODY=$(awk -v cut="$CUT" -v pend="$PF" '
					function add(day, mac, rx, tx,   k) { k = day " " mac; dr[k] += rx; dt[k] += tx }
					FILENAME == pend { if (FNR == 1) pday = $1; else if (NF == 3) add(pday, $1, $2, $3); next }
					NF >= 4 { add($1, $2, $3, $4) }
					END {
						for (k in dr) {
							split(k, p, " "); mk = substr(p[1], 1, 7) " " p[2]
							mr[mk] += dr[k]; mt[mk] += dt[k]
							if (p[1] >= cut) { s = (nd++ ? "," : ""); d = d s sprintf("[\"%s\",\"%s\",%.0f,%.0f]", p[1], p[2], dr[k], dt[k]) }
						}
						for (k in mr) {
							split(k, p, " "); s = (nm++ ? "," : ""); m = m s sprintf("[\"%s\",\"%s\",%.0f,%.0f]", p[1], p[2], mr[k], mt[k])
						}
						printf "\"daily\":[%s],\"monthly\":[%s]", d, m
					}' "$PF" "$DBF")
				printf '{"names":{%s},%s}\n' "$NAMES" "$BODY"
				;;
			devctl)
				CTLF="${NU_CTL:-/etc/netusage/devctl.db}"; [ -f "$CTLF" ] || CTLF=/dev/null
				LIMF="${NU_LIM:-/etc/netusage/limits.db}"; [ -f "$LIMF" ] || LIMF=/dev/null
				LEA="${NU_LEASES:-/tmp/dhcp.leases}"; [ -f "$LEA" ] || LEA=/dev/null
				NFTOK=false; command -v "${NU_NFT:-nft}" >/dev/null 2>&1 && NFTOK=true
				OFF=false; [ "$(uci -q get "firewall.@defaults[0].flow_offloading" 2>/dev/null)" = "1" ] && OFF=true
				NOW=$(date +%s)
				ENT=$(awk -F'|' -v now="$NOW" 'NF >= 5 && ($3 == 0 || $3 > now) { printf "%s[\"%s\",\"%s\",%d,\"%s\",\"%s\"]", (n++ ? "," : ""), $1, $2, $3, $4, $5 }' "$CTLF")
				LSE=$(awk 'NF >= 3 { n = $4; gsub(/[^A-Za-z0-9._-]/, "", n); printf "%s[\"%s\",\"%s\",\"%s\"]", (c++ ? "," : ""), tolower($2), $3, n }' "$LEA")
				LMT=$(awk -F'|' 'NF >= 5 { printf "%s[\"%s\",%d,%d,\"%s\",%d]", (n++ ? "," : ""), $1, $2, $3, $4, $5 }' "$LIMF")
				printf '{"nft":%s,"offload":%s,"now":%s,"today":"%s","month":"%s","entries":[%s],"leases":[%s],"limits":[%s]}\n' \
					"$NFTOK" "$OFF" "$NOW" "$(date +%Y-%m-%d)" "$(date +%Y-%m)" "$ENT" "$LSE" "$LMT"
				;;
			devlive)
				JSON=$(nlbw -c json -g mac 2>/dev/null)
				if [ -z "$JSON" ]; then echo '{"ts":0,"devs":{}}'; exit 0; fi
				COLS=$(jsonfilter -s "$JSON" -e '@.columns[*]' | tr '\n' ' ')
				BODY=$(jsonfilter -s "$JSON" -e '@.data[*]' | awk -v cols="$COLS" '
					BEGIN { n = split(cols, c, " "); for (i = 1; i <= n; i++) {
						if (c[i] == "mac") im = i; if (c[i] == "rx_bytes") ir = i; if (c[i] == "tx_bytes") it = i } }
					{ gsub(/\[|\]|"| /, ""); split($0, f, ",");
					  if (im && ir && it) printf "%s\"%s\":[%.0f,%.0f]", (k++ ? "," : ""), tolower(f[im]), f[ir], f[it] }')
				printf '{"ts":%s,"devs":{%s}}\n' "$(date +%s)" "$BODY"
				;;
			devctl_set)
				read -r INPUT
				DEVCTL="${NU_DEVCTL:-/usr/bin/netusage-devctl}"
				MAC=$(jsonfilter -s "$INPUT" -e '@.mac' | tr 'A-Z' 'a-z')
				ACT=$(jsonfilter -s "$INPUT" -e '@.action')
				MIN=$(jsonfilter -s "$INPUT" -e '@.minutes')
				NM=$(jsonfilter -s "$INPUT" -e '@.name' | tr -cd 'A-Za-z0-9._ -' | cut -c1-40)
				case "$MIN" in ''|*[!0-9]*) MIN=0 ;; esac
				case "$ACT" in
					block)   OUT=$("$DEVCTL" block "$MAC" "$NM" 2>&1) ;;
					pause)   OUT=$("$DEVCTL" pause "$MAC" "$MIN" "$NM" 2>&1) ;;
					unblock) OUT=$("$DEVCTL" unblock "$MAC" 2>&1) ;;
					clear)   OUT=$("$DEVCTL" clear 2>&1) ;;
					*) echo '{"error":"bad action"}'; exit 0 ;;
				esac
				RC=$?
				if [ "$RC" -eq 0 ]; then echo '{"ok":true}'; else printf '{"error":"%s"}\n' "$(echo "$OUT" | head -n 1 | tr -d '"\\' | cut -c1-120)"; fi
				;;
			devlimit_set)
				read -r INPUT
				DEVCTL="${NU_DEVCTL:-/usr/bin/netusage-devctl}"
				MAC=$(jsonfilter -s "$INPUT" -e '@.mac' | tr 'A-Z' 'a-z')
				DMB=$(jsonfilter -s "$INPUT" -e '@.daily_mb')
				MMB=$(jsonfilter -s "$INPUT" -e '@.monthly_mb')
				ACT=$(jsonfilter -s "$INPUT" -e '@.action')
				OUT=$("$DEVCTL" limit "$MAC" "$DMB" "$MMB" "$ACT" 2>&1)
				RC=$?
				if [ "$RC" -eq 0 ]; then echo '{"ok":true}'; else printf '{"error":"%s"}\n' "$(echo "$OUT" | head -n 1 | tr -d '"\\' | cut -c1-120)"; fi
				;;
			speedtests)
				SDB="${NU_STDB:-/etc/netusage/speedtests.db}"; [ -f "$SDB" ] || SDB=/dev/null
				SLOCK="${NU_STLOCK:-/tmp/netusage-speedtest.lock}"
				SERR="${NU_STERR:-/tmp/netusage-speedtest.err}"
				RUN=false
				if [ -f "$SLOCK" ] && kill -0 "$(cat "$SLOCK" 2>/dev/null)" 2>/dev/null; then RUN=true; fi
				INST=false
				if command -v ookla-speedtest >/dev/null 2>&1 || command -v speedtest >/dev/null 2>&1; then INST=true; fi
				ERR=""
				[ -s "$SERR" ] && ERR=$(head -n 1 "$SERR" | tr -d '"\\' | cut -c1-200)
				ROWS=$(awk -F'|' 'NF >= 8 { s = (n++ ? "," : ""); l = ($7 == "-" ? -1 : $7 + 0); printf "%s[%d,\"%s\",\"%s\",%.1f,%.1f,%.1f,%.1f,\"%s\"]", s, $1, $2, $3, $4, $5, $6, l, $8 }' "$SDB")
				printf '{"running":%s,"installed":%s,"error":"%s","rows":[%s]}\n' "$RUN" "$INST" "$ERR" "$ROWS"
				;;
			speedtest_run)
				if ! command -v ookla-speedtest >/dev/null 2>&1 && ! command -v speedtest >/dev/null 2>&1; then
					echo '{"error":"speedtest CLI not installed"}'; exit 0
				fi
				SLOCK="${NU_STLOCK:-/tmp/netusage-speedtest.lock}"
				if [ -f "$SLOCK" ] && kill -0 "$(cat "$SLOCK" 2>/dev/null)" 2>/dev/null; then
					echo '{"error":"already running"}'; exit 0
				fi
				/usr/bin/netusage-speedtest </dev/null >/dev/null 2>&1 &
				echo '{"started":true}'
				;;
			speedtest_clear)
				rm -f "${NU_STDB:-/etc/netusage/speedtests.db}"
				echo '{"ok":true}'
				;;
			setconfig)
				read -r INPUT
				IF=$(jsonfilter -s "$INPUT" -e '@.iface')
				CAP=$(jsonfilter -s "$INPUT" -e '@.cap_gb')
				CD=$(jsonfilter -s "$INPUT" -e '@.cycle_day')
				ST=$(jsonfilter -s "$INPUT" -e '@.st_hours')
				case "$IF" in ''|*[!A-Za-z0-9_.-]*) echo '{"error":"invalid interface"}'; exit 0 ;; esac
				case "$CAP" in ''|*[!0-9]*) CAP=0 ;; esac
				case "$CD" in ''|*[!0-9]*) CD=1 ;; esac
				[ "$CD" -lt 1 ] && CD=1
				[ "$CD" -gt 28 ] && CD=28
				case "$ST" in ''|*[!0-9]*) ST=$(get_num st_hours 0) ;; esac
				[ "$ST" -gt 24 ] && ST=24
				OLD=$(get_iface)
				uci -q set netusage.main.iface="$IF"
				uci -q set netusage.main.cap_gb="$CAP"
				uci -q set netusage.main.cycle_day="$CD"
				uci -q set netusage.main.st_hours="$ST"
				uci -q commit netusage
				touch /etc/crontabs/root
				sed -i '/netusage-speedtest/d' /etc/crontabs/root
				[ "$ST" -gt 0 ] && echo "7 */$ST * * * /usr/bin/netusage-speedtest" >> /etc/crontabs/root
				/etc/init.d/cron restart >/dev/null 2>&1
				if [ "$IF" != "$OLD" ]; then
					vnstat --add -i "$IF" >/dev/null 2>&1 || vnstat --create -i "$IF" >/dev/null 2>&1
					/etc/init.d/vnstat restart >/dev/null 2>&1 &
				fi
				echo '{"ok":true}'
				;;
			*)
				echo '{}'
				;;
		esac
		;;
esac
RPCEOF
chmod +x /usr/libexec/rpcd/netusage
ok "rpcd backend script installed"

log "Writing rpcd ACL rules..."
mkdir -p /usr/share/rpcd/acl.d
cat > /usr/share/rpcd/acl.d/luci-app-netusage.json <<'ACLEOF'
{
	"luci-app-netusage": {
		"description": "Access to Network Data Usage stats",
		"read": {
			"ubus": {
				"netusage": [ "data", "live", "config", "devices", "speedtests", "devctl", "devlive" ]
			}
		},
		"write": {
			"ubus": {
				"netusage": [ "setconfig", "speedtest_run", "speedtest_clear", "devctl_set", "devlimit_set" ]
			}
		}
	}
}
ACLEOF
ok "ACL rules configured"

log "Registering LuCI menu entry..."
mkdir -p /usr/share/luci/menu.d
cat > /usr/share/luci/menu.d/luci-app-netusage.json <<'MENUEOF'
{
	"admin/status/netusage": {
		"title": "Data Usage",
		"order": 35,
		"action": {
			"type": "view",
			"path": "netusage"
		},
		"depends": {
			"acl": [ "luci-app-netusage" ]
		}
	}
}
MENUEOF
ok "Menu entry registered under Status"

log "Installing dashboard view..."
mkdir -p /www/luci-static/resources/view
cat > /www/luci-static/resources/view/netusage.js <<'JSEOF'
'use strict';
'require view';
'require rpc';
'require poll';

var callData = rpc.declare({ object: 'netusage', method: 'data', expect: { } });
var callLive = rpc.declare({ object: 'netusage', method: 'live', expect: { } });
var callConfig = rpc.declare({ object: 'netusage', method: 'config', expect: { } });
var callDevices = rpc.declare({ object: 'netusage', method: 'devices', expect: { } });
var callSpeed = rpc.declare({ object: 'netusage', method: 'speedtests', expect: { } });
var callSpeedRun = rpc.declare({ object: 'netusage', method: 'speedtest_run', expect: { } });
var callSpeedClear = rpc.declare({ object: 'netusage', method: 'speedtest_clear', expect: { } });
var callDevCtl = rpc.declare({ object: 'netusage', method: 'devctl', expect: { } });
var callDevLive = rpc.declare({ object: 'netusage', method: 'devlive', expect: { } });
var callDevSet = rpc.declare({
	object: 'netusage', method: 'devctl_set',
	params: [ 'mac', 'action', 'minutes', 'name' ], expect: { }
});
var callDevLimit = rpc.declare({
	object: 'netusage', method: 'devlimit_set',
	params: [ 'mac', 'daily_mb', 'monthly_mb', 'action' ], expect: { }
});
var callSetConfig = rpc.declare({
	object: 'netusage', method: 'setconfig',
	params: [ 'iface', 'cap_gb', 'cycle_day', 'st_hours' ], expect: { }
});

var GB = 1073741824;
var state = {
	data: null,
	cfg: { iface: '', cap_gb: 0, cycle_day: 1, st_hours: 0 },
	st: { running: false, installed: true, error: '', rows: [], waitUntil: 0 },
	ctl: { nft: true, offload: false, now: 0, fetchedAt: 0, today: '', month: '', entries: [], leases: [], limits: [] },
	live: { hist: [], rates: {} },
	pauseMin: 30,
	dev: { names: {}, daily: [], monthly: [] },
	last: null, tick: 0,
	tab: 'daily', devMode: 'daily', devPick: { daily: '', monthly: '' }
};

/* vnstat 2.x JSON is in bytes, 1.x in KiB */
function B(v) {
	var ver = state.data && Number(state.data.jsonversion);
	return (ver >= 2) ? Number(v) || 0 : (Number(v) || 0) * 1024;
}

function fmt(b) {
	var u = [ 'B', 'KB', 'MB', 'GB', 'TB' ], i = 0;
	b = Number(b) || 0;
	while (b >= 1024 && i < 4) { b /= 1024; i++; }
	return b.toFixed(i ? 2 : 0) + ' ' + u[i];
}

function rate(bytesPerSec) {
	var bits = bytesPerSec * 8;
	if (bits >= 1e6) return (bits / 1e6).toFixed(2) + ' Mbps';
	if (bits >= 1e3) return (bits / 1e3).toFixed(1) + ' Kbps';
	return bits.toFixed(0) + ' bps';
}

function pad(n) { return (n < 10 ? '0' : '') + n; }
function setText(id, t) { var e = document.getElementById(id); if (e) e.textContent = t; }
function list(iface, a, b) { return (iface && iface.traffic && (iface.traffic[a] || iface.traffic[b])) || []; }
function dayKey(d) { return d.date.year * 10000 + d.date.month * 100 + d.date.day; }
function dayLabel(d) { return d.date.year + '-' + pad(d.date.month) + '-' + pad(d.date.day); }

function miniBar(pct) {
	return E('div', { 'class': 'nu-mini' },
		E('div', { 'class': 'nu-mini-fill', 'style': 'width:' + Math.max(0, Math.min(100, pct)).toFixed(1) + '%' }));
}

function cycleInfo(cd) {
	var n = new Date(), y = n.getFullYear(), m = n.getMonth() + 1;
	if (n.getDate() < cd) { m--; if (m < 1) { m = 12; y--; } }
	var start = new Date(y, m - 1, cd);
	var next = new Date(y, m, cd);
	return {
		key: y * 10000 + m * 100 + cd,
		elapsed: Math.floor((n - start) / 864e5) + 1,
		length: Math.round((next - start) / 864e5)
	};
}

/* ---------- painting ---------- */

function paintChart(days) {
	var box = document.getElementById('nu-chart');
	if (!box) return;
	box.innerHTML = '';
	var rows = days.slice(-30), max = 1;
	if (!rows.length) {
		box.appendChild(E('div', { 'class': 'nu-muted' }, _('No daily data yet.')));
		return;
	}
	rows.forEach(function (r) { max = Math.max(max, B(r.rx) + B(r.tx)); });
	rows.forEach(function (r) {
		var rx = B(r.rx), tx = B(r.tx);
		box.appendChild(E('div', { 'class': 'nu-col', 'title': dayLabel(r) + '  Down ' + fmt(rx) + '  Up ' + fmt(tx) }, [
			E('div', { 'class': 'nu-bar' }, [
				E('div', { 'class': 'nu-seg-tx', 'style': 'height:' + (tx / max * 100) + '%' }),
				E('div', { 'class': 'nu-seg-rx', 'style': 'height:' + (rx / max * 100) + '%' })
			]),
			E('div', { 'class': 'nu-day' }, String(r.date.day))
		]));
	});
}

function paintDaily(days) {
	var tbody = document.getElementById('nu-dtbody');
	if (!tbody) return;
	tbody.innerHTML = '';
	var rows = days.slice(-30).reverse(), max = 1;
	if (!rows.length) {
		tbody.appendChild(E('tr', {}, E('td', { 'colspan': 5 }, _('No daily data yet.'))));
		return;
	}
	rows.forEach(function (r) { max = Math.max(max, B(r.rx) + B(r.tx)); });
	rows.forEach(function (r) {
		var t = B(r.rx) + B(r.tx);
		tbody.appendChild(E('tr', {}, [
			E('td', {}, dayLabel(r)), E('td', {}, fmt(B(r.rx))), E('td', {}, fmt(B(r.tx))),
			E('td', {}, fmt(t)), E('td', {}, miniBar(t / max * 100))
		]));
	});
}

function paintMonthly(months) {
	var tbody = document.getElementById('nu-mtbody');
	if (!tbody) return;
	tbody.innerHTML = '';
	var rows = months.slice(-12).reverse(), max = 1;
	if (!rows.length) {
		tbody.appendChild(E('tr', {}, E('td', { 'colspan': 5 }, _('No monthly data yet.'))));
		return;
	}
	rows.forEach(function (m) { max = Math.max(max, B(m.rx) + B(m.tx)); });
	rows.forEach(function (m) {
		var t = B(m.rx) + B(m.tx);
		tbody.appendChild(E('tr', {}, [
			E('td', {}, m.date.year + '-' + pad(m.date.month)),
			E('td', {}, fmt(B(m.rx))), E('td', {}, fmt(B(m.tx))),
			E('td', {}, fmt(t)), E('td', {}, miniBar(t / max * 100))
		]));
	});
}

function paintDevices() {
	var body = document.getElementById('nu-devbody');
	var sel = document.getElementById('nu-devsel');
	if (!body || !sel) return;

	var mode = state.devMode;
	var rows = state.dev[mode] || [];
	var seen = {};
	rows.forEach(function (r) { seen[r[0]] = true; });
	var keys = Object.keys(seen).sort().reverse();

	var pick = state.devPick[mode];
	if (keys.indexOf(pick) < 0) pick = keys[0] || '';
	state.devPick[mode] = pick;

	var sig = mode + '|' + keys.join(',');
	if (sel.getAttribute('data-sig') !== sig) {
		sel.innerHTML = '';
		keys.forEach(function (k) { sel.appendChild(E('option', { 'value': k }, k)); });
		sel.setAttribute('data-sig', sig);
	}
	sel.value = pick;

	var mine = rows.filter(function (r) { return r[0] === pick; });
	mine.sort(function (a, b) { return (b[2] + b[3]) - (a[2] + a[3]); });
	var sum = 0, srx = 0, stx = 0;
	mine.forEach(function (r) { sum += r[2] + r[3]; srx += r[2]; stx += r[3]; });

	body.innerHTML = '';
	setText('nu-devmsg', mine.length ? '' :
		_('No per-device data yet. It shows up within about an hour of the first collector run (needs nlbwmon).'));

	mine.forEach(function (r) {
		var nm = state.dev.names[r[1]] || '';
		body.appendChild(E('tr', {}, [
			E('td', {}, [ E('div', {}, nm || r[1]), nm ? E('div', { 'class': 'nu-muted' }, r[1]) : '' ]),
			E('td', {}, fmt(r[2])), E('td', {}, fmt(r[3])), E('td', {}, fmt(r[2] + r[3])),
			E('td', {}, miniBar(sum ? (r[2] + r[3]) / sum * 100 : 0))
		]));
	});
	if (mine.length) {
		body.appendChild(E('tr', { 'style': 'font-weight:600' }, [
			E('td', {}, _('All devices')), E('td', {}, fmt(srx)), E('td', {}, fmt(stx)), E('td', {}, fmt(sum)), E('td', {})
		]));
	}

	var bd = document.getElementById('nu-m-daily'), bm = document.getElementById('nu-m-monthly');
	if (bd) bd.className = 'cbi-button' + (mode === 'daily' ? ' cbi-button-action' : '');
	if (bm) bm.className = 'cbi-button' + (mode === 'monthly' ? ' cbi-button-action' : '');
}

function paintCap(days) {
	var cap = Number(state.cfg.cap_gb) || 0;
	var ci = cycleInfo(Number(state.cfg.cycle_day) || 1);
	var used = 0;
	days.forEach(function (d) { if (dayKey(d) >= ci.key) used += B(d.rx) + B(d.tx); });
	var bar = document.getElementById('nu-capbar');

	if (cap <= 0) {
		setText('nu-capmain', fmt(used));
		setText('nu-capsub', _('This cycle (no cap set)'));
		if (bar) bar.style.width = '0%';
		return;
	}
	var pct = used / (cap * GB) * 100;
	var proj = used / Math.max(ci.elapsed, 1) * ci.length;
	setText('nu-capmain', fmt(used) + ' / ' + cap + ' GB (' + pct.toFixed(1) + '%)');
	setText('nu-capsub', _('Projected by cycle end: ') + fmt(proj));
	if (bar) {
		bar.style.width = Math.min(pct, 100) + '%';
		bar.className = 'nu-capbar-fill' + (pct >= 95 ? ' bad' : (pct >= 80 ? ' warn' : ''));
	}
}

function stRunning() { return state.st.running || Date.now() < state.st.waitUntil; }

function stDate(ts) {
	var d = new Date(ts * 1000);
	return d.getFullYear() + '-' + pad(d.getMonth() + 1) + '-' + pad(d.getDate()) + ' ' +
		pad(d.getHours()) + ':' + pad(d.getMinutes()) + ':' + pad(d.getSeconds());
}

function paintSpeed() {
	var body = document.getElementById('nu-stbody');
	var chart = document.getElementById('nu-st-chart');
	if (!body || !chart) return;
	var st = state.st, rows = st.rows || [], running = stRunning();
	var pd = 0, pu = 0, sp = 0;
	rows.forEach(function (r) { pd = Math.max(pd, r[4]); pu = Math.max(pu, r[5]); sp += r[3]; });
	setText('nu-st-pd', rows.length ? pd.toFixed(1) : '--');
	setText('nu-st-pu', rows.length ? pu.toFixed(1) : '--');
	setText('nu-st-ping', rows.length ? (sp / rows.length).toFixed(1) : '--');
	setText('nu-st-n', String(rows.length));

	var btn = document.getElementById('nu-st-run');
	if (btn) {
		btn.disabled = running || !st.installed;
		btn.textContent = running ? _('Running... (about 1 min)') : _('Run test now');
	}
	var msg = '';
	if (running) msg = _('Test in progress, your connection is busy until it finishes.');
	else if (!st.installed) msg = _('Ookla speedtest CLI is not installed on this router. Run the installer again.');
	else if (st.error) msg = _('Last test failed: ') + st.error;
	setText('nu-st-msg', msg);

	chart.innerHTML = '';
	var recent = rows.slice(-20), max = 1;
	if (!recent.length) chart.appendChild(E('div', { 'class': 'nu-muted' }, _('No speed tests yet.')));
	recent.forEach(function (r) { max = Math.max(max, r[4], r[5]); });
	recent.forEach(function (r) {
		chart.appendChild(E('div', { 'class': 'nu-col', 'title': stDate(r[0]) + '  Down ' + r[4].toFixed(1) + '  Up ' + r[5].toFixed(1) + ' Mbps' }, [
			E('div', { 'class': 'nu-sgrp' }, [
				E('div', { 'class': 'nu-sd', 'style': 'height:' + (r[4] / max * 100) + '%' }),
				E('div', { 'class': 'nu-su', 'style': 'height:' + (r[5] / max * 100) + '%' })
			])
		]));
	});

	body.innerHTML = '';
	if (!rows.length) {
		body.appendChild(E('tr', {}, E('td', { 'colspan': 9 }, _('No speed tests yet. Press "Run test now".'))));
		return;
	}
	rows.slice().reverse().slice(0, 50).forEach(function (r, i) {
		body.appendChild(E('tr', {}, [
			E('td', {}, String(i + 1)),
			E('td', {}, stDate(r[0])),
			E('td', {}, r[1]),
			E('td', {}, r[2]),
			E('td', { 'class': 'nu-pg' }, r[3].toFixed(1) + ' ms'),
			E('td', { 'class': 'nu-dl' }, r[4].toFixed(1) + ' Mbps'),
			E('td', { 'class': 'nu-ul' }, r[5].toFixed(1) + ' Mbps'),
			E('td', {}, r[6] < 0 ? 'n/a' : r[6].toFixed(1) + '%'),
			E('td', {}, /^https:\/\//.test(r[7]) ?
				E('a', { 'href': r[7], 'target': '_blank', 'rel': 'noopener noreferrer', 'class': 'cbi-button' }, 'Ookla') : '-')
		]));
	});
}

function paint() {
	paintCtl();
	paintSpeed();
	paintDevices();
	var iface = state.data && state.data.interfaces && state.data.interfaces[0];
	if (!iface) {
		setText('nu-status', _('No data yet - vnstat needs a few minutes to collect traffic.'));
		return;
	}
	setText('nu-status', '');
	var t = iface.traffic.total;
	setText('nu-rx', fmt(B(t.rx)));
	setText('nu-tx', fmt(B(t.tx)));
	setText('nu-total', fmt(B(t.rx) + B(t.tx)));
	var days = list(iface, 'day', 'days');
	paintCap(days);
	paintChart(days);
	paintDaily(days);
	paintMonthly(list(iface, 'month', 'months'));
	setText('nu-time', new Date().toLocaleTimeString());
}

function fillForm() {
	var a = document.getElementById('nu-in-iface');
	var b = document.getElementById('nu-in-cap');
	var c = document.getElementById('nu-in-cd');
	if (a) a.value = state.cfg.iface;
	if (b) b.value = state.cfg.cap_gb;
	if (c) c.value = state.cfg.cycle_day;
	var sh = document.getElementById('nu-in-sh');
	if (sh) sh.value = state.cfg.st_hours || 0;
}

/* ---------- data flow ---------- */

function applyDevices(d) {
	if (d && d.names) state.dev = { names: d.names, daily: d.daily || [], monthly: d.monthly || [] };
}

function applySpeed(s) {
	if (!s || !s.rows) return;
	var w = state.st.waitUntil;
	state.st = { running: !!s.running, installed: s.installed !== false, error: s.error || '', rows: s.rows, waitUntil: w };
	if (state.st.running) state.st.waitUntil = 0;
}

function runSpeedTest() {
	if (stRunning()) return;
	state.st.error = '';
	state.st.waitUntil = Date.now() + 8000;
	paintSpeed();
	return callSpeedRun().then(function (r) {
		if (r && r.error) { state.st.waitUntil = 0; state.st.error = r.error; paintSpeed(); }
	});
}

function clearSpeed() {
	if (!confirm(_('Delete all speed test history?'))) return;
	return callSpeedClear().then(function () { state.st.rows = []; paintSpeed(); });
}

function exportSpeedCsv() {
	var lines = [ 'date_time,server,isp,ping_ms,download_mbps,upload_mbps,loss_pct,result_url' ];
	state.st.rows.slice().reverse().forEach(function (r) {
		lines.push([ stDate(r[0]), r[1], r[2], r[3], r[4], r[5], r[6] < 0 ? '' : r[6], r[7] ].map(function (v) {
			return '"' + String(v).replace(/"/g, '""') + '"';
		}).join(','));
	});
	var a = E('a', { 'href': URL.createObjectURL(new Blob([ lines.join('\n') ], { type: 'text/csv' })), 'download': 'speedtests.csv' });
	document.body.appendChild(a);
	a.click();
	document.body.removeChild(a);
}

/* ---------- device control ---------- */

function macId(mac) { return 'nu-c-' + mac.replace(/:/g, ''); }

function ctlNow() { return state.ctl.now + (Date.now() - state.ctl.fetchedAt) / 1000; }

function timeLeft(sec) {
	sec = Math.max(0, Math.round(sec));
	if (sec >= 3600) return Math.floor(sec / 3600) + 'h ' + pad(Math.floor(sec % 3600 / 60)) + 'm';
	if (sec >= 60) return Math.floor(sec / 60) + 'm ' + pad(sec % 60) + 's';
	return sec + 's';
}

function ctlEntry(mac) {
	var now = ctlNow(), hit = null;
	state.ctl.entries.forEach(function (e) {
		if (e[0] === mac && (e[2] === 0 || e[2] > now)) hit = { mode: e[1], exp: e[2], src: e[4] };
	});
	return hit;
}

function ctlLimit(mac) {
	var hit = { daily: 0, monthly: 0, action: 'warn' };
	state.ctl.limits.forEach(function (l) { if (l[0] === mac) hit = { daily: l[1], monthly: l[2], action: l[3] }; });
	return hit;
}

function ctlUsage(mac) {
	var td = 0, mo = 0;
	(state.dev.daily || []).forEach(function (r) { if (r[0] === state.ctl.today && r[1] === mac) td += r[2] + r[3]; });
	(state.dev.monthly || []).forEach(function (r) { if (r[0] === state.ctl.month && r[1] === mac) mo += r[2] + r[3]; });
	return { today: td, month: mo };
}

function ctlDevices() {
	var map = {};
	function touch(mac) {
		mac = String(mac).toLowerCase();
		if (!map[mac]) map[mac] = { mac: mac, name: '', ip: '' };
		return map[mac];
	}
	state.ctl.leases.forEach(function (l) { var d = touch(l[0]); d.ip = l[1]; if (l[2]) d.name = l[2]; });
	state.ctl.entries.forEach(function (e) { var d = touch(e[0]); if (!d.name && e[3]) d.name = e[3]; });
	state.ctl.limits.forEach(function (l) { touch(l[0]); });
	(state.dev.daily || []).forEach(function (r) { if (r[0] === state.ctl.today) touch(r[1]); });
	(state.dev.monthly || []).forEach(function (r) { if (r[0] === state.ctl.month) touch(r[1]); });
	return Object.keys(map).map(function (m) {
		if (!map[m].name) map[m].name = (state.dev.names && state.dev.names[m]) || '';
		return map[m];
	}).sort(function (a, b) { return (a.name || a.mac).localeCompare(b.name || b.mac); });
}

function ctlBadge(mac) {
	var e = ctlEntry(mac), u = ctlUsage(mac), l = ctlLimit(mac);
	if (e && e.mode === 'block') return [ 'blk', _('Blocked') ];
	if (e) {
		var left = e.exp ? ' - ' + timeLeft(e.exp - ctlNow()) : '';
		return [ 'pau', (e.src === 'limit' ? _('Limit reached') : _('Paused')) + left ];
	}
	if (l.daily > 0 && u.today >= l.daily * 1048576) return [ 'lim', _('Over daily limit') ];
	if (l.monthly > 0 && u.month >= l.monthly * 1048576) return [ 'lim', _('Over monthly limit') ];
	return [ 'ok', _('Allowed') ];
}

function ctlSet(mac, action, minutes, name) {
	if (action !== 'unblock' &&
		!confirm(_('Apply ') + action + _(' to ') + mac + '?\n' + _('If this is the device you are using right now, you will lose your connection.')))
		return;
	setText('nu-ctl-msg', _('Applying...'));
	return callDevSet(mac, action, minutes || 0, name || '').then(function (r) {
		if (r && r.error) { setText('nu-ctl-msg', r.error); return; }
		return refreshCtl().then(function () { setText('nu-ctl-msg', _('Done')); });
	});
}

function ctlAdd(action) {
	var mac = document.getElementById('nu-ctl-mac').value.trim().toLowerCase();
	var nm = document.getElementById('nu-ctl-name').value.trim();
	if (!/^([0-9a-f]{2}:){5}[0-9a-f]{2}$/.test(mac)) {
		setText('nu-ctl-msg', _('Enter a valid MAC address like aa:bb:cc:dd:ee:ff'));
		return;
	}
	return ctlSet(mac, action, state.pauseMin, nm);
}

function ctlClear() {
	if (!confirm(_('Remove all blocks and pauses?'))) return;
	return callDevSet('', 'clear', 0, '').then(function (r) {
		if (r && r.error) { setText('nu-ctl-msg', r.error); return; }
		return refreshCtl().then(function () { setText('nu-ctl-msg', _('All devices unblocked')); });
	});
}

function saveLimit(mac) {
	var id = macId(mac);
	var dg = Math.max(0, parseFloat(document.getElementById(id + '-ld').value) || 0);
	var mg = Math.max(0, parseFloat(document.getElementById(id + '-lm').value) || 0);
	var act = document.getElementById(id + '-la').value;
	setText('nu-ctl-msg', _('Saving...'));
	return callDevLimit(mac, Math.round(dg * 1024), Math.round(mg * 1024), act).then(function (r) {
		if (r && r.error) { setText('nu-ctl-msg', r.error); return; }
		return refreshCtl().then(function () { setText('nu-ctl-msg', _('Limit saved')); });
	});
}

function refreshCtl() {
	return Promise.all([ callDevCtl(), callDevices().catch(function () { return null; }) ]).then(function (r) {
		applyCtl(r[0]);
		applyDevices(r[1]);
		paintCtl();
	});
}

function applyCtl(c) {
	if (!c || !c.entries) return;
	state.ctl = {
		nft: c.nft !== false, offload: !!c.offload, now: Number(c.now) || 0, fetchedAt: Date.now(),
		today: c.today || '', month: c.month || '',
		entries: c.entries || [], leases: c.leases || [], limits: c.limits || []
	};
}

function feedLive(l) {
	if (!l || !l.ts || !l.devs) return;
	var h = state.live.hist;
	h.push(l);
	while (h.length > 2 && l.ts - h[0].ts > 12) h.shift();
	var o = h[0], dt = l.ts - o.ts, rates = {};
	if (h.length > 1 && dt > 0) {
		Object.keys(l.devs).forEach(function (m) {
			var p = o.devs[m];
			if (!p) return;
			rates[m] = [ Math.max(0, (l.devs[m][0] - p[0]) / dt), Math.max(0, (l.devs[m][1] - p[1]) / dt) ];
		});
	}
	state.live.rates = rates;
}

function ctlCard(d) {
	var id = macId(d.mac), l = ctlLimit(d.mac);
	var title = d.name || d.mac;
	function btn(bid, cls, label, fn) {
		return E('button', { 'id': bid, 'class': 'cbi-button ' + cls, 'click': fn }, label);
	}
	var sel = E('select', { 'id': id + '-la', 'class': 'cbi-input-select' }, [
		E('option', { 'value': 'warn' }, _('Warn only')),
		E('option', { 'value': 'pause' }, _('Auto pause'))
	]);
	return E('div', { 'id': id, 'class': 'nu-dev' }, [
		E('div', { 'class': 'nu-dev-head' }, [
			E('b', {}, title),
			E('span', { 'id': id + '-b', 'class': 'nu-badge ok' }, '')
		]),
		E('div', { 'class': 'nu-muted' }, d.mac + (d.ip ? '  |  ' + d.ip : '')),
		E('div', { 'class': 'nu-dev-stats' }, [
			E('span', { 'class': 'nu-dl' }, [ _('Down') + ' ', E('span', { 'id': id + '-dn' }, '--') ]),
			E('span', { 'class': 'nu-ul' }, [ _('Up') + ' ', E('span', { 'id': id + '-up' }, '--') ])
		]),
		E('div', { 'class': 'nu-muted' }, [
			_('Today') + ' ', E('span', { 'id': id + '-td' }, '--'),
			'   ' + _('Month') + ' ', E('span', { 'id': id + '-mo' }, '--')
		]),
		E('div', { 'class': 'nu-dev-act' }, [
			btn(id + '-bb', 'nu-btn-block', _('Block'), function () { ctlSet(d.mac, 'block', 0, title); }),
			btn(id + '-bp', 'cbi-button-action', _('Pause'), function () { ctlSet(d.mac, 'pause', state.pauseMin, title); }),
			btn(id + '-bu', 'nu-btn-ok', _('Unblock'), function () { ctlSet(d.mac, 'unblock', 0, ''); })
		]),
		E('div', { 'class': 'nu-dev-lim' }, [
			E('label', {}, [ _('Daily limit (GB)'), E('input', { 'id': id + '-ld', 'type': 'number', 'min': 0, 'step': '0.1', 'class': 'cbi-input-text',
				'value': l.daily ? String(+(l.daily / 1024).toFixed(2)) : '' }) ]),
			E('label', {}, [ _('Monthly limit (GB)'), E('input', { 'id': id + '-lm', 'type': 'number', 'min': 0, 'step': '0.1', 'class': 'cbi-input-text',
				'value': l.monthly ? String(+(l.monthly / 1024).toFixed(2)) : '' }) ]),
			E('label', {}, [ _('When over limit'), sel ]),
			E('button', { 'class': 'cbi-button', 'click': function () { saveLimit(d.mac); } }, _('Save limit'))
		])
	]);
}

function paintCtl() {
	var grid = document.getElementById('nu-devgrid');
	if (!grid) return;
	var list = ctlDevices();
	var sig = list.map(function (d) {
		var e = ctlEntry(d.mac) || {}, l = ctlLimit(d.mac);
		return [ d.mac, d.name, d.ip, e.mode, e.exp, e.src, l.daily, l.monthly, l.action ].join('~');
	}).join('|');
	if (grid.getAttribute('data-sig') !== sig) {
		grid.innerHTML = '';
		list.forEach(function (d) {
			grid.appendChild(ctlCard(d));
			var s = document.getElementById(macId(d.mac) + '-la');
			if (s) s.value = ctlLimit(d.mac).action;
		});
		if (!list.length) grid.appendChild(E('div', { 'class': 'nu-muted' }, _('No devices seen yet.')));
		grid.setAttribute('data-sig', sig);
	}
	var rt = state.live.rates;
	list.forEach(function (d) {
		var id = macId(d.mac), r = rt[d.mac], u = ctlUsage(d.mac), b = ctlBadge(d.mac), e = ctlEntry(d.mac), l = ctlLimit(d.mac);
		setText(id + '-dn', r ? rate(r[0]) : '--');
		setText(id + '-up', r ? rate(r[1]) : '--');
		setText(id + '-td', fmt(u.today) + (l.daily ? ' / ' + (l.daily / 1024).toFixed(1) + ' GB' : ''));
		setText(id + '-mo', fmt(u.month) + (l.monthly ? ' / ' + (l.monthly / 1024).toFixed(1) + ' GB' : ''));
		var bd = document.getElementById(id + '-b');
		if (bd) { bd.className = 'nu-badge ' + b[0]; bd.textContent = b[1]; }
		var card = document.getElementById(id);
		if (card) card.className = 'nu-dev' + (e ? (e.mode === 'block' ? ' blocked' : ' paused') : '');
		var bb = document.getElementById(id + '-bb'), bu = document.getElementById(id + '-bu');
		if (bb) bb.disabled = !!(e && e.mode === 'block');
		if (bu) bu.disabled = !e;
	});
	var w = [];
	if (!state.ctl.nft) w.push(_('nft (firewall4) was not found, so blocking will not work.'));
	if (state.ctl.offload) w.push(_('Flow offloading is on: connections that are already open may keep working until they end. New connections are blocked.'));
	setText('nu-ctl-warn', w.join(' '));
}

function refreshAll() {
	return Promise.all([
		callData(), callConfig(),
		callDevices().catch(function () { return null; }),
		callSpeed().catch(function () { return null; }),
		callDevCtl().catch(function () { return null; })
	]).then(function (r) {
		state.data = r[0];
		state.cfg = r[1] || state.cfg;
		applyDevices(r[2]);
		applySpeed(r[3]);
		applyCtl(r[4]);
		paint();
	});
}

function liveTick() {
	return callLive().then(function (l) {
		if (state.last && l.ts > state.last.ts) {
			var dt = l.ts - state.last.ts;
			setText('nu-down', rate(Math.max(0, (l.rx - state.last.rx) / dt)));
			setText('nu-up', rate(Math.max(0, (l.tx - state.last.tx) / dt)));
		}
		state.last = l;
		state.tick++;
		if (state.tick % 5 === 0) return refreshAll();
		if (stRunning()) return callSpeed().then(function (s) { applySpeed(s); paintSpeed(); }).catch(function () {});
	});
}

function saveSettings() {
	var iface = document.getElementById('nu-in-iface').value.trim();
	var cap = parseInt(document.getElementById('nu-in-cap').value, 10) || 0;
	var cd = parseInt(document.getElementById('nu-in-cd').value, 10) || 1;
	setText('nu-saved', _('Saving...'));
	var sh = parseInt(document.getElementById('nu-in-sh').value, 10) || 0;
	return callSetConfig(iface, cap, cd, sh).then(function (res) {
		if (res && res.error) { setText('nu-saved', res.error); return; }
		state.last = null;
		return refreshAll().then(function () { fillForm(); setText('nu-saved', _('Saved')); });
	});
}

var THEMES = [
	[ 'ocean', _('Ocean Glass'), _('Blue and cyan, the default'), 'linear-gradient(135deg,#2563eb,#06b6d4)', '#07122e', '#3b82f6', '#6366f1' ],
	[ 'midnight', _('Midnight Neon'), _('Deep violet with cyan glow'), 'linear-gradient(135deg,#7c3aed,#22d3ee)', '#0b0820', '#22d3ee', '#a855f7' ],
	[ 'aurora', _('Aurora'), _('Green and teal northern lights'), 'linear-gradient(135deg,#059669,#06b6d4)', '#041a1a', '#34d399', '#22d3ee' ],
	[ 'sunset', _('Sunset'), _('Warm orange and amber'), 'linear-gradient(135deg,#ea580c,#be123c)', '#1f0a14', '#fb923c', '#f43f5e' ],
	[ 'frost', _('Frost Light'), _('Clean light glass'), 'linear-gradient(135deg,#bae6fd,#c7d2fe)', '#e8f1fb', '#38bdf8', '#818cf8' ]
];

function lsGet(k, d) { try { var v = window.localStorage.getItem(k); return v === null ? d : v; } catch (e) { return d; } }
function lsSet(k, v) { try { window.localStorage.setItem(k, v); } catch (e) {} }

function applyTheme(id, save) {
	var el = document.querySelector('.nu-wrap');
	var ok = THEMES.some(function (t) { return t[0] === id; });
	if (!ok) id = 'ocean';
	if (el) el.setAttribute('data-theme', id);
	THEMES.forEach(function (t) {
		var b = document.getElementById('nu-th-' + t[0]);
		if (b) b.className = 'nu-theme' + (t[0] === id ? ' sel' : '');
	});
	if (save) lsSet('nu_theme', id);
}

function applyFx(blur, anim, save) {
	var el = document.querySelector('.nu-wrap');
	if (el) { el.setAttribute('data-blur', blur ? 'on' : 'off'); el.setAttribute('data-anim', anim ? 'on' : 'off'); }
	if (save) { lsSet('nu_blur', blur ? '1' : '0'); lsSet('nu_anim', anim ? '1' : '0'); }
}

var TABS = [
	[ 'daily', _('Daily') ], [ 'monthly', _('Monthly') ],
	[ 'devices', _('Per device') ], [ 'ctl', _('Device control') ], [ 'speed', _('Speed tests') ], [ 'themes', _('Themes') ], [ 'settings', _('Settings') ]
];

function showTab(id) {
	state.tab = id;
	if (id === 'ctl') { state.live.hist = []; refreshCtl(); }
	TABS.forEach(function (t) {
		var p = document.getElementById('nu-p-' + t[0]);
		var b = document.getElementById('nu-t-' + t[0]);
		if (p) p.style.display = (t[0] === id) ? '' : 'none';
		if (b) b.className = 'nu-tab' + (t[0] === id ? ' active' : '');
	});
}

function setDevMode(mode) {
	state.devMode = mode;
	paintDevices();
}

/* ---------- view ---------- */

return view.extend({
	load: function () {
		return Promise.all([
			callData(), callConfig(),
			callDevices().catch(function () { return null; }),
		callSpeed().catch(function () { return null; }),
		callDevCtl().catch(function () { return null; })
		]);
	},

	render: function (res) {
		state.data = res[0];
		state.cfg = res[1] || state.cfg;
		applyDevices(res[2]);
		applySpeed(res[3]);
		applyCtl(res[4]);

		var style = E('style', {}, [
			'.nu-wrap{--fg:#e8f1ff;--fg2:#dbeafe;--th:#bfdbfe;--td:#f1f5f9;--card-fg:#fff;--bg:#07122e;--o1:#2563eb;--o2:#06b6d4;--o3:#4f46e5;--o4:#0ea5e9;--b1:#22d3ee;--b2:#6366f1;' +
				'--h2:linear-gradient(90deg,#fff,#bae6fd,#c7d2fe);--g1:rgba(255,255,255,.15);--g2:rgba(255,255,255,.04);--bd:rgba(255,255,255,.2);--hi:rgba(255,255,255,.3);--sh:rgba(2,8,30,.35);' +
				'--sheen:rgba(255,255,255,.26);--line:rgba(255,255,255,.14);--track:rgba(255,255,255,.16);--hov:rgba(255,255,255,.08);--inp:rgba(255,255,255,.12);--inpbd:rgba(255,255,255,.28);' +
				'--c-live:linear-gradient(135deg,rgba(13,148,136,.55),rgba(34,211,238,.2));--c-live2:linear-gradient(135deg,rgba(67,56,202,.6),rgba(96,165,250,.24));' +
				'--c-down:linear-gradient(135deg,rgba(14,165,233,.6),rgba(34,211,238,.2));--c-up:linear-gradient(135deg,rgba(79,70,229,.62),rgba(129,140,248,.24));' +
				'--c-total:linear-gradient(135deg,rgba(37,99,235,.66),rgba(56,189,248,.26));' +
				'--tab:linear-gradient(135deg,#3b82f6,#06b6d4);--tabsh:rgba(59,130,246,.5);--act:linear-gradient(135deg,#0ea5e9,#6366f1);--ok:rgba(20,184,166,.5);--okbd:rgba(94,234,212,.5);' +
				'--rx:linear-gradient(180deg,#7dd3fc,#0ea5e9);--tx:linear-gradient(180deg,#a5b4fc,#6366f1);--fill:linear-gradient(90deg,#22d3ee,#3b82f6);--mini:linear-gradient(90deg,#22d3ee,#6366f1);' +
				'--cdl:#7dd3fc;--cul:#a5b4fc;--cpg:#5eead4;--bdg:rgba(56,189,248,.28);--bdgfg:#e0f2fe;--blur:18px}',
			'.nu-wrap[data-theme="midnight"]{--fg:#ece9ff;--fg2:#ddd6fe;--th:#c4b5fd;--bg:#0b0820;--o1:#7c3aed;--o2:#22d3ee;--o3:#2563eb;--o4:#a855f7;--b1:#a855f7;--b2:#22d3ee;' +
				'--h2:linear-gradient(90deg,#fff,#c4b5fd,#67e8f9);--g1:rgba(255,255,255,.1);--g2:rgba(255,255,255,.03);--bd:rgba(167,139,250,.35);--sh:rgba(5,0,25,.5);' +
				'--c-live:linear-gradient(135deg,rgba(6,182,212,.5),rgba(34,211,238,.14));--c-live2:linear-gradient(135deg,rgba(124,58,237,.6),rgba(167,139,250,.2));' +
				'--c-down:linear-gradient(135deg,rgba(34,211,238,.45),rgba(124,58,237,.25));--c-up:linear-gradient(135deg,rgba(168,85,247,.6),rgba(99,102,241,.25));' +
				'--c-total:linear-gradient(135deg,rgba(79,70,229,.65),rgba(34,211,238,.25));--tab:linear-gradient(135deg,#7c3aed,#22d3ee);--tabsh:rgba(124,58,237,.55);' +
				'--act:linear-gradient(135deg,#7c3aed,#06b6d4);--rx:linear-gradient(180deg,#67e8f9,#06b6d4);--tx:linear-gradient(180deg,#c4b5fd,#7c3aed);' +
				'--fill:linear-gradient(90deg,#22d3ee,#a855f7);--mini:linear-gradient(90deg,#22d3ee,#a855f7);--cdl:#67e8f9;--cul:#c4b5fd;--bdg:rgba(167,139,250,.3);--bdgfg:#ede9fe}',
			'.nu-wrap[data-theme="aurora"]{--fg:#e6fff6;--fg2:#d1fae5;--th:#a7f3d0;--bg:#041a1a;--o1:#059669;--o2:#06b6d4;--o3:#0d9488;--o4:#10b981;--b1:#34d399;--b2:#22d3ee;' +
				'--h2:linear-gradient(90deg,#fff,#a7f3d0,#a5f3fc);--bd:rgba(110,231,183,.28);--sh:rgba(0,20,15,.45);' +
				'--c-live:linear-gradient(135deg,rgba(5,150,105,.6),rgba(52,211,153,.2));--c-live2:linear-gradient(135deg,rgba(8,145,178,.6),rgba(103,232,249,.2));' +
				'--c-down:linear-gradient(135deg,rgba(16,185,129,.6),rgba(34,211,238,.2));--c-up:linear-gradient(135deg,rgba(13,148,136,.62),rgba(94,234,212,.22));' +
				'--c-total:linear-gradient(135deg,rgba(2,132,199,.6),rgba(52,211,153,.25));--tab:linear-gradient(135deg,#10b981,#06b6d4);--tabsh:rgba(16,185,129,.5);' +
				'--act:linear-gradient(135deg,#10b981,#0891b2);--rx:linear-gradient(180deg,#6ee7b7,#10b981);--tx:linear-gradient(180deg,#67e8f9,#0891b2);' +
				'--fill:linear-gradient(90deg,#34d399,#22d3ee);--mini:linear-gradient(90deg,#34d399,#22d3ee);--cdl:#6ee7b7;--cul:#67e8f9;--cpg:#a7f3d0;--bdg:rgba(52,211,153,.28);--bdgfg:#d1fae5}',
			'.nu-wrap[data-theme="sunset"]{--fg:#fff4ea;--fg2:#ffedd5;--th:#fed7aa;--bg:#1f0a14;--o1:#ea580c;--o2:#f59e0b;--o3:#be123c;--o4:#fb7185;--b1:#fb923c;--b2:#f43f5e;' +
				'--h2:linear-gradient(90deg,#fff,#fed7aa,#fecdd3);--bd:rgba(253,186,116,.3);--sh:rgba(30,5,10,.5);' +
				'--c-live:linear-gradient(135deg,rgba(234,88,12,.58),rgba(251,191,36,.2));--c-live2:linear-gradient(135deg,rgba(190,18,60,.55),rgba(251,146,60,.22));' +
				'--c-down:linear-gradient(135deg,rgba(249,115,22,.6),rgba(251,191,36,.2));--c-up:linear-gradient(135deg,rgba(225,29,72,.55),rgba(251,113,133,.22));' +
				'--c-total:linear-gradient(135deg,rgba(217,70,39,.62),rgba(245,158,11,.25));--tab:linear-gradient(135deg,#f97316,#f43f5e);--tabsh:rgba(249,115,22,.5);' +
				'--act:linear-gradient(135deg,#f97316,#e11d48);--rx:linear-gradient(180deg,#fdba74,#f97316);--tx:linear-gradient(180deg,#fda4af,#e11d48);' +
				'--fill:linear-gradient(90deg,#fbbf24,#f97316);--mini:linear-gradient(90deg,#fbbf24,#f43f5e);--cdl:#fdba74;--cul:#fda4af;--cpg:#fde68a;--bdg:rgba(251,146,60,.3);--bdgfg:#ffedd5}',
			'.nu-wrap[data-theme="frost"]{--fg:#0f2744;--fg2:#1e3a5f;--th:#335c8a;--td:#12304f;--card-fg:#0b2545;--bg:#e8f1fb;--o1:#93c5fd;--o2:#a5f3fc;--o3:#c7d2fe;--o4:#bae6fd;--b1:#7dd3fc;--b2:#a5b4fc;' +
				'--h2:linear-gradient(90deg,#1e3a8a,#0369a1,#4338ca);--g1:rgba(255,255,255,.75);--g2:rgba(255,255,255,.35);--bd:rgba(255,255,255,.9);--hi:rgba(255,255,255,.9);--sh:rgba(30,64,120,.18);' +
				'--sheen:rgba(255,255,255,.6);--line:rgba(15,39,68,.12);--track:rgba(15,39,68,.12);--hov:rgba(59,130,246,.1);--inp:rgba(255,255,255,.8);--inpbd:rgba(15,39,68,.22);' +
				'--c-live:linear-gradient(135deg,rgba(45,212,191,.5),rgba(255,255,255,.55));--c-live2:linear-gradient(135deg,rgba(129,140,248,.5),rgba(255,255,255,.55));' +
				'--c-down:linear-gradient(135deg,rgba(56,189,248,.5),rgba(255,255,255,.55));--c-up:linear-gradient(135deg,rgba(129,140,248,.45),rgba(255,255,255,.55));' +
				'--c-total:linear-gradient(135deg,rgba(59,130,246,.45),rgba(255,255,255,.55));--tab:linear-gradient(135deg,#3b82f6,#0ea5e9);--tabsh:rgba(59,130,246,.35);' +
				'--rx:linear-gradient(180deg,#38bdf8,#0284c7);--tx:linear-gradient(180deg,#818cf8,#4f46e5);--fill:linear-gradient(90deg,#38bdf8,#3b82f6);--mini:linear-gradient(90deg,#38bdf8,#6366f1);' +
				'--cdl:#0369a1;--cul:#4338ca;--cpg:#0f766e;--bdg:rgba(14,165,233,.18);--bdgfg:#0c4a6e}',
			'.nu-wrap[data-theme="frost"] .nu-tab{color:#1e3a5f}.nu-wrap[data-theme="frost"] .nu-tab.active{color:#fff}',
			'.nu-wrap[data-theme="frost"] .cbi-button{color:#0f2744}.nu-wrap[data-theme="frost"] .cbi-button-action,.nu-wrap[data-theme="frost"] .cbi-button-save,.nu-wrap[data-theme="frost"] .nu-btn-block,.nu-wrap[data-theme="frost"] .cbi-button-remove{color:#fff}',
			'.nu-wrap[data-theme="frost"] .nu-btn-ok{color:#064e3b}.nu-wrap[data-theme="frost"] .nu-panel h3,.nu-wrap[data-theme="frost"] .nu-dev-head b{color:#0b2545}',
			'.nu-wrap[data-theme="frost"] .nu-badge.blk{color:#fff}.nu-wrap[data-theme="frost"] .nu-badge.pau,.nu-wrap[data-theme="frost"] .nu-badge.lim{color:#78350f}',
			'.nu-wrap[data-theme="frost"] .nu-value{text-shadow:none}.nu-wrap[data-theme="frost"] .nu-card{color:#0b2545}',
			'.nu-wrap[data-theme="frost"] input,.nu-wrap[data-theme="frost"] select{color:#0f2744}',
			'.nu-wrap{position:relative;isolation:isolate;overflow:hidden;max-width:980px;padding:18px;border-radius:26px;color:var(--fg);' +
				'background:radial-gradient(circle at 10% 6%,var(--o1) 0,transparent 44%),radial-gradient(circle at 90% 12%,var(--o2) 0,transparent 42%),' +
				'radial-gradient(circle at 72% 94%,var(--o3) 0,transparent 46%),radial-gradient(circle at 6% 88%,var(--o4) 0,transparent 40%),var(--bg);transition:background .35s,color .35s}',
			'.nu-wrap::before,.nu-wrap::after{content:"";position:absolute;z-index:-1;border-radius:50%;filter:blur(60px);opacity:.5;animation:nufloat 14s ease-in-out infinite alternate}',
			'.nu-wrap::before{width:260px;height:260px;left:-60px;top:32%;background:var(--b1)}',
			'.nu-wrap::after{width:300px;height:300px;right:-80px;bottom:8%;background:var(--b2);animation-delay:-6s}',
			'.nu-wrap[data-theme="frost"]::before,.nu-wrap[data-theme="frost"]::after{opacity:.35}',
			'@keyframes nufloat{to{transform:translate(40px,-50px) scale(1.15)}}',
			'@media (prefers-reduced-motion:reduce){.nu-wrap::before,.nu-wrap::after{animation:none}}',
			'.nu-wrap[data-anim="off"]::before,.nu-wrap[data-anim="off"]::after{animation:none}',
			'.nu-wrap[data-blur="off"]{--blur:0px}',
			'.nu-wrap h2{margin:0 0 14px;font-size:24px;font-weight:700;letter-spacing:.3px;background:var(--h2);-webkit-background-clip:text;background-clip:text;color:transparent}',
			'.nu-card,.nu-panel,.nu-stat,.nu-tabs,.nu-dev,.nu-theme{backdrop-filter:blur(var(--blur)) saturate(160%);-webkit-backdrop-filter:blur(var(--blur)) saturate(160%);border:1px solid var(--bd);box-shadow:0 10px 30px var(--sh),inset 0 1px 0 var(--hi)}',
			'.nu-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(170px,1fr));gap:12px;margin-bottom:16px}',
			'.nu-card{position:relative;overflow:hidden;border-radius:20px;padding:16px;color:var(--card-fg)}',
			'.nu-card::after{content:"";position:absolute;inset:0;background:linear-gradient(120deg,var(--sheen),transparent 45%);pointer-events:none}',
			'.nu-card.down{background:var(--c-down)}.nu-card.up{background:var(--c-up)}.nu-card.total{background:var(--c-total)}',
			'.nu-card.live{background:var(--c-live)}.nu-card.live2{background:var(--c-live2)}',
			'.nu-label{font-size:11px;opacity:.9;text-transform:uppercase;letter-spacing:.6px}',
			'.nu-value{font-size:22px;font-weight:700;margin-top:6px;text-shadow:0 2px 8px rgba(0,0,0,.25)}',
			'.nu-sub{font-size:11px;opacity:.8;margin-top:4px}',
			'.nu-panel{border-radius:20px;padding:16px;margin-bottom:16px;background:linear-gradient(135deg,var(--g1),var(--g2))}',
			'.nu-panel h3{margin:0 0 12px;font-size:16px;color:var(--card-fg)}',
			'.nu-capbar{height:14px;border-radius:7px;background:var(--track);overflow:hidden;margin:8px 0}',
			'.nu-capbar-fill{height:100%;width:0;border-radius:7px;background:var(--fill);transition:width .4s}',
			'.nu-capbar-fill.warn{background:linear-gradient(90deg,#fbbf24,#f59e0b)}',
			'.nu-capbar-fill.bad{background:linear-gradient(90deg,#f87171,#dc2626)}',
			'.nu-tabs{display:flex;gap:6px;margin-bottom:14px;flex-wrap:wrap;padding:6px;border-radius:999px;background:var(--hov)}',
			'.nu-tab{padding:8px 16px;border-radius:999px;border:0;cursor:pointer;background:transparent;color:var(--fg2);font-size:13px;font-weight:600;transition:all .2s}',
			'.nu-tab:hover{background:var(--hov)}',
			'.nu-tab.active{background:var(--tab);color:#fff;box-shadow:0 4px 14px var(--tabsh)}',
			'.nu-chart{display:flex;gap:3px;align-items:stretch;height:150px}',
			'.nu-col{flex:1;display:flex;flex-direction:column;min-width:0}',
			'.nu-bar{flex:1;display:flex;flex-direction:column;justify-content:flex-end}',
			'.nu-seg-rx{background:var(--rx)}',
			'.nu-seg-tx{background:var(--tx);border-radius:4px 4px 0 0}',
			'.nu-day{font-size:9px;text-align:center;opacity:.75;margin-top:3px}',
			'.nu-lg{display:inline-block;width:10px;height:10px;border-radius:3px;margin:0 4px 0 8px;vertical-align:middle}',
			'.nu-lg.d{background:var(--rx)}.nu-lg.u{background:var(--tx)}',
			'.nu-table{width:100%;border-collapse:collapse}',
			'.nu-table th,.nu-table td{white-space:nowrap}',
			'.nu-wrap .nu-table,.nu-wrap .nu-table tr,.nu-wrap .nu-table th,.nu-wrap .nu-table td{background:transparent}',
			'.nu-table th{padding:8px 10px;text-align:left;font-size:11px;text-transform:uppercase;letter-spacing:.6px;color:var(--th);border-bottom:1px solid var(--bd)}',
			'.nu-table td{padding:9px 10px;text-align:left;font-size:13px;color:var(--td);border-bottom:1px solid var(--line)}',
			'.nu-wrap .nu-table tbody tr:hover td{background:var(--hov)}',
			'.nu-mini{height:8px;min-width:60px;border-radius:4px;background:var(--track);overflow:hidden}',
			'.nu-mini-fill{height:100%;background:var(--mini)}',
			'.nu-form,.nu-devctl{display:flex;flex-wrap:wrap;gap:10px;align-items:flex-end;margin-bottom:10px}',
			'.nu-form label,.nu-devctl label,.nu-dev-lim label{display:flex;flex-direction:column;font-size:12px;gap:4px;color:var(--fg2)}',
			'.nu-wrap input,.nu-wrap select{background:var(--inp);color:var(--card-fg);border:1px solid var(--inpbd);border-radius:12px;padding:8px 12px;backdrop-filter:blur(8px);-webkit-backdrop-filter:blur(8px)}',
			'.nu-wrap select option{color:#111;background:#fff}',
			'.nu-wrap .cbi-button{background:var(--hov);color:var(--card-fg);border:1px solid var(--inpbd);border-radius:999px;padding:7px 16px;cursor:pointer;transition:all .2s;box-shadow:inset 0 1px 0 var(--hi)}',
			'.nu-wrap .cbi-button:hover{filter:brightness(1.15)}',
			'.nu-wrap .cbi-button:disabled{opacity:.4;cursor:not-allowed}',
			'.nu-wrap .cbi-button-action,.nu-wrap .cbi-button-save{background:var(--act);border-color:transparent}',
			'.nu-wrap .cbi-button-remove{background:rgba(220,38,38,.55);border-color:rgba(248,113,113,.5)}',
			'.nu-wrap .nu-btn-block{background:rgba(220,38,38,.55);border-color:rgba(248,113,113,.5)}',
			'.nu-wrap .nu-btn-ok{background:var(--ok);border-color:var(--okbd)}',
			'.nu-scroll{overflow-x:auto}',
			'.nu-muted,.nu-refresh{font-size:12px;opacity:.78}',
			'.nu-refresh{text-align:right}',
			'.nu-stats{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:10px;margin-bottom:14px}',
			'.nu-stat{border-radius:16px;padding:12px 14px;background:linear-gradient(135deg,var(--g1),var(--g2));border-left:3px solid var(--b2)}',
			'.nu-stat.d{border-left-color:var(--cdl)}.nu-stat.u{border-left-color:var(--cul)}.nu-stat.p{border-left-color:var(--cpg)}',
			'.nu-stat b{display:block;font-size:22px;margin-top:4px}',
			'.nu-stat small{font-size:11px;opacity:.8;text-transform:uppercase;letter-spacing:.5px}',
			'.nu-sgrp{flex:1;display:flex;gap:1px;align-items:flex-end}',
			'.nu-sd{flex:1;border-radius:3px 3px 0 0;background:var(--rx)}',
			'.nu-su{flex:1;border-radius:3px 3px 0 0;background:var(--tx)}',
			'.nu-pg{color:var(--cpg);font-weight:600}.nu-dl{color:var(--cdl);font-weight:600}.nu-ul{color:var(--cul);font-weight:600}',
			'.nu-devgrid{display:grid;grid-template-columns:repeat(auto-fit,minmax(270px,1fr));gap:12px;margin-top:6px}',
			'.nu-dev{border-radius:18px;padding:14px;background:linear-gradient(135deg,var(--g1),var(--g2));display:flex;flex-direction:column;gap:8px}',
			'.nu-dev.blocked{border-color:rgba(248,113,113,.6)}.nu-dev.paused{border-color:rgba(251,191,36,.6)}',
			'.nu-dev-head{display:flex;justify-content:space-between;align-items:center;gap:8px}',
			'.nu-dev-head b{font-size:15px;color:var(--card-fg);word-break:break-word}',
			'.nu-dev-stats{display:flex;gap:16px;font-size:14px}',
			'.nu-dev-act,.nu-dev-lim{display:flex;flex-wrap:wrap;gap:8px;align-items:flex-end}',
			'.nu-dev-lim{border-top:1px solid var(--line);padding-top:8px}',
			'.nu-dev-lim input{width:92px}',
			'.nu-badge{font-size:11px;padding:3px 10px;border-radius:999px;white-space:nowrap;background:var(--bdg);color:var(--bdgfg)}',
			'.nu-badge.blk{background:rgba(220,38,38,.6);color:#fee2e2}.nu-badge.pau,.nu-badge.lim{background:rgba(245,158,11,.5);color:#fef3c7}',
			'.nu-themes{display:grid;grid-template-columns:repeat(auto-fit,minmax(150px,1fr));gap:12px;margin:6px 0 14px}',
			'.nu-theme{cursor:pointer;border-radius:18px;padding:10px;background:linear-gradient(135deg,var(--g1),var(--g2));transition:transform .2s,border-color .2s;text-align:left;color:var(--fg);font:inherit}',
			'.nu-theme:hover{transform:translateY(-3px)}',
			'.nu-theme.sel{border-color:var(--cdl);box-shadow:0 0 0 2px var(--cdl),0 10px 30px var(--sh)}',
			'.nu-theme .sw{height:64px;border-radius:12px;margin-bottom:8px;position:relative;overflow:hidden}',
			'.nu-theme .sw i{position:absolute;display:block;border-radius:8px}',
			'.nu-theme b{display:block;font-size:14px}.nu-theme small{font-size:11px;opacity:.75}',
			'.nu-opts{display:flex;flex-wrap:wrap;gap:18px;margin-top:6px;font-size:13px}',
			'.nu-opts label{display:flex;align-items:center;gap:8px;cursor:pointer}',
			'@media (max-width:600px){.nu-table th,.nu-table td{padding:8px 6px;font-size:12px}.nu-wrap{padding:12px;border-radius:20px}.nu-value{font-size:19px}.nu-wrap h2{font-size:20px}}'
		].join('\n'));

		function card(cls, label, id, val, sub) {
			return E('div', { 'class': 'nu-card ' + cls }, [
				E('div', { 'class': 'nu-label' }, label),
				E('div', { 'class': 'nu-value', 'id': id }, val),
				E('div', { 'class': 'nu-sub' }, sub)
			]);
		}

		var grid = E('div', { 'class': 'nu-grid' }, [
			card('live', _('Live Download'), 'nu-down', '--', _('Current speed')),
			card('live2', _('Live Upload'), 'nu-up', '--', _('Current speed')),
			card('down', _('Total Download'), 'nu-rx', '0 B', _('All time (vnstat)')),
			card('up', _('Total Upload'), 'nu-tx', '0 B', _('All time (vnstat)')),
			card('total', _('Combined'), 'nu-total', '0 B', _('All time (vnstat)'))
		]);

		var capPanel = E('div', { 'class': 'nu-panel' }, [
			E('h3', {}, _('Billing cycle usage')),
			E('div', { 'id': 'nu-capmain', 'style': 'font-weight:600' }, '--'),
			E('div', { 'class': 'nu-capbar' }, E('div', { 'id': 'nu-capbar', 'class': 'nu-capbar-fill' })),
			E('div', { 'id': 'nu-capsub', 'class': 'nu-muted' }, '')
		]);

		var tabBar = E('div', { 'class': 'nu-tabs' }, TABS.map(function (t) {
			return E('button', { 'id': 'nu-t-' + t[0], 'class': 'nu-tab', 'click': function () { showTab(t[0]); } }, t[1]);
		}));

		function usageTable(bodyId, firstCol) {
			return E('div', { 'class': 'nu-scroll' }, E('table', { 'class': 'nu-table' }, [
				E('thead', {}, E('tr', {}, [
					E('th', {}, firstCol), E('th', {}, _('Download')), E('th', {}, _('Upload')),
					E('th', {}, _('Total')), E('th', {}, _('Share'))
				])),
				E('tbody', { 'id': bodyId })
			]));
		}

		var pDaily = E('div', { 'id': 'nu-p-daily', 'class': 'nu-panel' }, [
			E('h3', {}, _('Daily usage (last 30 days)')),
			E('div', { 'id': 'nu-chart', 'class': 'nu-chart' }),
			E('div', { 'class': 'nu-muted', 'style': 'margin:6px 0 12px' }, [ E('span', { 'class': 'nu-lg d', 'style': 'margin-left:0' }), _('Download'), E('span', { 'class': 'nu-lg u' }), _('Upload') ]),
			usageTable('nu-dtbody', _('Date'))
		]);

		var pMonthly = E('div', { 'id': 'nu-p-monthly', 'class': 'nu-panel' }, [
			E('h3', {}, _('Monthly usage')),
			usageTable('nu-mtbody', _('Month'))
		]);

		var pDevices = E('div', { 'id': 'nu-p-devices', 'class': 'nu-panel' }, [
			E('h3', {}, _('Usage per device')),
			E('div', { 'class': 'nu-devctl' }, [
				E('button', { 'id': 'nu-m-daily', 'class': 'cbi-button', 'click': function () { setDevMode('daily'); } }, _('Daily')),
				E('button', { 'id': 'nu-m-monthly', 'class': 'cbi-button', 'click': function () { setDevMode('monthly'); } }, _('Monthly')),
				E('select', { 'id': 'nu-devsel', 'class': 'cbi-input-select', 'change': function (ev) {
					state.devPick[state.devMode] = ev.target.value;
					paintDevices();
				} })
			]),
			E('div', { 'id': 'nu-devmsg', 'class': 'nu-muted' }, ''),
			E('div', { 'class': 'nu-scroll' }, E('table', { 'class': 'nu-table' }, [
				E('thead', {}, E('tr', {}, [
					E('th', {}, _('Device')), E('th', {}, _('Download')), E('th', {}, _('Upload')),
					E('th', {}, _('Total')), E('th', {}, _('Share'))
				])),
				E('tbody', { 'id': 'nu-devbody' })
			])),
			E('div', { 'class': 'nu-muted', 'style': 'margin-top:8px' },
				_('Device usage covers LAN clients as seen by nlbwmon. Daily = last 31 days, monthly = calendar months.'))
		]);

		var durSel = E('select', { 'id': 'nu-ctl-dur', 'class': 'cbi-input-select', 'change': function (ev) {
			state.pauseMin = parseInt(ev.target.value, 10) || 0;
		} }, [
			[ 15, _('15 minutes') ], [ 30, _('30 minutes') ], [ 60, _('1 hour') ], [ 120, _('2 hours') ],
			[ 240, _('4 hours') ], [ 480, _('8 hours') ], [ 0, _('Until I unblock') ]
		].map(function (o) { return E('option', { 'value': String(o[0]) }, o[1]); }));
		durSel.value = '30';

		var pCtl = E('div', { 'id': 'nu-p-ctl', 'class': 'nu-panel' }, [
			E('h3', {}, _('Device control')),
			E('div', { 'class': 'nu-muted', 'style': 'margin-bottom:10px' },
				_('Block = no internet and no router access. Pause = no internet only, comes back by itself. Rules use the MAC address, work instantly and survive reboots.')),
			E('div', { 'class': 'nu-devctl' }, [
				E('label', {}, [ _('Pause for'), durSel ]),
				E('button', { 'class': 'cbi-button', 'click': function () { return refreshCtl(); } }, _('Refresh')),
				E('button', { 'class': 'cbi-button nu-btn-ok', 'click': ctlClear }, _('Unblock all'))
			]),
			E('div', { 'class': 'nu-devctl' }, [
				E('label', {}, [ _('Add by MAC'), E('input', { 'id': 'nu-ctl-mac', 'type': 'text', 'placeholder': 'aa:bb:cc:dd:ee:ff', 'class': 'cbi-input-text' }) ]),
				E('label', {}, [ _('Name (optional)'), E('input', { 'id': 'nu-ctl-name', 'type': 'text', 'class': 'cbi-input-text' }) ]),
				E('button', { 'class': 'cbi-button nu-btn-block', 'click': function () { return ctlAdd('block'); } }, _('Block')),
				E('button', { 'class': 'cbi-button cbi-button-action', 'click': function () { return ctlAdd('pause'); } }, _('Pause'))
			]),
			E('div', { 'id': 'nu-ctl-msg', 'class': 'nu-muted' }, ''),
			E('div', { 'id': 'nu-ctl-warn', 'class': 'nu-muted' }, ''),
			E('div', { 'id': 'nu-devgrid', 'class': 'nu-devgrid' }),
			E('div', { 'class': 'nu-muted', 'style': 'margin-top:10px' },
				_('Limits: Warn only just marks the device. Auto pause pauses it until the day or month ends. Unblock ignores the limit for the rest of today. Emergency from SSH: netusage-devctl unblock aa:bb:cc:dd:ee:ff  or  netusage-devctl clear'))
		]);

		var pSpeed = E('div', { 'id': 'nu-p-speed', 'class': 'nu-panel' }, [
			E('h3', {}, _('Speed tests')),
			E('div', { 'class': 'nu-stats' }, [
				E('div', { 'class': 'nu-stat d' }, [ E('small', {}, _('Peak download')), E('b', {}, [ E('span', { 'id': 'nu-st-pd' }, '--'), ' Mbps' ]) ]),
				E('div', { 'class': 'nu-stat u' }, [ E('small', {}, _('Peak upload')), E('b', {}, [ E('span', { 'id': 'nu-st-pu' }, '--'), ' Mbps' ]) ]),
				E('div', { 'class': 'nu-stat p' }, [ E('small', {}, _('Average ping')), E('b', {}, [ E('span', { 'id': 'nu-st-ping' }, '--'), ' ms' ]) ]),
				E('div', { 'class': 'nu-stat' }, [ E('small', {}, _('Total tests')), E('b', { 'id': 'nu-st-n' }, '0') ])
			]),
			E('div', { 'class': 'nu-devctl' }, [
				E('button', { 'id': 'nu-st-run', 'class': 'cbi-button cbi-button-action', 'click': runSpeedTest }, _('Run test now')),
				E('button', { 'class': 'cbi-button', 'click': exportSpeedCsv }, _('Export CSV')),
				E('button', { 'class': 'cbi-button cbi-button-remove', 'click': clearSpeed }, _('Clear history')),
				E('button', { 'class': 'cbi-button', 'click': function () { return refreshAll(); } }, _('Refresh'))
			]),
			E('div', { 'id': 'nu-st-msg', 'class': 'nu-muted' }, ''),
			E('div', { 'id': 'nu-st-chart', 'class': 'nu-chart', 'style': 'margin:10px 0 4px' }),
			E('div', { 'class': 'nu-muted', 'style': 'margin-bottom:10px' }, [ _('Last 20 tests: '), E('span', { 'class': 'nu-lg d', 'style': 'margin-left:0' }), _('Download'), E('span', { 'class': 'nu-lg u' }), _('Upload') ]),
			E('div', { 'class': 'nu-scroll' }, E('table', { 'class': 'nu-table' }, [
				E('thead', {}, E('tr', {}, [
					E('th', {}, '#'), E('th', {}, _('Date & time')), E('th', {}, _('Server')), E('th', {}, _('ISP')),
					E('th', {}, _('Ping')), E('th', {}, _('Download')), E('th', {}, _('Upload')),
					E('th', {}, _('Loss')), E('th', {}, _('Result'))
				])),
				E('tbody', { 'id': 'nu-stbody' })
			])),
			E('div', { 'class': 'nu-muted', 'style': 'margin-top:8px' },
				_('Each test can use 2 GB or more at gigabit speed and counts against your data cap. Latest 50 shown, CSV has all (max 300 kept).'))
		]);

		var fxBlur = lsGet('nu_blur', '1') !== '0', fxAnim = lsGet('nu_anim', '1') !== '0';
		var cbBlur = E('input', { 'type': 'checkbox', 'id': 'nu-fx-blur', 'change': function (ev) { fxBlur = ev.target.checked; applyFx(fxBlur, fxAnim, true); } });
		var cbAnim = E('input', { 'type': 'checkbox', 'id': 'nu-fx-anim', 'change': function (ev) { fxAnim = ev.target.checked; applyFx(fxBlur, fxAnim, true); } });
		cbBlur.checked = fxBlur; cbAnim.checked = fxAnim;

		var pThemes = E('div', { 'id': 'nu-p-themes', 'class': 'nu-panel' }, [
			E('h3', {}, _('Themes')),
			E('div', { 'class': 'nu-muted' }, _('Tap a theme to apply it instantly. Only the look changes, your data is not touched. Saved in this browser.')),
			E('div', { 'class': 'nu-themes' }, THEMES.map(function (t) {
				return E('button', { 'id': 'nu-th-' + t[0], 'class': 'nu-theme', 'type': 'button', 'click': function () { applyTheme(t[0], true); } }, [
					E('div', { 'class': 'sw', 'style': 'background:' + t[3] + ',' + t[4] }, [
						E('i', { 'style': 'left:8px;top:8px;width:44%;height:20px;background:' + t[5] + ';opacity:.85' }),
						E('i', { 'style': 'right:8px;top:8px;width:30%;height:20px;background:' + t[6] + ';opacity:.85' }),
						E('i', { 'style': 'left:8px;bottom:8px;width:84%;height:18px;background:' + t[3] + ';opacity:.7' })
					]),
					E('b', {}, t[1]),
					E('small', {}, t[2])
				]);
			})),
			E('div', { 'class': 'nu-opts' }, [
				E('label', {}, [ cbBlur, _('Glass blur') ]),
				E('label', {}, [ cbAnim, _('Floating glow animation') ])
			])
		]);

		var pSettings = E('div', { 'id': 'nu-p-settings', 'class': 'nu-panel' }, [
			E('h3', {}, _('Settings')),
			E('div', { 'class': 'nu-form' }, [
				E('label', {}, [ _('Interface'), E('input', { 'id': 'nu-in-iface', 'type': 'text', 'class': 'cbi-input-text' }) ]),
				E('label', {}, [ _('Monthly cap (GB, 0 = off)'), E('input', { 'id': 'nu-in-cap', 'type': 'number', 'min': 0, 'class': 'cbi-input-text' }) ]),
				E('label', {}, [ _('Cycle start day (1-28)'), E('input', { 'id': 'nu-in-cd', 'type': 'number', 'min': 1, 'max': 28, 'class': 'cbi-input-text' }) ]),
				E('label', {}, [ _('Auto speed test every N hours (0 = off)'), E('input', { 'id': 'nu-in-sh', 'type': 'number', 'min': 0, 'max': 24, 'class': 'cbi-input-text' }) ]),
				E('button', { 'class': 'cbi-button cbi-button-save', 'click': saveSettings }, _('Save')),
				E('span', { 'id': 'nu-saved', 'class': 'nu-muted' }, '')
			])
		]);

		var wrap = E('div', { 'class': 'nu-wrap' }, [
			style,
			E('h2', {}, _('Router Data Usage')),
			E('div', { 'id': 'nu-status', 'class': 'nu-muted' }, ''),
			grid, capPanel, tabBar, pDaily, pMonthly, pDevices, pCtl, pSpeed, pThemes, pSettings,
			E('div', { 'class': 'nu-refresh' }, [ _('Last update: '), E('span', { 'id': 'nu-time' }, '--') ])
		]);

		applyTheme(lsGet('nu_theme', 'ocean'), false); applyFx(fxBlur, fxAnim, false);
		wrap.setAttribute('data-theme', lsGet('nu_theme', 'ocean'));
		requestAnimationFrame(function () { fillForm(); applyTheme(lsGet('nu_theme', 'ocean'), false); applyFx(fxBlur, fxAnim, false); showTab(state.tab); paint(); });

		poll.add(liveTick, 2);
		poll.add(function () {
			if (state.tab !== 'ctl') return;
			return callDevLive().then(function (l) { feedLive(l); paintCtl(); }).catch(function () {});
		}, 3);
		return wrap;
	}
});
JSEOF
ok "Dashboard view installed"

log "Restarting rpcd and clearing LuCI cache..."
/etc/init.d/rpcd restart
rm -f /tmp/luci-indexcache* 2>/dev/null || true
rm -rf /tmp/luci-modulecache/* 2>/dev/null || true
/etc/init.d/uhttpd restart
ok "Services restarted, cache cleared"

/usr/bin/netusage-devctl apply 2>/dev/null || true
# first sample so per-device tracking starts right away
[ "$DEV_OK" = "1" ] && /usr/bin/netusage-collect 2>/dev/null || true

echo ""
echo "=================================================="
echo " NetUsage v${SCRIPT_VERSION} installed successfully"
echo "=================================================="
echo " Dashboard : Status -> Data Usage"
echo " Interface : ${WAN_IFACE}"
echo " Package   : ${PKG_MGR} (vnstat)"
if [ "$DEV_OK" = "1" ]; then
echo " Per device: enabled (first data within ~1 hour)"
else
echo " Per device: DISABLED (nlbwmon missing)"
fi
if [ "$ST_OK" = "1" ]; then
echo " Speed test: enabled (about 1-2 GB per test at gigabit speed)"
else
echo " Speed test: DISABLED (Ookla CLI not installed)"
fi
echo " Dev. ctrl : block / pause by MAC (nftables, survives reboot)"
echo " Data store: /etc/vnstat + /etc/netusage (survive reboot)"
echo " Uninstall : sh netusage_v2.sh --uninstall"
echo "=================================================="
