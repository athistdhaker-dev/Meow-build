# Maraj Wallpaper - separate TV (Jio STB) and Mobile apps
One Flutter codebase, two purpose-built UIs, two APKs.

| | TV / Jio STB (`--dart-define=TARGET=tv`) | Mobile (`--dart-define=TARGET=mobile`) |
|---|---|---|
| Layout | Left category rail + big 3-column grid, ambient background of the focused wallpaper, TV safe margins | Search bar, category chips, pull-to-refresh grid |
| Input | D-pad only: arrows, OK = download, Up = slideshow | Touch: tap, swipe between wallpapers, tap to hide UI |
| Wallpapers | 16:9, 1080p+ (4K category) | 9:16 in portrait, 16:9 in landscape |
| Extras | Auto-hiding overlay, key hints, slideshow | Set as Home / Lock wallpaper, Download |
| Manifest | Leanback launcher + banner, no touchscreen required | Normal launcher, SET_WALLPAPER |

Build: upload this zip + build-apk.yml to GitHub; the workflow builds both APKs. Local:
    flutter create --platforms=android --org com.maraj --project-name maraj_wallpaper .
    python3 tools/patch_manifest.py tv
    flutter build apk --release --target-platform android-arm,android-arm64 --dart-define=TARGET=tv --obfuscate --split-debug-info=build/dbg-tv
    python3 tools/patch_manifest.py mobile
    flutter build apk --release --target-platform android-arm,android-arm64 --dart-define=TARGET=mobile --obfuscate --split-debug-info=build/dbg-mobile

Install on STB: `adb connect <STB-IP>:5555` then `adb install MarajWallpaper-TV-*.apk`. Phone: open the Mobile APK.

## Which APK do I install?
| File | Use for |
|---|---|
| `MarajWallpaper-TV-*.apk` | Jio STB / Android TV (armeabi-v7a + arm64-v8a in one APK) |
| `MarajWallpaper-Mobile-arm64-v8a-*.apk` | almost every phone made after ~2016 |
| `MarajWallpaper-Mobile-armeabi-v7a-*.apk` | older 32-bit phones |
| `MarajWallpaper-Mobile-x86_64-*.apk` | emulators / Chromebooks / x86 tablets |
| `MarajWallpaper-Mobile-universal-*.apk` | not sure? contains all of the above (bigger file) |

All APKs are signed with the SAME key (`tools/maraj-sideload.jks`, or your own via GitHub secrets
KEYSTORE_BASE64 / KEYSTORE_PASSWORD / KEY_ALIAS), so new builds update over old ones.
If an older build (signed with a different key) is installed, uninstall it once first.
For JioStore / Play Store use your OWN private keystore (secrets) - never the bundled one.
