# Maraj Wallpaper (Jio STB / Android TV)
Flutter app, wallpapers from Wallhaven public API. See STORE_LISTING.md for JioStore submission.

Build (GitHub): upload this zip + build-apk.yml to a repo. Local:
    flutter create --platforms=android --org com.maraj --project-name maraj_wallpaper .
    python3 tools/patch_manifest.py
    flutter build apk --release --target-platform android-arm,android-arm64 --obfuscate --split-debug-info=build/debug-info

Install on STB: `adb connect <STB-IP>:5555` then `adb install app-release.apk` (update: `adb install -r`).
