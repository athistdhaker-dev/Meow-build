# Maraj Wallpaper (Android TV)
Flutter app. Wallpapers: Wallhaven public API (SFW, 16:9, 1080p+).

## APK banane ke 2 tareeke
**A) GitHub (Flutter install ki zaroorat nahi):** is folder ko ek naye GitHub repo me upload karo -> Actions tab -> "Build APK" -> artifact `maraj-wallpaper-apk` download karo.

**B) Local:**
    flutter create --platforms=android --org com.maraj --project-name maraj_wallpaper .
    python3 tools/patch_manifest.py
    flutter build apk --release --split-per-abi

TV pe install: `adb connect <tv-ip>` then `adb install app-armeabi-v7a-release.apk` (ya arm64-v8a).
