# Maraj Wallpaper (Android phone + Jio STB / Android TV)
Flutter app, "liquid glass" UI, wallpapers from Wallhaven public API.
- Phone: touch (tap, swipe left/right in viewer), portrait 9:16 or landscape wallpapers.
- TV / Jio STB: D-pad remote (arrows, OK = download, Up = slideshow), 16:9 wallpapers, lighter glass for low-end GPUs.
See STORE_LISTING.md for JioStore submission.

Build: upload this zip + build-apk.yml to GitHub (workflow does everything). Local:
    flutter create --platforms=android --org com.maraj --project-name maraj_wallpaper .
    python3 tools/patch_manifest.py
    flutter build apk --release --target-platform android-arm,android-arm64 --obfuscate --split-debug-info=build/debug-info

Install: phone - copy APK and open it; STB - `adb connect <STB-IP>:5555` then `adb install app-release.apk`.
