import 'package:flutter/material.dart';

import 'core.dart';
import 'mobile.dart';
import 'tv.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await detectTarget();
  final cache = PaintingBinding.instance.imageCache;
  cache.maximumSizeBytes = (isTv ? (lowEnd ? 48 : 80) : 200) << 20; // STB has 1-2 GB RAM
  cache.maximumSize = 150;
  runApp(const MarajApp());
}

class MarajApp extends StatelessWidget {
  const MarajApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Maraj Wallpaper',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: Colors.transparent,
          appBarTheme: const AppBarTheme(
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0),
        ),
        builder: (_, child) =>
            GlassBackdrop(child: isTv ? TvCanvas(child: child!) : child!),
        home: isTv ? const TvHome() : const MobileHome(),
      );
}
