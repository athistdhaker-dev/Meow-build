import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:http/http.dart' as http;

void main() => runApp(const MarajApp());

class MarajApp extends StatelessWidget {
  const MarajApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Maraj Wallpaper',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true)
            .copyWith(scaffoldBackgroundColor: const Color(0xFF0B0B10)),
        home: const Home(),
      );
}

class Wall {
  final String thumb, full, res;
  Wall(this.thumb, this.full, this.res);
}

// name: [search query, sorting]
const cats = <String, List<String>>{
  'Top': ['', 'toplist'],
  'Latest': ['', 'date_added'],
  'Random': ['', 'random'],
  'Nature': ['nature', 'toplist'],
  'Space': ['space', 'toplist'],
  'City': ['city', 'toplist'],
  'Cars': ['cars', 'toplist'],
  'Anime': ['anime', 'toplist'],
  'Abstract': ['abstract', 'toplist'],
  'Minimal': ['minimal', 'toplist'],
};

// Wallhaven public API (free, no key needed for SFW). 16:9, min 1080p.
Future<List<Wall>> fetchWalls(String q, String sort, int page) async {
  final u = Uri.https('wallhaven.cc', '/api/v1/search', {
    'q': q, 'categories': '111', 'purity': '100', 'sorting': sort,
    'atleast': '1920x1080', 'ratios': '16x9', 'page': '$page',
  });
  final r = await http.get(u).timeout(const Duration(seconds: 20));
  if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
  return (jsonDecode(r.body)['data'] as List)
      .map((e) => Wall(e['thumbs']['large'], e['path'], e['resolution']))
      .toList();
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String cat = 'Top';
  final items = <Wall>[];
  int page = 1;
  bool loading = false;
  String? error;

  @override
  void initState() {
    super.initState();
    load(reset: true);
  }

  Future<void> load({bool reset = false}) async {
    if (loading) return;
    if (reset) {
      items.clear();
      page = 1;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final c = cats[cat]!;
      items.addAll(await fetchWalls(c[0], c[1], page++));
    } catch (e) {
      error = 'Load nahi hua: $e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Padding(
          padding: const EdgeInsets.fromLTRB(48, 28, 48, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            const Text('Maraj Wallpaper',
                style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
            const SizedBox(height: 14),
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final k in cats.keys)
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: ChoiceChip(
                        label: Text(k, style: const TextStyle(fontSize: 18)),
                        selected: cat == k,
                        autofocus: k == 'Top',
                        onSelected: (_) {
                          cat = k;
                          load(reset: true);
                        },
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (error != null)
              Text(error!, style: const TextStyle(color: Colors.redAccent)),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.only(bottom: 40, top: 8),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 18,
                    mainAxisSpacing: 18,
                    childAspectRatio: 16 / 9),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  if (i >= items.length - 4) {
                    Future.microtask(load);
                  }
                  return Tile(
                    wall: items[i],
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => Viewer(items: items, start: i))),
                  );
                },
              ),
            ),
            if (loading) const LinearProgressIndicator(),
          ]),
        ),
      );
}

class Tile extends StatefulWidget {
  final Wall wall;
  final VoidCallback onTap;
  const Tile({super.key, required this.wall, required this.onTap});
  @override
  State<Tile> createState() => _TileState();
}

class _TileState extends State<Tile> {
  bool focused = false;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: widget.onTap,
        onFocusChange: (f) => setState(() => focused = f),
        borderRadius: BorderRadius.circular(12),
        child: AnimatedScale(
          scale: focused ? 1.07 : 1,
          duration: const Duration(milliseconds: 150),
          child: Container(
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(12),
              border: Border.all(
                  color: focused ? Colors.white : Colors.transparent, width: 3),
            ),
            clipBehavior: Clip.antiAlias,
            child: Image.network(widget.wall.thumb,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const ColoredBox(color: Colors.black26)),
          ),
        ),
      );
}

class Viewer extends StatefulWidget {
  final List<Wall> items;
  final int start;
  const Viewer({super.key, required this.items, required this.start});
  @override
  State<Viewer> createState() => _ViewerState();
}

class _ViewerState extends State<Viewer> {
  late int i = widget.start;
  Timer? timer;
  bool auto = false;

  void go(int d) {
    final len = widget.items.length;
    setState(() => i = (i + d + len) % len);
    precacheImage(NetworkImage(widget.items[(i + 1) % len].full), context);
  }

  void toggle() {
    setState(() => auto = !auto);
    timer?.cancel();
    if (auto) timer = Timer.periodic(const Duration(seconds: 10), (_) => go(1));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.items[i];
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (_, e) {
          if (e is! KeyDownEvent) return KeyEventResult.ignored;
          final k = e.logicalKey;
          if (k == LogicalKeyboardKey.arrowRight) {
            go(1);
          } else if (k == LogicalKeyboardKey.arrowLeft) {
            go(-1);
          } else if (k == LogicalKeyboardKey.select ||
              k == LogicalKeyboardKey.enter) {
            toggle();
          } else {
            return KeyEventResult.ignored;
          }
          return KeyEventResult.handled;
        },
        child: Stack(fit: StackFit.expand, children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: Image.network(w.full,
                key: ValueKey(w.full),
                fit: BoxFit.cover,
                loadingBuilder: (_, c, p) => p == null
                    ? c
                    : const Center(child: CircularProgressIndicator()),
                errorBuilder: (_, __, ___) =>
                    const Center(child: Text('Image load nahi hui'))),
          ),
          Positioned(
            left: 24,
            bottom: 18,
            child: Text(
                '${i + 1}/${widget.items.length}  •  ${w.res}  •  ◀ ▶ badlo  •  OK = slideshow ${auto ? "ON" : "OFF"}',
                style: const TextStyle(
                    fontSize: 16, shadows: [Shadow(blurRadius: 6)])),
          ),
        ]),
      ),
    );
  }
}
