import 'dart:async';
import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;

import 'legal.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  // STB has only 1-2 GB RAM: keep the image cache small.
  PaintingBinding.instance.imageCache
    ..maximumSizeBytes = 80 << 20
    ..maximumSize = 120;
  runApp(const MarajApp());
}

const _storage = MethodChannel('maraj/storage');

/// Free external storage in percent (Jio rule: don't write if < 20%).
Future<double> freePercent() async {
  try {
    return (await _storage.invokeMethod<double>('freePercent')) ?? 100;
  } catch (_) {
    return 100;
  }
}

class MarajApp extends StatelessWidget {
  const MarajApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Maraj Wallpaper',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true)
            .copyWith(scaffoldBackgroundColor: const Color(0xFF0B0B10)),
        home: const Home(),
      );
}

class Wall {
  final String thumb, full, res;
  Wall(this.thumb, this.full, this.res);
}

// name: [search query, sorting, min resolution]
const _hd = '1920x1080', _4k = '3840x2160';
const cats = <String, List<String>>{
  'Top': ['', 'toplist', _hd],
  'Latest': ['', 'date_added', _hd],
  'Random': ['', 'random', _hd],
  '4K': ['', 'toplist', _4k],
  'Nature': ['nature', 'toplist', _hd],
  'Mountains': ['mountains', 'toplist', _hd],
  'Ocean': ['ocean', 'toplist', _hd],
  'Sunset': ['sunset', 'toplist', _hd],
  'Space': ['space', 'toplist', _hd],
  'City': ['city', 'toplist', _hd],
  'Architecture': ['architecture', 'toplist', _hd],
  'Cars': ['cars', 'toplist', _hd],
  'Animals': ['animals', 'toplist', _hd],
  'Flowers': ['flowers', 'toplist', _hd],
  'Anime': ['anime', 'toplist', _hd],
  'Gaming': ['game', 'toplist', _hd],
  'Fantasy': ['fantasy', 'toplist', _hd],
  'Technology': ['technology', 'toplist', _hd],
  'Abstract': ['abstract', 'toplist', _hd],
  'Minimal': ['minimal', 'toplist', _hd],
  'Dark': ['dark', 'toplist', _hd],
};

// Wallhaven public API (free, no key needed for SFW). 16:9.
Future<List<Wall>> fetchWalls(String q, String sort, String min, int page) async {
  final u = Uri.https('wallhaven.cc', '/api/v1/search', {
    'q': q, 'categories': '111', 'purity': '100', 'sorting': sort,
    'atleast': min, 'ratios': '16x9', 'page': '$page',
  });
  final r = await http.get(u).timeout(const Duration(seconds: 20));
  if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
  return (jsonDecode(r.body)['data'] as List)
      .map((e) => Wall(e['thumbs']['large'], e['path'], e['resolution']))
      .toList();
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String cat = 'Top';
  final items = <Wall>[];
  int page = 1;
  bool loading = false;
  String? error;

  @override
  void initState() {
    super.initState();
    load(reset: true);
  }

  Future<void> load({bool reset = false}) async {
    if (loading) return;
    if (reset) {
      items.clear();
      page = 1;
    }
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final c = cats[cat]!;
      items.addAll(await fetchWalls(c[0], c[1], c[2], page++));
    } catch (e) {
      error = 'Load nahi hua: $e';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Padding(
          padding: const EdgeInsets.fromLTRB(48, 28, 48, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              ClipRRect(
                  borderRadius: BorderRadius.circular(12),
                  child: Image.asset('assets/logo.png', width: 56, height: 56)),
              const SizedBox(width: 16),
              const Text('Maraj Wallpaper',
                  style: TextStyle(fontSize: 34, fontWeight: FontWeight.bold)),
              const Spacer(),
              OutlinedButton.icon(
                icon: const Icon(Icons.info_outline),
                label: const Text('About & Legal'),
                onPressed: () => Navigator.push(context,
                    MaterialPageRoute(builder: (_) => const InfoScreen())),
              ),
            ]),
            const SizedBox(height: 14),
            SizedBox(
              height: 52,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final k in cats.keys)
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: ChoiceChip(
                        label: Text(k, style: const TextStyle(fontSize: 18)),
                        selected: cat == k,
                        autofocus: k == 'Top',
                        onSelected: (_) {
                          cat = k;
                          load(reset: true);
                        },
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 14),
            if (error != null)
              Text(error!, style: const TextStyle(color: Colors.redAccent)),
            Expanded(
              child: GridView.builder(
                padding: const EdgeInsets.only(bottom: 40, top: 8),
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                    crossAxisCount: 4,
                    crossAxisSpacing: 18,
                    mainAxisSpacing: 18,
                    childAspectRatio: 16 / 9),
                itemCount: items.length,
                itemBuilder: (_, i) {
                  if (i >= items.length - 4) {
                    Future.microtask(load);
                  }
                  return Tile(
                    wall: items[i],
                    onTap: () => Navigator.push(
                        context,
                        MaterialPageRoute(
                            builder: (_) => Viewer(items: items, start: i))),
                  );
                },
              ),
            ),
            if (loading) const LinearProgressIndicator(),
          ]),
        ),
      );
}

class Tile extends StatefulWidget {
  final Wall wall;
  final VoidCallback onTap;
  const Tile({super.key, required this.wall, required this.onTap});
  @override
  State<Tile> createState() => _TileState();
}

class _TileState extends State<Tile> {
  bool focused = false;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: widget.onTap,
        onFocusChange: (f) => setState(() => focused = f),
        borderRadius: BorderRadius.circular(12),
        child: Container(
          // fixed size/position: only the border colour changes on focus
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(12),
            border: Border.all(
                color: focused ? Colors.white : Colors.transparent, width: 4),
          ),
          clipBehavior: Clip.antiAlias,
          child: Image.network(widget.wall.thumb,
              cacheWidth: 480,
              fit: BoxFit.cover,
              errorBuilder: (_, __, ___) =>
                  const ColoredBox(color: Colors.black26)),
        ),
      );
}

class Viewer extends StatefulWidget {
  final List<Wall> items;
  final int start;
  const Viewer({super.key, required this.items, required this.start});
  @override
  State<Viewer> createState() => _ViewerState();
}

class _ViewerState extends State<Viewer> {
  late int i = widget.start;
  Timer? timer;
  bool auto = false, busy = false;
  String status = '';

  void say(String m) {
    if (mounted) setState(() => status = m);
  }

  Future<void> download() async {
    if (busy) return;
    busy = true;
    say('Download ho raha hai...');
    try {
      if (await freePercent() < 20) {
        busy = false;
        say('Storage kam hai (20% se kam free). Pehle jagah khali karein.');
        return;
      }
      if (!await Gal.hasAccess(toAlbum: true) &&
          !await Gal.requestAccess(toAlbum: true)) {
        throw 'storage permission nahi mili';
      }
      final r = await http
          .get(Uri.parse(widget.items[i].full))
          .timeout(const Duration(seconds: 60));
      await Gal.putImageBytes(r.bodyBytes, album: 'Maraj Wallpaper');
      say('Saved! Pictures/Maraj Wallpaper me mil jayegi');
    } catch (e) {
      say('Download fail: $e');
    }
    busy = false;
  }

  void go(int d) {
    final len = widget.items.length;
    setState(() => i = (i + d + len) % len);
    precacheImage(
        ResizeImage(NetworkImage(widget.items[(i + 1) % len].full), width: 1920),
        context);
  }

  void toggle() {
    setState(() => auto = !auto);
    timer?.cancel();
    if (auto) timer = Timer.periodic(const Duration(seconds: 10), (_) => go(1));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.items[i];
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (_, e) {
          if (e is! KeyDownEvent) return KeyEventResult.ignored;
          final k = e.logicalKey;
          if (k == LogicalKeyboardKey.arrowRight) {
            go(1);
          } else if (k == LogicalKeyboardKey.arrowLeft) {
            go(-1);
          } else if (k == LogicalKeyboardKey.arrowUp) {
            toggle();
          } else if (k == LogicalKeyboardKey.select ||
              k == LogicalKeyboardKey.enter) {
            download();
          } else {
            return KeyEventResult.ignored;
          }
          return KeyEventResult.handled;
        },
        child: Stack(fit: StackFit.expand, children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: Image.network(w.full,
                key: ValueKey(w.full),
                cacheWidth: 1920,
                fit: BoxFit.cover,
                loadingBuilder: (_, c, p) => p == null
                    ? c
                    : const Center(child: CircularProgressIndicator()),
                errorBuilder: (_, __, ___) =>
                    const Center(child: Text('Image load nahi hui'))),
          ),
          Positioned(
            left: 24,
            bottom: 18,
            child: Text(
                '${i + 1}/${widget.items.length}  •  ${w.res}  •  ◀ ▶ badlo  •  OK = Download  •  ▲ Slideshow ${auto ? "ON" : "OFF"}${status.isEmpty ? "" : "\n$status"}',
                style: const TextStyle(
                    fontSize: 16, shadows: [Shadow(blurRadius: 6)])),
          ),
        ]),
      ),
    );
  }
}

class InfoScreen extends StatelessWidget {
  const InfoScreen({super.key});
  @override
  Widget build(BuildContext context) {
    void open(String t, String b) => Navigator.push(context,
        MaterialPageRoute(builder: (_) => DocPage(title: t, body: b)));
    return Scaffold(
      appBar: AppBar(title: const Text('About & Legal')),
      body: ListView(padding: const EdgeInsets.all(32), children: [
        ListTile(
            autofocus: true,
            title: const Text('Privacy Policy'),
            onTap: () => open('Privacy Policy', kPrivacy)),
        ListTile(
            title: const Text('Terms & Conditions'),
            onTap: () => open('Terms & Conditions', kTerms)),
        ListTile(
            title: const Text('Open-source licenses'),
            onTap: () => showLicensePage(
                context: context,
                applicationName: kAppName,
                applicationVersion: kVersion)),
        const ListTile(
            title: Text('$kAppName v$kVersion'),
            subtitle: Text(
                'Wallpapers: Wallhaven.cc\nPrivacy Policy & Terms last updated $kLastUpdated'),
            isThreeLine: true),
      ]),
    );
  }
}

class DocPage extends StatefulWidget {
  final String title, body;
  const DocPage({super.key, required this.title, required this.body});
  @override
  State<DocPage> createState() => _DocPageState();
}

class _DocPageState extends State<DocPage> {
  final sc = ScrollController();
  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  void scroll(double d) => sc.animateTo(
      (sc.offset + d).clamp(0.0, sc.position.maxScrollExtent),
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: Focus(
          autofocus: true,
          onKeyEvent: (_, e) {
            if (e is! KeyDownEvent) return KeyEventResult.ignored;
            if (e.logicalKey == LogicalKeyboardKey.arrowDown) {
              scroll(300);
            } else if (e.logicalKey == LogicalKeyboardKey.arrowUp) {
              scroll(-300);
            } else {
              return KeyEventResult.ignored;
            }
            return KeyEventResult.handled;
          },
          child: SingleChildScrollView(
            controller: sc,
            padding: const EdgeInsets.all(32),
            child: Text(widget.body,
                style: const TextStyle(fontSize: 20, height: 1.5)),
          ),
        ),
      );
}
