import 'dart:async';
import 'dart:convert';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;

import 'legal.dart';

const _storage = MethodChannel('maraj/storage');

/// true on TV / set-top box (low-end GPU: lighter glass), false on phones.
bool isTv = true;
double get panelBlur => isTv ? 12 : 24;
double get smallBlur => isTv ? 0 : 16;

/// Free external storage in percent (Jio rule: don't write if < 20%).
Future<double> freePercent() async {
  try {
    return (await _storage.invokeMethod<double>('freePercent')) ?? 100;
  } catch (_) {
    return 100;
  }
}

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  try {
    isTv = (await _storage.invokeMethod<bool>('isTv')) ?? true;
  } catch (_) {
    isTv = true;
  }
  final cache = PaintingBinding.instance.imageCache;
  cache.maximumSizeBytes = (isTv ? 80 : 200) << 20; // STB has 1-2 GB RAM
  cache.maximumSize = 150;
  runApp(const MarajApp());
}

class MarajApp extends StatelessWidget {
  const MarajApp({super.key});
  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Maraj Wallpaper',
        debugShowCheckedModeBanner: false,
        theme: ThemeData.dark(useMaterial3: true).copyWith(
          scaffoldBackgroundColor: Colors.transparent,
          appBarTheme: const AppBarTheme(
              backgroundColor: Colors.transparent,
              elevation: 0,
              scrolledUnderElevation: 0),
        ),
        builder: (_, child) => GlassBackdrop(child: child!),
        home: const Home(),
      );
}

// ---------------------------------------------------------------- glass UI

/// Dark gradient with soft colour orbs - gives the glass something to refract.
class GlassBackdrop extends StatelessWidget {
  final Widget child;
  const GlassBackdrop({super.key, required this.child});
  Widget orb(Color c, double s) => Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient: RadialGradient(
                colors: [c.withAlpha(170), c.withAlpha(0)])),
      );
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        const DecoratedBox(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0A0A1C), Color(0xFF1A1040)]))),
        Positioned(top: -140, left: -100, child: orb(const Color(0xFF7B2FF7), 480)),
        Positioned(bottom: -180, right: -120, child: orb(const Color(0xFFEC5678), 520)),
        Positioned(top: 220, right: 120, child: orb(const Color(0xFF2FA8F7), 320)),
        child,
      ]);
}

/// Frosted "liquid glass" surface: blur + translucent gradient + specular rim.
class Glass extends StatelessWidget {
  final Widget child;
  final double radius, blur;
  final EdgeInsets padding;
  final bool focused, selected;
  const Glass({
    super.key,
    required this.child,
    this.radius = 20,
    this.blur = 20,
    this.padding = EdgeInsets.zero,
    this.focused = false,
    this.selected = false,
  });
  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    Widget box = Container(
      decoration: BoxDecoration(
        borderRadius: r,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withAlpha(selected ? 100 : 58),
            Colors.white.withAlpha(selected ? 44 : 14),
          ],
        ),
        border: Border.all(
            color: Colors.white.withAlpha(focused ? 240 : 72),
            width: focused ? 3 : 1.2),
      ),
      child: Stack(children: [
        Padding(padding: padding, child: child),
        // specular highlight along the top edge
        Positioned(
          top: 0,
          left: radius * .6,
          right: radius * .6,
          height: 1.5,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.white.withAlpha(0),
                Colors.white.withAlpha(190),
                Colors.white.withAlpha(0),
              ]),
            ),
          ),
        ),
      ]),
    );
    if (blur > 0) {
      box = BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur), child: box);
    }
    return ClipRRect(borderRadius: r, child: box);
  }
}

/// Pill button. Focusable (remote D-pad) or touch-only (focusable: false).
class GlassButton extends StatefulWidget {
  final String? label;
  final IconData? icon;
  final VoidCallback onTap;
  final bool selected, autofocus, focusable, expand;
  final double blur;
  const GlassButton({
    super.key,
    required this.onTap,
    this.label,
    this.icon,
    this.selected = false,
    this.autofocus = false,
    this.focusable = true,
    this.expand = false,
    this.blur = 0,
  });
  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool f = false;
  @override
  Widget build(BuildContext context) {
    final content = Glass(
      radius: 28,
      blur: widget.blur,
      selected: widget.selected,
      focused: f,
      padding: EdgeInsets.symmetric(
          horizontal: widget.label == null ? 13 : 20, vertical: 12),
      child: Row(
        mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
        children: [
          if (widget.icon != null) Icon(widget.icon, size: 24),
          if (widget.icon != null && widget.label != null)
            const SizedBox(width: 10),
          if (widget.label != null)
            Text(widget.label!,
                style:
                    const TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        ],
      ),
    );
    if (!widget.focusable) {
      return GestureDetector(onTap: widget.onTap, child: content);
    }
    return InkWell(
      onTap: widget.onTap,
      autofocus: widget.autofocus,
      onFocusChange: (v) => setState(() => f = v),
      borderRadius: BorderRadius.circular(28),
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      child: content,
    );
  }
}

// -------------------------------------------------------------------- data

class Wall {
  final String thumb, full, res;
  Wall(this.thumb, this.full, this.res);
}

const _hd = '1920x1080', _4k = '3840x2160';
// name: [search query, sorting, min resolution (landscape)]
const cats = <String, List<String>>{
  'Top': ['', 'toplist', _hd],
  'Latest': ['', 'date_added', _hd],
  'Random': ['', 'random', _hd],
  '4K': ['', 'toplist', _4k],
  'Nature': ['nature', 'toplist', _hd],
  'Mountains': ['mountains', 'toplist', _hd],
  'Ocean': ['ocean', 'toplist', _hd],
  'Sunset': ['sunset', 'toplist', _hd],
  'Space': ['space', 'toplist', _hd],
  'City': ['city', 'toplist', _hd],
  'Architecture': ['architecture', 'toplist', _hd],
  'Cars': ['cars', 'toplist', _hd],
  'Animals': ['animals', 'toplist', _hd],
  'Flowers': ['flowers', 'toplist', _hd],
  'Anime': ['anime', 'toplist', _hd],
  'Gaming': ['game', 'toplist', _hd],
  'Fantasy': ['fantasy', 'toplist', _hd],
  'Technology': ['technology', 'toplist', _hd],
  'Abstract': ['abstract', 'toplist', _hd],
  'Minimal': ['minimal', 'toplist', _hd],
  'Dark': ['dark', 'toplist', _hd],
};

String _flip(String m) {
  final p = m.split('x');
  return '${p[1]}x${p[0]}';
}

// Wallhaven public API (free, no key for SFW). 16:9 on TV/landscape,
// 9:16 on phones held in portrait.
Future<List<Wall>> fetchWalls(
    String q, String sort, String min, bool portrait, int page) async {
  final u = Uri.https('wallhaven.cc', '/api/v1/search', {
    'q': q,
    'categories': '111',
    'purity': '100',
    'sorting': sort,
    'atleast': portrait ? _flip(min) : min,
    'ratios': portrait ? '9x16' : '16x9',
    'page': '$page',
  });
  final r = await http.get(u).timeout(const Duration(seconds: 20));
  if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
  return (jsonDecode(r.body)['data'] as List)
      .map((e) => Wall(e['thumbs']['large'], e['path'], e['resolution']))
      .toList();
}

// -------------------------------------------------------------------- home

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  String cat = 'Top';
  final items = <Wall>[];
  int page = 1, gen = 0;
  bool loading = false;
  bool? portrait;
  String? error;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final p = MediaQuery.sizeOf(context).aspectRatio < 1;
    if (portrait != p) {
      portrait = p;
      Future.microtask(() => load(reset: true));
    }
  }

  Future<void> load({bool reset = false}) async {
    if (loading && !reset) return;
    if (reset) {
      items.clear();
      page = 1;
      gen++;
    }
    final g = gen;
    setState(() {
      loading = true;
      error = null;
    });
    try {
      final c = cats[cat]!;
      final r = await fetchWalls(c[0], c[1], c[2], portrait ?? false, page++);
      if (g != gen) return;
      items.addAll(r);
    } catch (e) {
      if (g != gen) return;
      error = 'Could not load wallpapers ($e)';
    }
    if (mounted) setState(() => loading = false);
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final tall = size.aspectRatio < 1;
    final big = size.width >= 1000; // TV / tablet
    final cols = big ? 4 : (tall ? 2 : 3);
    final pad = big ? 48.0 : 14.0;
    return Scaffold(
      body: SafeArea(
        child: Padding(
          padding: EdgeInsets.fromLTRB(pad, big ? 24 : 8, pad, 0),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Glass(
              radius: 30,
              blur: panelBlur,
              padding: EdgeInsets.symmetric(
                  horizontal: big ? 20 : 12, vertical: big ? 12 : 8),
              child: Row(children: [
                ClipRRect(
                    borderRadius: BorderRadius.circular(12),
                    child: Image.asset('assets/logo.png',
                        width: big ? 52 : 40, height: big ? 52 : 40)),
                const SizedBox(width: 14),
                Flexible(
                  child: Text('Maraj Wallpaper',
                      overflow: TextOverflow.ellipsis,
                      style: TextStyle(
                          fontSize: big ? 32 : 20,
                          fontWeight: FontWeight.bold)),
                ),
                const Spacer(),
                GlassButton(
                  icon: Icons.info_outline,
                  label: big ? 'About & Legal' : null,
                  blur: smallBlur,
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const InfoScreen())),
                ),
              ]),
            ),
            const SizedBox(height: 12),
            SizedBox(
              height: 54,
              child: ListView(
                scrollDirection: Axis.horizontal,
                children: [
                  for (final k in cats.keys)
                    Padding(
                      padding: const EdgeInsets.only(right: 10),
                      child: GlassButton(
                        label: k,
                        selected: cat == k,
                        autofocus: big && k == 'Top',
                        blur: smallBlur,
                        onTap: () {
                          cat = k;
                          load(reset: true);
                        },
                      ),
                    ),
                ],
              ),
            ),
            const SizedBox(height: 12),
            if (error != null)
              Padding(
                padding: const EdgeInsets.only(bottom: 8),
                child: Row(children: [
                  Expanded(
                      child: Text(error!,
                          style: const TextStyle(color: Colors.redAccent))),
                  GlassButton(
                      label: 'Retry',
                      icon: Icons.refresh,
                      blur: smallBlur,
                      onTap: () => load(reset: true)),
                ]),
              ),
            Expanded(
              child: items.isEmpty && loading
                  ? const Center(child: CircularProgressIndicator())
                  : GridView.builder(
                      padding: const EdgeInsets.only(bottom: 24, top: 4),
                      gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                          crossAxisCount: cols,
                          crossAxisSpacing: 14,
                          mainAxisSpacing: 14,
                          childAspectRatio: tall ? 9 / 16 : 16 / 9),
                      itemCount: items.length,
                      itemBuilder: (_, i) {
                        if (i >= items.length - 4) Future.microtask(load);
                        return Tile(
                          wall: items[i],
                          onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                  builder: (_) =>
                                      Viewer(items: items, start: i))),
                        );
                      },
                    ),
            ),
            if (loading && items.isNotEmpty)
              const LinearProgressIndicator(minHeight: 3),
          ]),
        ),
      ),
    );
  }
}

class Tile extends StatefulWidget {
  final Wall wall;
  final VoidCallback onTap;
  const Tile({super.key, required this.wall, required this.onTap});
  @override
  State<Tile> createState() => _TileState();
}

class _TileState extends State<Tile> {
  bool focused = false;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: widget.onTap,
        onFocusChange: (f) => setState(() => focused = f),
        borderRadius: BorderRadius.circular(18),
        focusColor: Colors.transparent,
        hoverColor: Colors.transparent,
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
        // fixed size & position: only the glass rim changes on focus
        child: Glass(
          radius: 18,
          blur: 0,
          focused: focused,
          padding: const EdgeInsets.all(4),
          child: ClipRRect(
            borderRadius: BorderRadius.circular(14),
            child: Stack(fit: StackFit.expand, children: [
              Image.network(widget.wall.thumb,
                  cacheWidth: 480,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) =>
                      const ColoredBox(color: Colors.black26)),
              Positioned(
                left: 8,
                bottom: 8,
                child: Glass(
                  radius: 10,
                  blur: 0,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                  child: Text(widget.wall.res,
                      style: const TextStyle(fontSize: 12)),
                ),
              ),
            ]),
          ),
        ),
      );
}

// ------------------------------------------------------------------ viewer

class Viewer extends StatefulWidget {
  final List<Wall> items;
  final int start;
  const Viewer({super.key, required this.items, required this.start});
  @override
  State<Viewer> createState() => _ViewerState();
}

class _ViewerState extends State<Viewer> {
  late int i = widget.start;
  Timer? timer;
  bool auto = false, busy = false, ui = true;
  String status = '';

  void say(String m) {
    if (mounted) setState(() => status = m);
  }

  Future<void> download() async {
    if (busy) return;
    busy = true;
    say('Downloading...');
    try {
      if (await freePercent() < 20) {
        busy = false;
        say('Storage low (under 20% free). Free some space first.');
        return;
      }
      if (!await Gal.hasAccess(toAlbum: true) &&
          !await Gal.requestAccess(toAlbum: true)) {
        throw 'storage permission denied';
      }
      final r = await http
          .get(Uri.parse(widget.items[i].full))
          .timeout(const Duration(seconds: 60));
      await Gal.putImageBytes(r.bodyBytes, album: 'Maraj Wallpaper');
      say('Saved to Pictures/Maraj Wallpaper');
    } catch (e) {
      say('Download failed: $e');
    }
    busy = false;
  }

  void go(int d) {
    final len = widget.items.length;
    setState(() => i = (i + d + len) % len);
    final w = MediaQuery.sizeOf(context).aspectRatio < 1 ? 1080 : 1920;
    precacheImage(
        ResizeImage(NetworkImage(widget.items[(i + 1) % len].full), width: w),
        context);
  }

  void toggle() {
    setState(() => auto = !auto);
    timer?.cancel();
    if (auto) timer = Timer.periodic(const Duration(seconds: 10), (_) => go(1));
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final w = widget.items[i];
    final size = MediaQuery.sizeOf(context);
    final big = size.width >= 1000;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (_, e) {
          if (e is! KeyDownEvent) return KeyEventResult.ignored;
          final k = e.logicalKey;
          if (k == LogicalKeyboardKey.arrowRight) {
            go(1);
          } else if (k == LogicalKeyboardKey.arrowLeft) {
            go(-1);
          } else if (k == LogicalKeyboardKey.arrowUp) {
            toggle();
          } else if (k == LogicalKeyboardKey.select ||
              k == LogicalKeyboardKey.enter) {
            download();
          } else {
            return KeyEventResult.ignored;
          }
          return KeyEventResult.handled;
        },
        child: GestureDetector(
          behavior: HitTestBehavior.opaque,
          onTap: () => setState(() => ui = !ui),
          onHorizontalDragEnd: (d) {
            final v = d.primaryVelocity ?? 0;
            if (v < -200) go(1);
            if (v > 200) go(-1);
          },
          child: Stack(fit: StackFit.expand, children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 500),
              child: Image.network(w.full,
                  key: ValueKey(w.full),
                  cacheWidth: size.aspectRatio < 1 ? 1080 : 1920,
                  fit: BoxFit.cover,
                  loadingBuilder: (_, c, p) => p == null
                      ? c
                      : const Center(child: CircularProgressIndicator()),
                  errorBuilder: (_, __, ___) =>
                      const Center(child: Text('Could not load image'))),
            ),
            if (ui)
              SafeArea(
                child: Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: GlassButton(
                      icon: Icons.arrow_back,
                      focusable: false,
                      blur: smallBlur,
                      onTap: () => Navigator.pop(context),
                    ),
                  ),
                ),
              ),
            if (ui)
              SafeArea(
                child: Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.all(14),
                    child: Glass(
                      radius: 30,
                      blur: panelBlur,
                      padding: const EdgeInsets.all(14),
                      child: Column(mainAxisSize: MainAxisSize.min, children: [
                        Text(
                            '${i + 1}/${widget.items.length}  •  ${w.res}'
                            '${status.isEmpty ? "" : "\n$status"}',
                            textAlign: TextAlign.center,
                            style: const TextStyle(fontSize: 15)),
                        const SizedBox(height: 10),
                        Wrap(
                          alignment: WrapAlignment.center,
                          spacing: 12,
                          runSpacing: 8,
                          children: [
                            GlassButton(
                                icon: Icons.chevron_left,
                                focusable: false,
                                onTap: () => go(-1)),
                            GlassButton(
                                icon: Icons.download,
                                label: 'Download',
                                focusable: false,
                                onTap: download),
                            GlassButton(
                                icon: auto ? Icons.pause : Icons.play_arrow,
                                label: 'Slideshow',
                                selected: auto,
                                focusable: false,
                                onTap: toggle),
                            GlassButton(
                                icon: Icons.chevron_right,
                                focusable: false,
                                onTap: () => go(1)),
                          ],
                        ),
                        if (big) ...[
                          const SizedBox(height: 8),
                          const Text(
                              '◀ ▶ change   •   OK download   •   ▲ slideshow',
                              style: TextStyle(fontSize: 14)),
                        ],
                      ]),
                    ),
                  ),
                ),
              ),
          ]),
        ),
      ),
    );
  }
}

// ------------------------------------------------------------- legal pages

class InfoScreen extends StatelessWidget {
  const InfoScreen({super.key});
  @override
  Widget build(BuildContext context) {
    void open(String t, String b) => Navigator.push(context,
        MaterialPageRoute(builder: (_) => DocPage(title: t, body: b)));
    return Scaffold(
      appBar: AppBar(title: const Text('About & Legal')),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Glass(
                radius: 30,
                blur: panelBlur,
                padding: const EdgeInsets.all(18),
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    GlassButton(
                        expand: true,
                        autofocus: true,
                        icon: Icons.privacy_tip_outlined,
                        label: 'Privacy Policy',
                        onTap: () => open('Privacy Policy', kPrivacy)),
                    const SizedBox(height: 12),
                    GlassButton(
                        expand: true,
                        icon: Icons.description_outlined,
                        label: 'Terms & Conditions',
                        onTap: () => open('Terms & Conditions', kTerms)),
                    const SizedBox(height: 12),
                    GlassButton(
                        expand: true,
                        icon: Icons.code,
                        label: 'Open-source licenses',
                        onTap: () => showLicensePage(
                            context: context,
                            applicationName: kAppName,
                            applicationVersion: kVersion)),
                    const SizedBox(height: 18),
                    const Text(
                        '$kAppName v$kVersion\nWallpapers: Wallhaven.cc\n'
                        'Privacy Policy & Terms last updated $kLastUpdated',
                        textAlign: TextAlign.center),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DocPage extends StatefulWidget {
  final String title, body;
  const DocPage({super.key, required this.title, required this.body});
  @override
  State<DocPage> createState() => _DocPageState();
}

class _DocPageState extends State<DocPage> {
  final sc = ScrollController();
  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  void scroll(double d) => sc.animateTo(
      (sc.offset + d).clamp(0.0, sc.position.maxScrollExtent),
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: SafeArea(
          child: Focus(
            autofocus: true,
            onKeyEvent: (_, e) {
              if (e is! KeyDownEvent) return KeyEventResult.ignored;
              if (e.logicalKey == LogicalKeyboardKey.arrowDown) {
                scroll(300);
              } else if (e.logicalKey == LogicalKeyboardKey.arrowUp) {
                scroll(-300);
              } else {
                return KeyEventResult.ignored;
              }
              return KeyEventResult.handled;
            },
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
              child: Glass(
                radius: 28,
                blur: panelBlur,
                child: SingleChildScrollView(
                  controller: sc,
                  padding: const EdgeInsets.all(24),
                  child: Text(widget.body,
                      style: const TextStyle(fontSize: 18, height: 1.5)),
                ),
              ),
            ),
          ),
        ),
      );
}
