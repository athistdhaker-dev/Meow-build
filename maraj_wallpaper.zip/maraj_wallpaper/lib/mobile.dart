import 'package:flutter/material.dart';

import 'core.dart';
import 'pages.dart';

// Touch-first UI for phones: search, chips, pull-to-refresh, swipe viewer,
// "set as wallpaper" (home / lock screen).

class MobileHome extends StatefulWidget {
  const MobileHome({super.key});
  @override
  State<MobileHome> createState() => _MobileHomeState();
}

class _MobileHomeState extends State<MobileHome> {
  final feed = WallFeed();
  final tc = TextEditingController();
  bool started = false;

  @override
  void didChangeDependencies() {
    super.didChangeDependencies();
    final p = MediaQuery.sizeOf(context).aspectRatio < 1;
    if (!started || feed.portrait != p) {
      started = true;
      feed.portrait = p;
      Future.microtask(() => feed.load(reset: true));
    }
  }

  @override
  void dispose() {
    feed.dispose();
    tc.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.sizeOf(context);
    final tall = size.aspectRatio < 1;
    final cols = (size.width / (tall ? 175 : 250)).floor().clamp(2, 6);
    return Scaffold(
      body: SafeArea(
        child: ListenableBuilder(
          listenable: feed,
          builder: (_, __) => Column(children: [
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
              child: Row(children: [
                ClipRRect(
                    borderRadius: BorderRadius.circular(10),
                    child: Image.asset('assets/logo.png', width: 38, height: 38)),
                const SizedBox(width: 12),
                const Expanded(
                  child: Text('Maraj Wallpaper',
                      overflow: TextOverflow.ellipsis,
                      style:
                          TextStyle(fontSize: 22, fontWeight: FontWeight.bold)),
                ),
                GlassButton(
                  icon: Icons.info_outline,
                  focusable: false,
                  dense: true,
                  blur: smallBlur,
                  onTap: () => Navigator.push(context,
                      MaterialPageRoute(builder: (_) => const InfoScreen())),
                ),
              ]),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Glass(
                radius: 26,
                blur: smallBlur,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: Row(children: [
                  const Icon(Icons.search, size: 22),
                  const SizedBox(width: 10),
                  Expanded(
                    child: TextField(
                      controller: tc,
                      textInputAction: TextInputAction.search,
                      onSubmitted: feed.search,
                      decoration: const InputDecoration(
                          border: InputBorder.none,
                          hintText: 'Search wallpapers'),
                    ),
                  ),
                  if (feed.query.isNotEmpty)
                    GestureDetector(
                      onTap: () {
                        tc.clear();
                        feed.setCat(feed.cat);
                      },
                      child: const Icon(Icons.close, size: 22),
                    ),
                ]),
              ),
            ),
            SizedBox(
              height: 42,
              child: ListView(
                scrollDirection: Axis.horizontal,
                padding: const EdgeInsets.symmetric(horizontal: 16),
                children: [
                  for (final k in cats.keys)
                    Padding(
                      padding: const EdgeInsets.only(right: 8),
                      child: GlassButton(
                        label: k,
                        dense: true,
                        focusable: false,
                        selected: feed.query.isEmpty && feed.cat == k,
                        blur: smallBlur,
                        onTap: () {
                          tc.clear();
                          feed.setCat(k);
                        },
                      ),
                    ),
                ],
              ),
            ),
            if (feed.source.isNotEmpty)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 6, 16, 0),
                child: Align(
                  alignment: Alignment.centerLeft,
                  child: Text(feed.sourceLine,
                      style: const TextStyle(
                          fontSize: 12, color: Colors.white70)),
                ),
              ),
            if (feed.error != null)
              Padding(
                padding: const EdgeInsets.fromLTRB(16, 8, 16, 0),
                child: Row(children: [
                  Expanded(
                      child: Text(feed.error!,
                          style: const TextStyle(color: Colors.redAccent))),
                  GlassButton(
                      label: 'Retry',
                      dense: true,
                      focusable: false,
                      onTap: () => feed.refresh()),
                ]),
              ),
            Expanded(
              child: RefreshIndicator(
                onRefresh: () => feed.refresh(),
                child: feed.items.isEmpty && feed.loading
                    ? const Center(child: CircularProgressIndicator())
                    : GridView.builder(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
                        gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                            crossAxisCount: cols,
                            crossAxisSpacing: 12,
                            mainAxisSpacing: 12,
                            childAspectRatio: tall ? 9 / 16 : 16 / 9),
                        itemCount: feed.items.length,
                        itemBuilder: (_, i) {
                          if (i >= feed.items.length - 4) {
                            Future.microtask(feed.load);
                          }
                          return _tile(i);
                        },
                      ),
              ),
            ),
            if (feed.loading && feed.items.isNotEmpty)
              const LinearProgressIndicator(minHeight: 3),
          ]),
        ),
      ),
    );
  }

  Widget _tile(int i) {
    final w = feed.items[i];
    return GestureDetector(
      onTap: () => Navigator.push(
          context,
          MaterialPageRoute(
              builder: (_) => MobileViewer(items: feed.items, start: i))),
      child: Container(
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: Colors.white.withAlpha(70)),
        ),
        clipBehavior: Clip.antiAlias,
        child: Stack(fit: StackFit.expand, children: [
          Hero(
            tag: 'wall_$i',
            child: Image.network(w.thumb,
                cacheWidth: 400,
                fit: BoxFit.cover,
                errorBuilder: (_, __, ___) =>
                    const ColoredBox(color: Colors.black26)),
          ),
          Positioned(
            left: 8,
            bottom: 8,
            child: Glass(
              radius: 10,
              blur: 0,
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
              child: Text(w.res, style: const TextStyle(fontSize: 12)),
            ),
          ),
        ]),
      ),
    );
  }
}

// ------------------------------------------------------------------ viewer

class MobileViewer extends StatefulWidget {
  final List<Wall> items;
  final int start;
  const MobileViewer({super.key, required this.items, required this.start});
  @override
  State<MobileViewer> createState() => _MobileViewerState();
}

class _MobileViewerState extends State<MobileViewer> {
  late final pc = PageController(initialPage: widget.start);
  late int i = widget.start;
  bool ui = true, busy = false;

  @override
  void dispose() {
    pc.dispose();
    super.dispose();
  }

  void toast(String m) {
    if (!mounted) return;
    ScaffoldMessenger.of(context)
      ..hideCurrentSnackBar()
      ..showSnackBar(SnackBar(
        content: Text(m),
        behavior: SnackBarBehavior.floating,
        backgroundColor: const Color(0xE61A1040),
        duration: const Duration(seconds: 3),
      ));
  }

  Future<void> download() async {
    if (busy) return;
    busy = true;
    toast('Downloading...');
    try {
      toast(await saveWall(widget.items[i].full));
    } catch (e) {
      toast('Download failed: $e');
    }
    busy = false;
  }

  void chooseWallpaperTarget() {
    showModalBottomSheet<void>(
      context: context,
      backgroundColor: Colors.transparent,
      builder: (ctx) => SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(14),
          child: Glass(
            radius: 30,
            blur: 24,
            padding: const EdgeInsets.all(16),
            child: Column(mainAxisSize: MainAxisSize.min, children: [
              const Text('Set as wallpaper',
                  style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
              const SizedBox(height: 14),
              for (final o in const [
                (1, 'Home screen', Icons.home_outlined),
                (2, 'Lock screen', Icons.lock_outline),
                (3, 'Home & lock screen', Icons.smartphone),
              ]) ...[
                GlassButton(
                  expand: true,
                  focusable: false,
                  icon: o.$3,
                  label: o.$2,
                  onTap: () {
                    Navigator.pop(ctx);
                    setWallpaper(o.$1);
                  },
                ),
                const SizedBox(height: 10),
              ],
            ]),
          ),
        ),
      ),
    );
  }

  Future<void> setWallpaper(int which) async {
    toast('Setting wallpaper...');
    try {
      final ok = await applyWallpaper(widget.items[i].full, which);
      toast(ok ? 'Wallpaper set' : 'Could not set wallpaper');
    } catch (e) {
      toast('Could not set wallpaper: $e');
    }
  }

  Widget _action(IconData icon, String label, VoidCallback onTap) =>
      GestureDetector(
        onTap: onTap,
        behavior: HitTestBehavior.opaque,
        child: Padding(
          padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 6),
          child: Column(mainAxisSize: MainAxisSize.min, children: [
            Icon(icon, size: 28),
            const SizedBox(height: 4),
            Text(label, style: const TextStyle(fontSize: 12.5)),
          ]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final tall = MediaQuery.sizeOf(context).aspectRatio < 1;
    return Scaffold(
      backgroundColor: Colors.black,
      body: Stack(fit: StackFit.expand, children: [
        PageView.builder(
          controller: pc,
          itemCount: widget.items.length,
          onPageChanged: (p) {
            setState(() => i = p);
            if (p + 1 < widget.items.length) {
              precacheImage(
                  ResizeImage(NetworkImage(widget.items[p + 1].full),
                      width: tall ? 1080 : 1920),
                  context);
            }
          },
          itemBuilder: (_, idx) => GestureDetector(
            onTap: () => setState(() => ui = !ui),
            child: Hero(
              tag: 'wall_$idx',
              child: Image.network(widget.items[idx].full,
                  fit: BoxFit.cover,
                  cacheWidth: tall ? 1080 : 1920,
                  loadingBuilder: (_, c, p) => p == null
                      ? c
                      : Stack(fit: StackFit.expand, children: [
                          Image.network(widget.items[idx].thumb,
                              fit: BoxFit.cover),
                          const Center(child: CircularProgressIndicator()),
                        ]),
                  errorBuilder: (_, __, ___) =>
                      const Center(child: Text('Could not load image'))),
            ),
          ),
        ),
        IgnorePointer(
          ignoring: !ui,
          child: AnimatedOpacity(
            opacity: ui ? 1 : 0,
            duration: const Duration(milliseconds: 200),
            child: SafeArea(
              child: Stack(children: [
                Align(
                  alignment: Alignment.topLeft,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: GlassButton(
                      icon: Icons.arrow_back,
                      focusable: false,
                      dense: true,
                      blur: smallBlur,
                      onTap: () => Navigator.pop(context),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.topRight,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Glass(
                      radius: 20,
                      blur: smallBlur,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 14, vertical: 8),
                      child: Text(
                          '${i + 1} / ${widget.items.length}  •  ${widget.items[i].res}',
                          style: const TextStyle(fontSize: 13)),
                    ),
                  ),
                ),
                Align(
                  alignment: Alignment.bottomCenter,
                  child: Padding(
                    padding: const EdgeInsets.all(16),
                    child: Glass(
                      radius: 34,
                      blur: 24,
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 8),
                      child: Row(mainAxisSize: MainAxisSize.min, children: [
                        _action(Icons.download_rounded, 'Download', download),
                        _action(Icons.wallpaper_rounded, 'Set wallpaper',
                            chooseWallpaperTarget),
                      ]),
                    ),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ]),
    );
  }
}
