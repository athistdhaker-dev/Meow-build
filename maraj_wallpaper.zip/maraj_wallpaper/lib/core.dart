import 'dart:convert';
import 'dart:typed_data';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:gal/gal.dart';
import 'package:http/http.dart' as http;

// ------------------------------------------------------------ device target
/// Set at build time: --dart-define=TARGET=tv | mobile (default: auto-detect)
const kTarget = String.fromEnvironment('TARGET', defaultValue: 'auto');
const channel = MethodChannel('maraj/storage');

/// true on TV / Jio STB, false on phones & tablets.
bool isTv = true;
double get panelBlur => isTv ? 12 : 24;
double get smallBlur => isTv ? 0 : 16;

Future<void> detectTarget() async {
  if (kTarget == 'tv') {
    isTv = true;
  } else if (kTarget == 'mobile') {
    isTv = false;
  } else {
    try {
      isTv = (await channel.invokeMethod<bool>('isTv')) ?? true;
    } catch (_) {
      isTv = true;
    }
  }
}

/// Free external storage in percent (Jio rule: don't write if < 20%).
Future<double> freePercent() async {
  try {
    return (await channel.invokeMethod<double>('freePercent')) ?? 100;
  } catch (_) {
    return 100;
  }
}

Future<String> saveWall(String url) async {
  if (await freePercent() < 20) {
    throw 'storage low (under 20% free), free some space first';
  }
  if (!await Gal.hasAccess(toAlbum: true) &&
      !await Gal.requestAccess(toAlbum: true)) {
    throw 'storage permission denied';
  }
  final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 60));
  await Gal.putImageBytes(r.bodyBytes, album: 'Maraj Wallpaper');
  return 'Saved to Pictures/Maraj Wallpaper';
}

/// which: 1 = home screen, 2 = lock screen, 3 = both (phones only)
Future<bool> applyWallpaper(String url, int which) async {
  final r = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 60));
  final ok = await channel.invokeMethod<bool>('setWallpaper',
      {'bytes': Uint8List.fromList(r.bodyBytes), 'which': which});
  return ok ?? false;
}

// -------------------------------------------------------------------- data
class Wall {
  final String thumb, full, res;
  Wall(this.thumb, this.full, this.res);
}

const _hd = '1920x1080', _4k = '3840x2160';
// name: [search query, sorting, min resolution (landscape)]
const cats = <String, List<String>>{
  'Top': ['', 'toplist', _hd],
  'Latest': ['', 'date_added', _hd],
  'Random': ['', 'random', _hd],
  '4K': ['', 'toplist', _4k],
  'Nature': ['nature', 'toplist', _hd],
  'Mountains': ['mountains', 'toplist', _hd],
  'Ocean': ['ocean', 'toplist', _hd],
  'Sunset': ['sunset', 'toplist', _hd],
  'Space': ['space', 'toplist', _hd],
  'City': ['city', 'toplist', _hd],
  'Architecture': ['architecture', 'toplist', _hd],
  'Cars': ['cars', 'toplist', _hd],
  'Animals': ['animals', 'toplist', _hd],
  'Flowers': ['flowers', 'toplist', _hd],
  'Anime': ['anime', 'toplist', _hd],
  'Gaming': ['game', 'toplist', _hd],
  'Fantasy': ['fantasy', 'toplist', _hd],
  'Technology': ['technology', 'toplist', _hd],
  'Abstract': ['abstract', 'toplist', _hd],
  'Minimal': ['minimal', 'toplist', _hd],
  'Dark': ['dark', 'toplist', _hd],
};

String _flip(String m) {
  final p = m.split('x');
  return '${p[1]}x${p[0]}';
}

const kUserAgent = 'MarajWallpaper/1.5 (Android wallpaper app)';

Future<http.Response> _get(Uri u) async {
  final r = await http.get(u, headers: {
    'User-Agent': kUserAgent,
    'Accept': 'application/json'
  }).timeout(const Duration(seconds: 10));
  if (r.statusCode != 200) throw 'HTTP ${r.statusCode}';
  return r;
}

// ------------------------------------------------------ wallpaper providers
// Each provider returns a page of walls. If one is down (error / timeout /
// no results) the feed automatically tries the next one.

typedef FetchFn = Future<List<Wall>> Function(
    String q, String sort, String min, bool portrait, int page);

class Provider {
  final String name;
  final FetchFn fetch;
  const Provider(this.name, this.fetch);
}

class _NoResults implements Exception {
  @override
  String toString() => 'no results';
}

/// 1) Wallhaven - best choice & categories (free API, no key for SFW).
Future<List<Wall>> _wallhaven(
    String q, String sort, String min, bool portrait, int page) async {
  final u = Uri.https('wallhaven.cc', '/api/v1/search', {
    'q': q,
    'categories': '111',
    'purity': '100',
    'sorting': sort,
    'atleast': portrait ? _flip(min) : min,
    'ratios': portrait ? '9x16' : '16x9',
    'page': '$page',
  });
  return (jsonDecode((await _get(u)).body)['data'] as List)
      .map((e) => Wall(e['thumbs']['large'], e['path'], e['resolution']))
      .toList();
}

/// 2) Wikimedia Commons - Featured Pictures (open licences, supports search).
Future<List<Wall>> _wikimedia(
    String q, String sort, String min, bool portrait, int page) async {
  final big = min == _4k;
  final w = portrait ? (big ? 1920 : 1280) : (big ? 3840 : 1920);
  final u = Uri.https('commons.wikimedia.org', '/w/api.php', {
    'action': 'query',
    'format': 'json',
    'generator': 'search',
    'gsrsearch':
        'incategory:"Featured pictures on Wikimedia Commons" filetype:bitmap $q'
            .trim(),
    'gsrnamespace': '6',
    'gsrlimit': '30',
    'gsroffset': '${(page - 1) * 30}',
    if (sort == 'date_added') 'gsrsort': 'create_timestamp_desc',
    'prop': 'imageinfo',
    'iiprop': 'url|size',
    'iiurlwidth': '$w',
  });
  final j = jsonDecode((await _get(u)).body);
  final pages = ((j['query']?['pages'] as Map?)?.values.toList() ?? [])
    ..sort((a, b) =>
        ((a['index'] ?? 0) as int).compareTo((b['index'] ?? 0) as int));
  final out = <Wall>[];
  for (final p in pages) {
    final ii = (p['imageinfo'] as List?)?.first;
    if (ii == null) continue;
    final ow = ii['width'] as int, oh = ii['height'] as int;
    if (portrait ? oh <= ow : ow <= oh) continue; // keep matching orientation
    if ((portrait ? oh : ow) < (big ? 3000 : 1800)) continue; // HD+ only
    final full = (ii['thumburl'] ?? ii['url']) as String;
    out.add(Wall(full.replaceFirst('/${w}px-', '/500px-'), full, '${ow}x$oh'));
  }
  return out;
}

/// 3) Lorem Picsum - random HD photos (no categories / search).
Future<List<Wall>> _picsum(
    String q, String sort, String min, bool portrait, int page) async {
  final u = Uri.https(
      'picsum.photos', '/v2/list', {'page': '$page', 'limit': '30'});
  final fw = portrait ? 1080 : 1920, fh = portrait ? 1920 : 1080;
  final tw = portrait ? 270 : 480, th = portrait ? 480 : 270;
  return (jsonDecode((await _get(u)).body) as List)
      .map((e) => Wall('https://picsum.photos/id/${e['id']}/$tw/$th',
          'https://picsum.photos/id/${e['id']}/$fw/$fh', '${fw}x$fh'))
      .toList();
}

/// 4) Bing daily images - last resort (about 16 images, no categories).
Future<List<Wall>> _bing(
    String q, String sort, String min, bool portrait, int page) async {
  final u = Uri.https('www.bing.com', '/HPImageArchive.aspx', {
    'format': 'js',
    'idx': '${(page - 1) * 8}',
    'n': '8',
    'mkt': 'en-IN',
  });
  final list = (jsonDecode((await _get(u)).body)['images'] as List?) ?? [];
  final fullSize = portrait ? '1080x1920' : (min == _4k ? 'UHD' : '1920x1080');
  final thumbSize = portrait ? '1080x1920' : '800x480';
  return [
    for (final e in list)
      Wall('https://www.bing.com${e['urlbase']}_$thumbSize.jpg',
          'https://www.bing.com${e['urlbase']}_$fullSize.jpg',
          fullSize == 'UHD' ? '3840x2160' : fullSize),
  ];
}

const providers = <Provider>[
  Provider('Wallhaven', _wallhaven),
  Provider('Wikimedia Commons', _wikimedia),
  Provider('Lorem Picsum', _picsum),
  Provider('Bing Daily', _bing),
];

/// provider name -> time until which we skip it (it recently failed)
final _downUntil = <String, DateTime>{};

/// Shared paging/search logic for both the TV and the phone UI.
class WallFeed extends ChangeNotifier {
  String cat = 'Top', query = '';
  final items = <Wall>[];
  int page = 1, gen = 0, active = 0;
  bool loading = false, portrait = false, exhausted = false, _dead = false;
  String? error;
  String source = '';

  String get sourceLine => active > 0
      ? 'Source: $source  (backup - ${providers[0].name} unavailable)'
      : 'Source: $source';

  void _n() {
    if (!_dead) notifyListeners();
  }

  @override
  void dispose() {
    _dead = true;
    super.dispose();
  }

  void setCat(String k) {
    cat = k;
    query = '';
    load(reset: true);
  }

  void search(String q) {
    query = q.trim();
    load(reset: true);
  }

  /// User-triggered reload: forget which providers were marked as down.
  Future<void> refresh() {
    _downUntil.clear();
    return load(reset: true);
  }

  /// First page: try providers in order until one answers with results.
  Future<List<Wall>> _firstPage(List<String> c, int g) async {
    final errors = <String>[];
    for (var k = 0; k < providers.length; k++) {
      final p = providers[k];
      final until = _downUntil[p.name];
      if (until != null &&
          DateTime.now().isBefore(until) &&
          k < providers.length - 1) {
        errors.add('${p.name}: skipped');
        continue;
      }
      try {
        final r = await p
            .fetch(c[0], c[1], c[2], portrait, 1)
            .timeout(const Duration(seconds: 12));
        if (g != gen) return const [];
        if (r.isEmpty) throw _NoResults();
        _downUntil.remove(p.name);
        active = k;
        source = p.name;
        return r;
      } catch (e) {
        if (e is! _NoResults) {
          _downUntil[p.name] = DateTime.now().add(const Duration(seconds: 60));
        }
        errors.add('${p.name}: $e');
      }
    }
    throw errors.join('; ');
  }

  Future<void> load({bool reset = false}) async {
    if (loading && !reset) return;
    if (exhausted && !reset) return;
    if (reset) {
      items.clear();
      page = 1;
      gen++;
      exhausted = false;
    }
    final g = gen;
    loading = true;
    error = null;
    _n();
    try {
      final c = query.isNotEmpty ? [query, 'relevance', _hd] : cats[cat]!;
      List<Wall> r;
      if (page == 1) {
        r = await _firstPage(c, g);
      } else {
        // later pages stay on the provider that served page 1
        r = await providers[active].fetch(c[0], c[1], c[2], portrait, page);
        if (r.isEmpty) exhausted = true;
      }
      if (g != gen) return;
      page++;
      items.addAll(r);
    } catch (e) {
      if (g != gen) return;
      error = page == 1
          ? 'Could not load wallpapers from any source. Check your internet connection.'
          : 'Could not load more wallpapers.';
    }
    loading = false;
    _n();
  }
}

// ---------------------------------------------------------------- glass UI
/// Dark gradient with soft colour orbs - gives the glass something to refract.
class GlassBackdrop extends StatelessWidget {
  final Widget child;
  const GlassBackdrop({super.key, required this.child});
  Widget orb(Color c, double s) => Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
            shape: BoxShape.circle,
            gradient:
                RadialGradient(colors: [c.withAlpha(170), c.withAlpha(0)])),
      );
  @override
  Widget build(BuildContext context) => Stack(fit: StackFit.expand, children: [
        const DecoratedBox(
            decoration: BoxDecoration(
                gradient: LinearGradient(
                    begin: Alignment.topLeft,
                    end: Alignment.bottomRight,
                    colors: [Color(0xFF0A0A1C), Color(0xFF1A1040)]))),
        Positioned(top: -140, left: -100, child: orb(const Color(0xFF7B2FF7), 480)),
        Positioned(bottom: -180, right: -120, child: orb(const Color(0xFFEC5678), 520)),
        Positioned(top: 220, right: 120, child: orb(const Color(0xFF2FA8F7), 320)),
        child,
      ]);
}

/// Frosted "liquid glass" surface: blur + translucent gradient + specular rim.
class Glass extends StatelessWidget {
  final Widget child;
  final double radius, blur;
  final EdgeInsets padding;
  final bool focused, selected;
  const Glass({
    super.key,
    required this.child,
    this.radius = 20,
    this.blur = 20,
    this.padding = EdgeInsets.zero,
    this.focused = false,
    this.selected = false,
  });
  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    Widget box = Container(
      decoration: BoxDecoration(
        borderRadius: r,
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            Colors.white.withAlpha(selected ? 100 : 58),
            Colors.white.withAlpha(selected ? 44 : 14),
          ],
        ),
        border: Border.all(
            color: Colors.white.withAlpha(focused ? 240 : 72),
            width: focused ? 3 : 1.2),
      ),
      child: Stack(children: [
        Padding(padding: padding, child: child),
        Positioned(
          top: 0,
          left: radius * .6,
          right: radius * .6,
          height: 1.5,
          child: DecoratedBox(
            decoration: BoxDecoration(
              gradient: LinearGradient(colors: [
                Colors.white.withAlpha(0),
                Colors.white.withAlpha(190),
                Colors.white.withAlpha(0),
              ]),
            ),
          ),
        ),
      ]),
    );
    if (blur > 0) {
      box = BackdropFilter(
          filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur), child: box);
    }
    return ClipRRect(borderRadius: r, child: box);
  }
}

/// Pill button. Focusable (D-pad) or touch-only (focusable: false).
class GlassButton extends StatefulWidget {
  final String? label;
  final IconData? icon;
  final VoidCallback onTap;
  final bool selected, autofocus, focusable, expand, dense;
  final double blur;
  const GlassButton({
    super.key,
    required this.onTap,
    this.label,
    this.icon,
    this.selected = false,
    this.autofocus = false,
    this.focusable = true,
    this.expand = false,
    this.dense = false,
    this.blur = 0,
  });
  @override
  State<GlassButton> createState() => _GlassButtonState();
}

class _GlassButtonState extends State<GlassButton> {
  bool f = false;
  @override
  Widget build(BuildContext context) {
    final fs = widget.dense ? 15.0 : 18.0;
    final content = Glass(
      radius: 28,
      blur: widget.blur,
      selected: widget.selected,
      focused: f,
      padding: EdgeInsets.symmetric(
          horizontal: widget.label == null ? 12 : (widget.dense ? 16 : 20),
          vertical: widget.dense ? 8 : 12),
      child: Row(
        mainAxisSize: widget.expand ? MainAxisSize.max : MainAxisSize.min,
        children: [
          if (widget.icon != null) Icon(widget.icon, size: fs + 6),
          if (widget.icon != null && widget.label != null)
            const SizedBox(width: 10),
          if (widget.label != null)
            Text(widget.label!,
                style: TextStyle(fontSize: fs, fontWeight: FontWeight.w600)),
        ],
      ),
    );
    if (!widget.focusable) {
      return GestureDetector(onTap: widget.onTap, child: content);
    }
    return InkWell(
      onTap: widget.onTap,
      autofocus: widget.autofocus,
      onFocusChange: (v) => setState(() => f = v),
      borderRadius: BorderRadius.circular(28),
      focusColor: Colors.transparent,
      hoverColor: Colors.transparent,
      splashColor: Colors.transparent,
      highlightColor: Colors.transparent,
      child: content,
    );
  }
}
