import 'dart:async';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'core.dart';
import 'pages.dart';

// 10-foot UI for Jio STB / Android TV: side rail + big grid, D-pad only.

class TvHome extends StatefulWidget {
  const TvHome({super.key});
  @override
  State<TvHome> createState() => _TvHomeState();
}

class _TvHomeState extends State<TvHome> {
  final feed = WallFeed();
  final focusIdx = ValueNotifier<int>(0);

  @override
  void initState() {
    super.initState();
    feed.load(reset: true);
  }

  @override
  void dispose() {
    feed.dispose();
    focusIdx.dispose();
    super.dispose();
  }

  /// Ambient background: the focused wallpaper's thumbnail, stretched
  /// (so it is naturally soft) and dimmed. Cheap - no blur filter needed.
  Widget ambient() => ListenableBuilder(
        listenable: Listenable.merge([feed, focusIdx]),
        builder: (_, __) {
          final it = feed.items;
          if (it.isEmpty) return const SizedBox.shrink();
          final w = it[focusIdx.value.clamp(0, it.length - 1)];
          return Stack(fit: StackFit.expand, children: [
            AnimatedSwitcher(
              duration: const Duration(milliseconds: 600),
              child: Image.network(w.thumb,
                  key: ValueKey(w.thumb),
                  fit: BoxFit.cover,
                  cacheWidth: 320,
                  errorBuilder: (_, __, ___) => const SizedBox.shrink()),
            ),
            const ColoredBox(color: Color(0xB30A0A1C)),
          ]);
        },
      );

  @override
  Widget build(BuildContext context) => Scaffold(
        body: Stack(fit: StackFit.expand, children: [
          ambient(),
          // TV safe area (overscan): 48 / 27 px margins
          Padding(
            padding: const EdgeInsets.fromLTRB(48, 27, 48, 0),
            child: ListenableBuilder(
              listenable: feed,
              builder: (_, __) => Row(children: [
                SizedBox(width: 300, child: _rail()),
                const SizedBox(width: 32),
                Expanded(child: _content()),
              ]),
            ),
          ),
        ]),
      );

  Widget _rail() => Glass(
        radius: 32,
        blur: panelBlur,
        padding: const EdgeInsets.fromLTRB(16, 22, 16, 16),
        child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
          Row(children: [
            ClipRRect(
                borderRadius: BorderRadius.circular(12),
                child: Image.asset('assets/logo.png', width: 52, height: 52)),
            const SizedBox(width: 12),
            const Expanded(
              child: Text('Maraj\nWallpaper',
                  style: TextStyle(
                      fontSize: 24, fontWeight: FontWeight.bold, height: 1.1)),
            ),
          ]),
          const SizedBox(height: 18),
          Expanded(
            child: ListView(children: [
              for (final k in cats.keys)
                TvNavItem(
                  label: k,
                  selected: feed.query.isEmpty && feed.cat == k,
                  autofocus: k == 'Top',
                  onTap: () {
                    focusIdx.value = 0;
                    feed.setCat(k);
                  },
                ),
            ]),
          ),
          const SizedBox(height: 8),
          TvNavItem(
            label: 'About & Legal',
            icon: Icons.info_outline,
            onTap: () => Navigator.push(context,
                MaterialPageRoute(builder: (_) => const InfoScreen())),
          ),
        ]),
      );

  Widget _content() => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Text(feed.query.isNotEmpty ? feed.query : feed.cat,
            style: const TextStyle(fontSize: 38, fontWeight: FontWeight.bold)),
        if (feed.source.isNotEmpty)
          Text(feed.sourceLine,
              style: const TextStyle(fontSize: 18, color: Colors.white70)),
        const SizedBox(height: 12),
        if (feed.error != null)
          Padding(
            padding: const EdgeInsets.only(bottom: 10),
            child: Row(children: [
              Expanded(
                  child: Text(feed.error!,
                      style: const TextStyle(
                          color: Colors.redAccent, fontSize: 20))),
              GlassButton(
                  label: 'Retry',
                  icon: Icons.refresh,
                  onTap: () => feed.refresh()),
            ]),
          ),
        Expanded(
          child: feed.items.isEmpty && feed.loading
              ? const Center(child: CircularProgressIndicator())
              : GridView.builder(
                  padding: const EdgeInsets.only(top: 6, bottom: 27),
                  gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                      crossAxisCount: 3,
                      crossAxisSpacing: 20,
                      mainAxisSpacing: 20,
                      childAspectRatio: 16 / 9),
                  itemCount: feed.items.length,
                  itemBuilder: (_, i) {
                    if (i >= feed.items.length - 4) Future.microtask(feed.load);
                    return TvTile(
                      wall: feed.items[i],
                      onFocus: () => focusIdx.value = i,
                      onTap: () => Navigator.push(
                          context,
                          MaterialPageRoute(
                              builder: (_) =>
                                  TvViewer(items: feed.items, start: i))),
                    );
                  },
                ),
        ),
        if (feed.loading && feed.items.isNotEmpty)
          const LinearProgressIndicator(minHeight: 4),
      ]);
}

class TvNavItem extends StatefulWidget {
  final String label;
  final IconData? icon;
  final bool selected, autofocus;
  final VoidCallback onTap;
  const TvNavItem({
    super.key,
    required this.label,
    required this.onTap,
    this.icon,
    this.selected = false,
    this.autofocus = false,
  });
  @override
  State<TvNavItem> createState() => _TvNavItemState();
}

class _TvNavItemState extends State<TvNavItem> {
  bool f = false;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 3),
        child: InkWell(
          onTap: widget.onTap,
          autofocus: widget.autofocus,
          onFocusChange: (v) => setState(() => f = v),
          borderRadius: BorderRadius.circular(18),
          focusColor: Colors.transparent,
          hoverColor: Colors.transparent,
          splashColor: Colors.transparent,
          highlightColor: Colors.transparent,
          child: AnimatedContainer(
            duration: const Duration(milliseconds: 120),
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 13),
            decoration: BoxDecoration(
              borderRadius: BorderRadius.circular(18),
              color: f
                  ? Colors.white.withAlpha(75)
                  : widget.selected
                      ? Colors.white.withAlpha(36)
                      : Colors.transparent,
              border: Border.all(
                  color: f ? Colors.white : Colors.transparent, width: 2.5),
            ),
            child: Row(children: [
              Icon(
                  widget.icon ??
                      (widget.selected ? Icons.circle : Icons.circle_outlined),
                  size: widget.icon == null ? 12 : 24),
              const SizedBox(width: 12),
              Expanded(
                child: Text(widget.label,
                    overflow: TextOverflow.ellipsis,
                    style: TextStyle(
                        fontSize: 23,
                        fontWeight:
                            widget.selected ? FontWeight.w700 : FontWeight.w500)),
              ),
            ]),
          ),
        ),
      );
}

class TvTile extends StatefulWidget {
  final Wall wall;
  final VoidCallback onTap, onFocus;
  const TvTile(
      {super.key,
      required this.wall,
      required this.onTap,
      required this.onFocus});
  @override
  State<TvTile> createState() => _TvTileState();
}

class _TvTileState extends State<TvTile> {
  bool focused = false;
  @override
  Widget build(BuildContext context) => InkWell(
        onTap: widget.onTap,
        onFocusChange: (f) {
          setState(() => focused = f);
          if (f) widget.onFocus();
        },
        borderRadius: BorderRadius.circular(20),
        focusColor: Colors.transparent,
        hoverColor: Colors.transparent,
        splashColor: Colors.transparent,
        highlightColor: Colors.transparent,
        // fixed size & position: only the glass rim + glow change on focus
        child: DecoratedBox(
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(20),
            boxShadow: focused
                ? [BoxShadow(color: Colors.white.withAlpha(90), blurRadius: 26)]
                : const [],
          ),
          child: Glass(
            radius: 20,
            blur: 0,
            focused: focused,
            padding: const EdgeInsets.all(4),
            child: ClipRRect(
              borderRadius: BorderRadius.circular(16),
              child: Stack(fit: StackFit.expand, children: [
                Image.network(widget.wall.thumb,
                    cacheWidth: 520,
                    fit: BoxFit.cover,
                    errorBuilder: (_, __, ___) =>
                        const ColoredBox(color: Colors.black26)),
                Positioned(
                  left: 10,
                  bottom: 10,
                  child: Glass(
                    radius: 10,
                    blur: 0,
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    child: Text(widget.wall.res,
                        style: const TextStyle(fontSize: 15)),
                  ),
                ),
              ]),
            ),
          ),
        ),
      );
}

// ------------------------------------------------------------ full screen

class TvViewer extends StatefulWidget {
  final List<Wall> items;
  final int start;
  const TvViewer({super.key, required this.items, required this.start});
  @override
  State<TvViewer> createState() => _TvViewerState();
}

class _TvViewerState extends State<TvViewer> {
  late int i = widget.start;
  Timer? slide, hide;
  bool auto = false, busy = false, showUi = true;
  String status = '';

  @override
  void initState() {
    super.initState();
    kick();
  }

  @override
  void dispose() {
    slide?.cancel();
    hide?.cancel();
    super.dispose();
  }

  /// Show the overlay and auto-hide it after 4 s without a key press.
  void kick() {
    hide?.cancel();
    if (!showUi) setState(() => showUi = true);
    hide = Timer(const Duration(seconds: 4), () {
      if (mounted) setState(() => showUi = false);
    });
  }

  void go(int d) {
    final len = widget.items.length;
    setState(() {
      i = (i + d + len) % len;
      status = '';
    });
    precacheImage(
        ResizeImage(NetworkImage(widget.items[(i + 1) % len].full), width: 1920),
        context);
  }

  void toggleSlide() {
    setState(() => auto = !auto);
    slide?.cancel();
    if (auto) slide = Timer.periodic(const Duration(seconds: 10), (_) => go(1));
  }

  Future<void> download() async {
    if (busy) return;
    busy = true;
    setState(() => status = 'Downloading...');
    try {
      final m = await saveWall(widget.items[i].full);
      if (mounted) setState(() => status = m);
    } catch (e) {
      if (mounted) setState(() => status = 'Download failed: $e');
    }
    busy = false;
  }

  Widget _hint(String t) => Glass(
        radius: 14,
        blur: 0,
        padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 7),
        child: Text(t, style: const TextStyle(fontSize: 19)),
      );

  @override
  Widget build(BuildContext context) {
    final w = widget.items[i];
    return Scaffold(
      backgroundColor: Colors.black,
      body: Focus(
        autofocus: true,
        onKeyEvent: (_, e) {
          if (e is! KeyDownEvent) return KeyEventResult.ignored;
          final k = e.logicalKey;
          if (k == LogicalKeyboardKey.goBack ||
              k == LogicalKeyboardKey.escape) {
            return KeyEventResult.ignored;
          }
          kick();
          if (k == LogicalKeyboardKey.arrowRight) {
            go(1);
          } else if (k == LogicalKeyboardKey.arrowLeft) {
            go(-1);
          } else if (k == LogicalKeyboardKey.arrowUp) {
            toggleSlide();
          } else if (k == LogicalKeyboardKey.select ||
              k == LogicalKeyboardKey.enter) {
            download();
          }
          return KeyEventResult.handled;
        },
        child: Stack(fit: StackFit.expand, children: [
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 500),
            child: Image.network(w.full,
                key: ValueKey(w.full),
                cacheWidth: 1920,
                fit: BoxFit.cover,
                loadingBuilder: (_, c, p) => p == null
                    ? c
                    : const Center(child: CircularProgressIndicator()),
                errorBuilder: (_, __, ___) =>
                    const Center(child: Text('Could not load image'))),
          ),
          AnimatedOpacity(
            opacity: showUi ? 1 : 0,
            duration: const Duration(milliseconds: 300),
            child: Align(
              alignment: Alignment.bottomCenter,
              child: Padding(
                padding: const EdgeInsets.fromLTRB(48, 0, 48, 27),
                child: Glass(
                  radius: 30,
                  blur: panelBlur,
                  padding:
                      const EdgeInsets.symmetric(horizontal: 24, vertical: 16),
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Text(
                        '${i + 1} / ${widget.items.length}   •   ${w.res}'
                        '${status.isEmpty ? "" : "   •   $status"}',
                        style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w600)),
                    const SizedBox(height: 12),
                    Wrap(spacing: 14, runSpacing: 8, children: [
                      _hint('◀  ▶   Change'),
                      _hint('OK   Download'),
                      _hint('▲   Slideshow ${auto ? "ON" : "OFF"}'),
                      _hint('Back   Close'),
                    ]),
                  ]),
                ),
              ),
            ),
          ),
        ]),
      ),
    );
  }
}
