import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'core.dart';
import 'legal.dart';

class InfoScreen extends StatelessWidget {
  const InfoScreen({super.key});
  @override
  Widget build(BuildContext context) {
    void open(String t, String b) => Navigator.push(context,
        MaterialPageRoute(builder: (_) => DocPage(title: t, body: b)));
    return Scaffold(
      appBar: AppBar(title: const Text('About & Legal')),
      body: SafeArea(
        child: Center(
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 720),
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Glass(
                radius: 30,
                blur: panelBlur,
                padding: const EdgeInsets.all(18),
                child: SingleChildScrollView(
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    GlassButton(
                        expand: true,
                        autofocus: isTv,
                        icon: Icons.privacy_tip_outlined,
                        label: 'Privacy Policy',
                        onTap: () => open('Privacy Policy', kPrivacy)),
                    const SizedBox(height: 12),
                    GlassButton(
                        expand: true,
                        icon: Icons.description_outlined,
                        label: 'Terms & Conditions',
                        onTap: () => open('Terms & Conditions', kTerms)),
                    const SizedBox(height: 12),
                    GlassButton(
                        expand: true,
                        icon: Icons.code,
                        label: 'Open-source licenses',
                        onTap: () => showLicensePage(
                            context: context,
                            applicationName: kAppName,
                            applicationVersion: kVersion)),
                    const SizedBox(height: 18),
                    const Text(
                        '$kAppName v$kVersion\nSources: Wallhaven, Wikimedia Commons, Lorem Picsum, Bing\n'
                        'Privacy Policy & Terms last updated $kLastUpdated',
                        textAlign: TextAlign.center),
                  ]),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}

class DocPage extends StatefulWidget {
  final String title, body;
  const DocPage({super.key, required this.title, required this.body});
  @override
  State<DocPage> createState() => _DocPageState();
}

class _DocPageState extends State<DocPage> {
  final sc = ScrollController();
  @override
  void dispose() {
    sc.dispose();
    super.dispose();
  }

  void scroll(double d) => sc.animateTo(
      (sc.offset + d).clamp(0.0, sc.position.maxScrollExtent),
      duration: const Duration(milliseconds: 150),
      curve: Curves.easeOut);

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(title: Text(widget.title)),
        body: SafeArea(
          child: Focus(
            autofocus: true,
            onKeyEvent: (_, e) {
              if (e is! KeyDownEvent) return KeyEventResult.ignored;
              if (e.logicalKey == LogicalKeyboardKey.arrowDown) {
                scroll(300);
              } else if (e.logicalKey == LogicalKeyboardKey.arrowUp) {
                scroll(-300);
              } else {
                return KeyEventResult.ignored;
              }
              return KeyEventResult.handled;
            },
            child: Padding(
              padding: const EdgeInsets.fromLTRB(20, 4, 20, 20),
              child: Glass(
                radius: 28,
                blur: panelBlur,
                child: SingleChildScrollView(
                  controller: sc,
                  padding: const EdgeInsets.all(24),
                  child: Text(widget.body,
                      style: TextStyle(fontSize: isTv ? 22 : 17, height: 1.5)),
                ),
              ),
            ),
          ),
        ),
      );
}
