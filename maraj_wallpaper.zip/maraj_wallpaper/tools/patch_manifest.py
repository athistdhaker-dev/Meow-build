import re
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
s = s.replace("<application", """<uses-permission android:name="android.permission.INTERNET"/>
    <uses-feature android:name="android.software.leanback" android:required="false"/>
    <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
    <application android:banner="@mipmap/ic_launcher" """, 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Maraj Wallpaper"', s, 1)
s = s.replace('<category android:name="android.intent.category.LAUNCHER"/>',
 '<category android:name="android.intent.category.LAUNCHER"/>\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>', 1)
open(p, "w", encoding="utf-8").write(s)
print("manifest patched")
