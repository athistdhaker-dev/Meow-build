"""Usage: python3 tools/patch_manifest.py tv|mobile   (run after `flutter create`)
Safe to run repeatedly: it always starts from the original generated manifest."""
import re, shutil, sys, pathlib

target = sys.argv[1] if len(sys.argv) > 1 else "tv"
assert target in ("tv", "mobile"), "target must be tv or mobile"

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
orig = p.with_name("AndroidManifest.xml.orig")
if orig.exists():
    shutil.copy(orig, p)
else:
    shutil.copy(p, orig)

s = p.read_text(encoding="utf-8")
perms = [
    '<uses-permission android:name="android.permission.INTERNET"/>',
    '<uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>',
]
app_attr = ""
if target == "tv":
    perms += [
        '<uses-feature android:name="android.software.leanback" android:required="false"/>',
        '<uses-feature android:name="android.hardware.touchscreen" android:required="false"/>',
    ]
    app_attr = ' android:banner="@drawable/banner"'
else:
    perms += ['<uses-permission android:name="android.permission.SET_WALLPAPER"/>']

s = s.replace("<application", "\n    ".join(perms) + "\n    <application" + app_attr, 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Maraj Wallpaper"', s, 1)
if target == "tv":
    s = s.replace(
        '<category android:name="android.intent.category.LAUNCHER"/>',
        '<category android:name="android.intent.category.LAUNCHER"/>\n'
        '                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>', 1)
p.write_text(s, encoding="utf-8")

shutil.copytree("assets/android_icons", "android/app/src/main/res", dirs_exist_ok=True)

# Native helpers: free space, TV detection, set wallpaper
for f in pathlib.Path("android/app/src/main").rglob("MainActivity.kt"):
    pkg = re.search(r"^package\s+([\w.]+)", f.read_text(), re.M).group(1)
    f.write_text(f"""package {pkg}

import android.app.UiModeManager
import android.app.WallpaperManager
import android.content.Context
import android.content.res.Configuration
import android.graphics.BitmapFactory
import android.os.Environment
import android.os.StatFs
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "maraj/storage")
            .setMethodCallHandler {{ call, result ->
                when (call.method) {{
                    "freePercent" -> try {{
                        val st = StatFs(Environment.getExternalStorageDirectory().path)
                        result.success(st.availableBytes * 100.0 / st.totalBytes)
                    }} catch (e: Exception) {{ result.success(100.0) }}
                    "lowEnd" -> {{
                        val am = getSystemService(Context.ACTIVITY_SERVICE) as android.app.ActivityManager
                        result.success(am.isLowRamDevice || am.memoryClass < 192)
                    }}
                    "isTv" -> {{
                        val um = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
                        result.success(um.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION)
                    }}
                    "setWallpaper" -> {{
                        val bytes = call.argument<ByteArray>("bytes")
                        val which = call.argument<Int>("which") ?: 3
                        Thread {{
                            var ok = false
                            try {{
                                val b = bytes!!
                                val o = BitmapFactory.Options().apply {{ inJustDecodeBounds = true }}
                                BitmapFactory.decodeByteArray(b, 0, b.size, o)
                                var sample = 1
                                while (maxOf(o.outWidth, o.outHeight) / sample > 3000) sample *= 2
                                val o2 = BitmapFactory.Options().apply {{ inSampleSize = sample }}
                                val bmp = BitmapFactory.decodeByteArray(b, 0, b.size, o2)
                                val wm = WallpaperManager.getInstance(this)
                                val flags = when (which) {{
                                    1 -> WallpaperManager.FLAG_SYSTEM
                                    2 -> WallpaperManager.FLAG_LOCK
                                    else -> WallpaperManager.FLAG_SYSTEM or WallpaperManager.FLAG_LOCK
                                }}
                                wm.setBitmap(bmp, null, true, flags)
                                ok = true
                            }} catch (e: Exception) {{ ok = false }}
                            runOnUiThread {{ result.success(ok) }}
                        }}.start()
                    }}
                    else -> result.notImplemented()
                }}
            }}
    }}
}}
""")
print(f"patched for {target}")
