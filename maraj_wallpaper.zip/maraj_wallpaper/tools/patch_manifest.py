import re, shutil, pathlib
p = "android/app/src/main/AndroidManifest.xml"
s = open(p, encoding="utf-8").read()
s = s.replace("<application", """<uses-permission android:name="android.permission.INTERNET"/>
    <uses-permission android:name="android.permission.WRITE_EXTERNAL_STORAGE" android:maxSdkVersion="28"/>
    <uses-feature android:name="android.software.leanback" android:required="false"/>
    <uses-feature android:name="android.hardware.touchscreen" android:required="false"/>
    <application android:banner="@drawable/banner" """, 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Maraj Wallpaper"', s, 1)
s = s.replace('<category android:name="android.intent.category.LAUNCHER"/>',
 '<category android:name="android.intent.category.LAUNCHER"/>\n                <category android:name="android.intent.category.LEANBACK_LAUNCHER"/>', 1)
open(p, "w", encoding="utf-8").write(s)
shutil.copytree("assets/android_icons", "android/app/src/main/res", dirs_exist_ok=True)

# Native free-space check (Jio rule: don't store data when free space < 20%)
for f in pathlib.Path("android/app/src/main").rglob("MainActivity.kt"):
    pkg = re.search(r"^package\s+([\w.]+)", f.read_text(), re.M).group(1)
    f.write_text(f"""package {pkg}

import android.os.Environment
import android.os.StatFs
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity : FlutterActivity() {{
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {{
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, "maraj/storage")
            .setMethodCallHandler {{ call, result ->
                if (call.method == "freePercent") {{
                    try {{
                        val st = StatFs(Environment.getExternalStorageDirectory().path)
                        result.success(st.availableBytes * 100.0 / st.totalBytes)
                    }} catch (e: Exception) {{ result.success(100.0) }}
                }} else result.notImplemented()
            }}
    }}
}}
""")
print("manifest, icons, MainActivity patched")
