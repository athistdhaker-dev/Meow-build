# JioStore STB submission - Maraj Wallpaper

## App info (limits from Jio guideline)
- **App name** (3-24 chars): Maraj Wallpaper
- **Keywords** (5-15): wallpaper, hd wallpaper, 4k wallpaper, background, slideshow, nature, space, anime, cars, tv wallpaper
- **Short description** (<=100): Browse HD & 4K wallpapers on your TV, run a slideshow and save your favourites.
- **Long description** (200-2000):
  Maraj Wallpaper brings thousands of high-quality HD and 4K wallpapers to your TV. Pick a category - Nature, Mountains, Ocean, Sunset, Space, City, Architecture, Cars, Animals, Flowers, Anime, Gaming, Fantasy, Technology, Abstract, Minimal or Dark - and browse with your remote. Open any wallpaper full screen, move between images with left/right, start an automatic slideshow with Up, and press OK to save a wallpaper to your device. Designed for 16:9 TV screens, works with the Jio remote (D-pad only), no sign-in needed and no ads. Wallpapers come from Wallhaven, with Wikimedia Commons, Lorem Picsum and Bing as automatic backup sources if one service is down. Privacy Policy, Terms and open-source licenses are available inside the app under "About & Legal".
- **Category**: Personalization / Lifestyle (pick the closest in the portal)
- **Age rating**: 12 (suggested; wallpapers come from a third party with a safe-for-work filter)
- **Support email / Publisher name**: fill in (mandatory)
- **Privacy Policy & T&C links**: mandatory - edit `lib/legal.dart` placeholders (publisher, grievance officer name, mobile, address, email) and also host the same text online.

## Assets (store_assets/)
App icon 320x180, promo 1920x1080, carousel 1920x720 (content inside core area), recommendation icon 360x442 are generated.
**Still needed by you:** 5 real screenshots 1920x1080 (take them on the Jio-style emulator: Android TV 1080p, API 28, no Play Store) and an optional promo video (.mp4, max 50 MB).

## Self-certification (honest status)
| Item | Status |
|---|---|
| CPU < 50% foreground | **Measure** on device (`adb shell top`) |
| Responsiveness < 5 s | **Measure** |
| Minimum permissions | Yes: INTERNET, storage only on Android <=9 for saving |
| Security / encrypted transmission | Yes: HTTPS only, no sensitive data stored |
| 24 h stability (Monkey) | **Not done.** `adb shell monkey -p com.maraj.maraj_wallpaper --throttle 300 -v 500000` |
| GMS dependency | No |
| Android M (API 23) compatible | **Check**: Flutter's default minSdk may be 24 |
| Leanback | Partly: leanback launcher + banner + D-pad UI, built with Flutter (not Leanback framework) |
| Voice search (local/global) | No |
| Native libs | Only Flutter engine libs (libflutter.so, libapp.so), built with Flutter's NDK toolchain |
| Static analysis | CI runs `flutter analyze` |
| Pro-guard | R8 + Dart `--obfuscate` in CI build |
| Log level | No logging in release |
| Data storage / 20% free rule | Yes: checked before every download |
| Accessories | None (remote only) |
| Boot-up impact | None (no boot receiver/service) |
| Security audit | **Not done** |
| Privacy policy / T&C / Licenses screens | Yes (About & Legal) - fill placeholders |
| RAM / ROM | **Measure**: `adb shell dumpsys meminfo com.maraj.maraj_wallpaper`; ROM = APK size |
| Published on Google Play | No |
| Hidden Google APIs / third-party, GMS, ad, payment SDKs | None |
| Custom keyboard | No |
