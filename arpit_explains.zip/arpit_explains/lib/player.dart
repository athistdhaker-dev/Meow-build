import 'package:flutter/material.dart';
import 'package:youtube_player_iframe/youtube_player_iframe.dart';

import 'config.dart';
import 'glass.dart';
import 'store.dart';
import 'widgets.dart';
import 'yt.dart';

/// Video page: official YouTube player on top, details and more videos below.
class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key, required this.video});
  final Video video;
  @override
  State<PlayerPage> createState() => _PlayerPageState();
}

class _PlayerPageState extends State<PlayerPage> {
  late final YoutubePlayerController _c;
  late Video _v;
  final ScrollController _sc = ScrollController();
  bool _expanded = false;

  @override
  void initState() {
    super.initState();
    _v = widget.video;
    _c = YoutubePlayerController.fromVideoId(
      videoId: _v.id,
      autoPlay: true,
      params: const YoutubePlayerParams(
        showFullscreenButton: true,
        strictRelatedVideos: true,
      ),
    );
  }

  @override
  void dispose() {
    _c.close();
    _sc.dispose();
    super.dispose();
  }

  void _play(Video v) {
    setState(() {
      _v = v;
      _expanded = false;
    });
    _c.loadVideoById(videoId: v.id);
    if (_sc.hasClients) {
      _sc.animateTo(0, duration: const Duration(milliseconds: 300), curve: Curves.easeOut);
    }
  }

  @override
  Widget build(BuildContext context) {
    final more = AppData.i.videos.where((x) => x.id != _v.id).take(20).toList();
    return YoutubePlayerScaffold(
      controller: _c,
      aspectRatio: 16 / 9,
      builder: (context, player) => Scaffold(
        appBar: AppBar(
          backgroundColor: Colors.transparent,
          elevation: 0,
          scrolledUnderElevation: 0,
          title: const Text(kChannelName),
        ),
        body: SafeArea(
          child: ListView(
            controller: _sc,
            padding: const EdgeInsets.fromLTRB(14, 0, 14, 24),
            children: <Widget>[
              ClipRRect(borderRadius: BorderRadius.circular(20), child: player),
              const SizedBox(height: 14),
              Text(_v.title,
                  style: const TextStyle(
                      fontSize: 20, height: 1.3, fontWeight: FontWeight.w800, color: Pal.text)),
              const SizedBox(height: 6),
              Text(viewsLine(_v), style: const TextStyle(fontSize: 13.5, color: Pal.dim)),
              const SizedBox(height: 14),
              Row(
                children: <Widget>[
                  const SubscribeButton(),
                  const SizedBox(width: 10),
                  GlassTap(
                    radius: 26,
                    focusScale: 1.0,
                    padding: const EdgeInsets.all(12),
                    onTap: () => copyText(context, _v.url, 'Video link copied'),
                    child: const Icon(Icons.share_rounded, size: 22, color: Pal.text),
                  ),
                  const SizedBox(width: 10),
                  GlassTap(
                    radius: 26,
                    focusScale: 1.0,
                    padding: const EdgeInsets.all(12),
                    onTap: () => openUrl(context, _v.url),
                    child: const Icon(Icons.open_in_new_rounded, size: 22, color: Pal.text),
                  ),
                ],
              ),
              if (_v.description.trim().isNotEmpty) ...<Widget>[
                const SizedBox(height: 14),
                GlassTap(
                  radius: 22,
                  focusScale: 1.0,
                  padding: const EdgeInsets.all(14),
                  onTap: () => setState(() => _expanded = !_expanded),
                  child: SizedBox(
                    width: double.infinity,
                    child: Text(_v.description.trim(),
                        maxLines: _expanded ? null : 3,
                        overflow: _expanded ? TextOverflow.visible : TextOverflow.ellipsis,
                        style: const TextStyle(fontSize: 14, height: 1.45, color: Pal.dim)),
                  ),
                ),
              ],
              if (more.isNotEmpty) const SectionTitle('More videos'),
              for (final m in more)
                Padding(
                  padding: const EdgeInsets.only(bottom: 10),
                  child: GlassTap(
                    radius: 20,
                    focusScale: 1.0,
                    padding: const EdgeInsets.all(8),
                    onTap: () => _play(m),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: <Widget>[
                        SizedBox(width: 150, child: VideoThumb(m.thumb, radius: 12)),
                        const SizedBox(width: 12),
                        Expanded(
                          child: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: <Widget>[
                              Text(m.title,
                                  maxLines: 3,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(
                                      fontSize: 14,
                                      height: 1.25,
                                      fontWeight: FontWeight.w600,
                                      color: Pal.text)),
                              const SizedBox(height: 4),
                              Text(viewsLine(m),
                                  maxLines: 1,
                                  overflow: TextOverflow.ellipsis,
                                  style: const TextStyle(fontSize: 12, color: Pal.dim)),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}
