// Data layer: channel feed (RSS, no key needed) or YouTube Data API (optional key).
import 'dart:convert';
import 'package:http/http.dart' as http;
import 'config.dart';

class Video {
  const Video({
    required this.id,
    required this.title,
    required this.published,
    this.description = '',
    this.views = 0,
    this.seconds,
  });
  final String id, title, description;
  final DateTime published;
  final int views;
  final int? seconds;

  String get thumb => 'https://i.ytimg.com/vi/$id/hqdefault.jpg';
  String get url => 'https://www.youtube.com/watch?v=$id';
  bool get isShort => seconds != null && seconds! <= 60;
  String get durationText => seconds == null ? '' : formatDuration(seconds!);
}

class ChannelInfo {
  const ChannelInfo({
    required this.name,
    required this.handle,
    required this.description,
    this.avatarUrl,
    this.bannerUrl,
    this.subscribers,
  });
  final String name, handle, description;
  final String? avatarUrl, bannerUrl;
  final int? subscribers;
}

class RemoteConfig {
  const RemoteConfig({this.socials = const <SocialLink>[], this.announcement = ''});
  final List<SocialLink> socials;
  final String announcement;
}

// ----------------------------------------------------------------- helpers
String unescapeXml(String s) => s
    .replaceAll('&lt;', '<')
    .replaceAll('&gt;', '>')
    .replaceAll('&quot;', '"')
    .replaceAll('&apos;', "'")
    .replaceAll('&#39;', "'")
    .replaceAllMapped(
        RegExp(r'&#(\d+);'), (m) => String.fromCharCode(int.parse(m.group(1)!)))
    .replaceAll('&amp;', '&');

List<Video> parseFeed(String xml) {
  final out = <Video>[];
  for (final m in RegExp(r'<entry>([\s\S]*?)</entry>').allMatches(xml)) {
    final e = m.group(1) ?? '';
    final id = RegExp(r'<yt:videoId>([^<]+)</yt:videoId>').firstMatch(e)?.group(1);
    final title = RegExp(r'<title>([\s\S]*?)</title>').firstMatch(e)?.group(1);
    final pub = RegExp(r'<published>([^<]+)</published>').firstMatch(e)?.group(1);
    if (id == null || title == null) continue;
    final desc = RegExp(r'<media:description>([\s\S]*?)</media:description>')
            .firstMatch(e)
            ?.group(1) ??
        '';
    final views = int.tryParse(
            RegExp(r'<media:statistics views="(\d+)"').firstMatch(e)?.group(1) ?? '') ??
        0;
    out.add(Video(
      id: id,
      title: unescapeXml(title),
      published: DateTime.tryParse(pub ?? '') ?? DateTime.now(),
      description: unescapeXml(desc),
      views: views,
    ));
  }
  return out;
}

int parseIsoDuration(String iso) {
  final m = RegExp(r'PT(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?').firstMatch(iso);
  if (m == null) return 0;
  int g(int i) => int.tryParse(m.group(i) ?? '') ?? 0;
  return g(1) * 3600 + g(2) * 60 + g(3);
}

String formatDuration(int s) {
  final h = s ~/ 3600;
  final m = (s % 3600) ~/ 60;
  final ss = (s % 60).toString().padLeft(2, '0');
  if (h > 0) return '$h:${m.toString().padLeft(2, '0')}:$ss';
  return '$m:$ss';
}

String compactNumber(int n) {
  String f(double v, String suffix) {
    final t = v.toStringAsFixed(1);
    return '${t.endsWith('.0') ? t.substring(0, t.length - 2) : t}$suffix';
  }

  if (n >= 1000000000) return f(n / 1e9, 'B');
  if (n >= 1000000) return f(n / 1e6, 'M');
  if (n >= 1000) return f(n / 1e3, 'K');
  return '$n';
}

String timeAgo(DateTime d, {DateTime? now}) {
  final diff = (now ?? DateTime.now()).difference(d);
  if (diff.inMinutes < 1) return 'Just now';
  if (diff.inMinutes < 60) return '${diff.inMinutes} min ago';
  if (diff.inHours < 24) return '${diff.inHours} hr ago';
  final days = diff.inDays;
  if (days == 1) return 'Yesterday';
  if (days < 7) return '$days days ago';
  if (days < 30) {
    final w = days ~/ 7;
    return w == 1 ? '1 week ago' : '$w weeks ago';
  }
  if (days < 365) {
    final mo = days ~/ 30;
    return mo == 1 ? '1 month ago' : '$mo months ago';
  }
  final y = days ~/ 365;
  return y == 1 ? '1 year ago' : '$y years ago';
}

RemoteConfig parseRemoteConfig(String body) {
  final j = jsonDecode(body) as Map<String, dynamic>;
  final socials = <SocialLink>[];
  for (final raw in (j['socials'] as List<dynamic>? ?? <dynamic>[])) {
    final s = raw as Map<String, dynamic>;
    final url = (s['url'] as String?) ?? '';
    if (url.isEmpty) continue;
    final hex = ((s['color'] as String?) ?? '#7B2FF7').replaceFirst('#', '');
    final c = int.tryParse(hex, radix: 16) ?? 0x7B2FF7;
    final name = (s['name'] as String?) ?? 'Link';
    socials.add(SocialLink(
      name,
      (s['badge'] as String?) ?? (name.isEmpty ? '?' : name.substring(0, 1)),
      url,
      0xFF000000 | c,
      subtitle: (s['subtitle'] as String?) ?? '',
    ));
  }
  return RemoteConfig(
      socials: socials, announcement: (j['announcement'] as String?) ?? '');
}

// -------------------------------------------------------------- repository
class YtRepo {
  YtRepo({http.Client? client}) : _c = client ?? http.Client();
  final http.Client _c;

  static const _headers = <String, String>{
    'User-Agent':
        'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0 Mobile Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
  };

  Future<String> _get(String url) async {
    final r = await _c
        .get(Uri.parse(url), headers: _headers)
        .timeout(const Duration(seconds: 20));
    if (r.statusCode != 200) throw Exception('HTTP ${r.statusCode}');
    return utf8.decode(r.bodyBytes, allowMalformed: true);
  }

  String? _thumb(Map<String, dynamic>? th) {
    if (th == null) return null;
    for (final k in <String>['high', 'medium', 'default']) {
      final t = th[k] as Map<String, dynamic>?;
      final u = t?['url'] as String?;
      if (u != null && u.isNotEmpty) return u;
    }
    return null;
  }

  Future<ChannelInfo> loadChannel() async {
    const base = ChannelInfo(
        name: kChannelName, handle: kHandle, description: kDescription);
    if (kApiKey.isNotEmpty) {
      try {
        final j = jsonDecode(await _get(
                'https://www.googleapis.com/youtube/v3/channels?part=snippet,statistics,brandingSettings&id=$kChannelId&key=$kApiKey'))
            as Map<String, dynamic>;
        final items = j['items'] as List<dynamic>?;
        if (items != null && items.isNotEmpty) {
          final it = items[0] as Map<String, dynamic>;
          final sn = (it['snippet'] as Map<String, dynamic>?) ?? <String, dynamic>{};
          final st = (it['statistics'] as Map<String, dynamic>?) ?? <String, dynamic>{};
          final br = (it['brandingSettings'] as Map<String, dynamic>?)?['image']
              as Map<String, dynamic>?;
          return ChannelInfo(
            name: kChannelName,
            handle: kHandle,
            description: kDescription,
            avatarUrl: _thumb(sn['thumbnails'] as Map<String, dynamic>?),
            bannerUrl: br?['bannerExternalUrl'] as String?,
            subscribers: int.tryParse('${st['subscriberCount']}'),
          );
        }
      } catch (_) {}
    }
    // No key: read the public channel page for the profile picture.
    try {
      final html = await _get(kChannelUrl);
      final m = RegExp(r'<meta property="og:image" content="([^"]+)"').firstMatch(html);
      final u = m?.group(1);
      if (u != null && u.isNotEmpty) {
        return ChannelInfo(
            name: base.name,
            handle: base.handle,
            description: base.description,
            avatarUrl: unescapeXml(u));
      }
    } catch (_) {}
    return base;
  }

  Future<List<Video>> loadVideos() async {
    if (kApiKey.isNotEmpty) {
      try {
        final v = await _viaApi();
        if (v.isNotEmpty) return v;
      } catch (_) {}
    }
    final xml = await _get(
        'https://www.youtube.com/feeds/videos.xml?channel_id=$kChannelId');
    return parseFeed(xml);
  }

  Future<List<Video>> _viaApi() async {
    final uploads = 'UU${kChannelId.substring(2)}';
    final out = <Video>[];
    String? token;
    for (var page = 0; page < 3; page++) {
      final tokenPart = token == null ? '' : '&pageToken=$token';
      final j = jsonDecode(await _get(
              'https://www.googleapis.com/youtube/v3/playlistItems?part=snippet,contentDetails&maxResults=50&playlistId=$uploads$tokenPart&key=$kApiKey'))
          as Map<String, dynamic>;
      final items = (j['items'] as List<dynamic>?) ?? <dynamic>[];
      final ids = <String>[];
      final snips = <String, Map<String, dynamic>>{};
      final dates = <String, String>{};
      for (final raw in items) {
        final it = raw as Map<String, dynamic>;
        final sn = (it['snippet'] as Map<String, dynamic>?) ?? <String, dynamic>{};
        final cd =
            (it['contentDetails'] as Map<String, dynamic>?) ?? <String, dynamic>{};
        final id = (cd['videoId'] as String?) ?? '';
        final title = (sn['title'] as String?) ?? '';
        if (id.isEmpty || title == 'Private video' || title == 'Deleted video') continue;
        ids.add(id);
        snips[id] = sn;
        dates[id] = ((cd['videoPublishedAt'] as String?) ??
            (sn['publishedAt'] as String?) ??
            '');
      }
      final secs = <String, int>{};
      final views = <String, int>{};
      if (ids.isNotEmpty) {
        final d = jsonDecode(await _get(
                'https://www.googleapis.com/youtube/v3/videos?part=contentDetails,statistics&id=${ids.join(',')}&key=$kApiKey'))
            as Map<String, dynamic>;
        for (final raw in ((d['items'] as List<dynamic>?) ?? <dynamic>[])) {
          final it = raw as Map<String, dynamic>;
          final id = (it['id'] as String?) ?? '';
          final cd =
              (it['contentDetails'] as Map<String, dynamic>?) ?? <String, dynamic>{};
          final st = (it['statistics'] as Map<String, dynamic>?) ?? <String, dynamic>{};
          final s = parseIsoDuration((cd['duration'] as String?) ?? '');
          if (s > 0) secs[id] = s;
          views[id] = int.tryParse('${st['viewCount']}') ?? 0;
        }
      }
      for (final id in ids) {
        final sn = snips[id] ?? <String, dynamic>{};
        out.add(Video(
          id: id,
          title: (sn['title'] as String?) ?? '',
          description: (sn['description'] as String?) ?? '',
          published: DateTime.tryParse(dates[id] ?? '') ?? DateTime.now(),
          views: views[id] ?? 0,
          seconds: secs[id],
        ));
      }
      token = j['nextPageToken'] as String?;
      if (token == null) break;
    }
    return out;
  }

  Future<RemoteConfig?> loadRemote() async {
    if (kRemoteConfigUrl.isEmpty) return null;
    return parseRemoteConfig(await _get(kRemoteConfigUrl));
  }
}
