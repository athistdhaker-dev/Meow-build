// =====================================================================
//  EDIT THIS FILE to customise the app. Everything channel-specific is here.
// =====================================================================

const kChannelName = 'Arpit Explains';
const kHandle = '@arpit_explains';
const kChannelId = 'UCa1DrVdRPEvEQiaocQIe1uA';
const kTagline = 'Mushkil sawalon ke saral jawab';
const kDescription =
    'Complex questions explained in simple, relatable language. Science, critical '
    'thinking, current affairs, geopolitics and social issues in India, with facts '
    'and data. Education is a fundamental right.';

const kChannelUrl = 'https://www.youtube.com/@arpit_explains';
const kSubscribeUrl = '$kChannelUrl?sub_confirmation=1';
const kContactEmail = 'arpitexplains@gmail.com';

/// Optional. A YouTube Data API v3 key lets the app show ALL videos (not just the
/// latest 15), durations, Shorts filter, subscriber count and the channel photo.
/// Do NOT paste it here - add a GitHub secret named YT_API_KEY instead
/// (Settings > Secrets and variables > Actions). The workflow passes it in.
const kApiKey = String.fromEnvironment('YT_API_KEY', defaultValue: '');

/// Optional. URL of a small JSON file you host (for example a GitHub raw link) to
/// change social links / show an announcement WITHOUT building a new APK:
/// {"announcement":"New video every Sunday",
///  "socials":[{"name":"Instagram","badge":"IG","url":"https://instagram.com/xyz",
///              "color":"#E1306C","subtitle":"Daily updates"}]}
const kRemoteConfigUrl = String.fromEnvironment('REMOTE_CONFIG_URL', defaultValue: '');

class SocialLink {
  const SocialLink(this.name, this.badge, this.url, this.color, {this.subtitle = ''});
  final String name;
  final String badge; // 1-3 letters shown in the coloured square
  final String url; // empty = hidden in the app
  final int color; // 0xAARRGGBB
  final String subtitle;
}

/// Social links menu. Fill the empty `url` values and they appear automatically.
const kSocials = <SocialLink>[
  SocialLink('YouTube', 'YT', kChannelUrl, 0xFFFF3B47, subtitle: 'Watch all videos'),
  SocialLink('Instagram', 'IG', '', 0xFFE1306C, subtitle: 'Behind the scenes'),
  SocialLink('Telegram', 'TG', '', 0xFF2AABEE, subtitle: 'Join the community'),
  SocialLink('WhatsApp Channel', 'WA', '', 0xFF25D366, subtitle: 'Get updates first'),
  SocialLink('X (Twitter)', 'X', '', 0xFF4A4F5C, subtitle: 'Short thoughts'),
  SocialLink('Facebook', 'FB', '', 0xFF1877F2, subtitle: 'Follow the page'),
  SocialLink('Website', 'WEB', '', 0xFF7B2FF7, subtitle: 'Visit the website'),
  SocialLink('Email', '@', 'mailto:$kContactEmail', 0xFF4C8DFF,
      subtitle: 'Collaborations & enquiries'),
];
