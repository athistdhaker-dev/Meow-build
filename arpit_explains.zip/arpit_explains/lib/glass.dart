import 'dart:ui';
import 'package:flutter/material.dart';

/// Dark gradient with soft colour orbs - gives the glass something to refract.
class GlassBackdrop extends StatelessWidget {
  const GlassBackdrop({super.key, required this.child});
  final Widget child;

  Widget _orb(Color c, double s) => Container(
        width: s,
        height: s,
        decoration: BoxDecoration(
          shape: BoxShape.circle,
          gradient: RadialGradient(colors: <Color>[c.withAlpha(170), c.withAlpha(0)]),
        ),
      );

  @override
  Widget build(BuildContext context) {
    final w = MediaQuery.of(context).size.width;
    final h = MediaQuery.of(context).size.height;
    final u = w < h ? w : h; // orb sizes scale with the short side
    return Stack(
      fit: StackFit.expand,
      children: <Widget>[
        const DecoratedBox(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: <Color>[Color(0xFF080B18), Color(0xFF171046)],
            ),
          ),
        ),
        Positioned(top: -u * 0.25, left: -u * 0.2, child: _orb(const Color(0xFF7B2FF7), u * 0.95)),
        Positioned(bottom: -u * 0.3, right: -u * 0.2, child: _orb(const Color(0xFFEC5678), u * 1.0)),
        Positioned(top: h * 0.3, right: w * 0.08, child: _orb(const Color(0xFF2FA8F7), u * 0.6)),
        Positioned(bottom: h * 0.12, left: w * 0.06, child: _orb(const Color(0xFF2ED3B7), u * 0.5)),
        child,
      ],
    );
  }
}

/// Gradient specular rim (bright top-left, soft middle, bright bottom-right).
class _RimPainter extends CustomPainter {
  _RimPainter(this.radius, this.focused);
  final double radius;
  final bool focused;

  @override
  void paint(Canvas canvas, Size size) {
    final rect = Offset.zero & size;
    if (focused) {
      final rr = RRect.fromRectAndRadius(rect.deflate(1.5), Radius.circular(radius));
      canvas.drawRRect(
        rr,
        Paint()
          ..style = PaintingStyle.stroke
          ..strokeWidth = 3
          ..color = const Color(0xF2FFFFFF),
      );
      return;
    }
    final rr = RRect.fromRectAndRadius(rect.deflate(0.7), Radius.circular(radius));
    canvas.drawRRect(
      rr,
      Paint()
        ..style = PaintingStyle.stroke
        ..strokeWidth = 1.4
        ..shader = const LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: <Color>[
            Color(0xD0FFFFFF),
            Color(0x1FFFFFFF),
            Color(0x14FFFFFF),
            Color(0x88FFFFFF),
          ],
          stops: <double>[0.0, 0.35, 0.65, 1.0],
        ).createShader(rect),
    );
  }

  @override
  bool shouldRepaint(_RimPainter old) =>
      old.radius != radius || old.focused != focused;
}

/// Frosted "liquid glass" surface: backdrop blur + translucent gradient +
/// specular rim + top highlight. [tint] colours the glass (strength 0..1).
class Glass extends StatelessWidget {
  const Glass({
    super.key,
    required this.child,
    this.radius = 20,
    this.blur = 0,
    this.padding = EdgeInsets.zero,
    this.focused = false,
    this.selected = false,
    this.pressed = false,
    this.tint,
    this.tintStrength = 1.0,
  });
  final Widget child;
  final double radius, blur, tintStrength;
  final EdgeInsets padding;
  final bool focused, selected, pressed;
  final Color? tint;

  @override
  Widget build(BuildContext context) {
    final r = BorderRadius.circular(radius);
    Color a;
    Color b;
    if (tint == null) {
      a = Colors.white.withAlpha(selected ? 100 : 58);
      b = Colors.white.withAlpha(selected ? 44 : 14);
    } else {
      a = tint!.withAlpha((200 * tintStrength).round());
      b = tint!.withAlpha((105 * tintStrength).round());
      if (selected) {
        a = Color.alphaBlend(Colors.white.withAlpha(40), a);
      }
    }
    if (pressed) {
      a = Color.alphaBlend(Colors.white.withAlpha(60), a);
      b = Color.alphaBlend(Colors.white.withAlpha(40), b);
    }
    Widget box = CustomPaint(
      foregroundPainter: _RimPainter(radius, focused),
      child: DecoratedBox(
        decoration: BoxDecoration(
          borderRadius: r,
          gradient: LinearGradient(
            begin: Alignment.topLeft,
            end: Alignment.bottomRight,
            colors: <Color>[a, b],
          ),
        ),
        child: Stack(
          fit: StackFit.passthrough,
          children: <Widget>[
            Padding(padding: padding, child: child),
            Positioned(
              top: 0,
              left: radius * 0.6,
              right: radius * 0.6,
              height: 1.5,
              child: DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(colors: <Color>[
                    Colors.white.withAlpha(0),
                    Colors.white.withAlpha(200),
                    Colors.white.withAlpha(0),
                  ]),
                ),
              ),
            ),
          ],
        ),
      ),
    );
    if (blur > 0) {
      box = BackdropFilter(
        filter: ImageFilter.blur(sigmaX: blur, sigmaY: blur),
        child: box,
      );
    }
    return ClipRRect(borderRadius: r, child: box);
  }
}

/// Focusable (D-pad) + touch glass tile. The glass grows slightly on focus.
class GlassTap extends StatefulWidget {
  const GlassTap({
    super.key,
    required this.onTap,
    required this.child,
    this.radius = 18,
    this.blur = 0,
    this.padding = const EdgeInsets.symmetric(horizontal: 14, vertical: 10),
    this.selected = false,
    this.autofocus = false,
    this.tint,
    this.tintStrength = 1.0,
    this.focusScale = 1.03,
  });
  final VoidCallback onTap;
  final Widget child;
  final double radius, blur, tintStrength, focusScale;
  final EdgeInsets padding;
  final bool selected, autofocus;
  final Color? tint;

  @override
  State<GlassTap> createState() => _GlassTapState();
}

class _GlassTapState extends State<GlassTap> {
  bool _focus = false;
  bool _down = false;

  @override
  Widget build(BuildContext context) {
    return FocusableActionDetector(
      autofocus: widget.autofocus,
      onShowFocusHighlight: (v) => setState(() => _focus = v),
      actions: <Type, Action<Intent>>{
        ActivateIntent: CallbackAction<ActivateIntent>(onInvoke: (_) {
          widget.onTap();
          return null;
        }),
      },
      child: GestureDetector(
        behavior: HitTestBehavior.opaque,
        onTapDown: (_) => setState(() => _down = true),
        onTapUp: (_) => setState(() => _down = false),
        onTapCancel: () => setState(() => _down = false),
        onTap: widget.onTap,
        child: AnimatedScale(
          duration: const Duration(milliseconds: 120),
          curve: Curves.easeOut,
          scale: _down ? 0.96 : (_focus ? widget.focusScale : 1.0),
          child: Glass(
            radius: widget.radius,
            blur: widget.blur,
            padding: widget.padding,
            selected: widget.selected,
            focused: _focus,
            pressed: _down,
            tint: widget.tint,
            tintStrength: widget.tintStrength,
            child: widget.child,
          ),
        ),
      ),
    );
  }
}
