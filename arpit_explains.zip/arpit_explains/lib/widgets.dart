import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

import 'config.dart';
import 'glass.dart';
import 'yt.dart';

class Pal {
  static const accent = Color(0xFFFF4D5A);
  static const accent2 = Color(0xFFFF8A4C);
  static const violet = Color(0xFF7B2FF7);
  static const text = Color(0xFFF2F5FF);
  static const dim = Color(0xFFA9B4D0);
}

const double kBlur = 24;

Future<void> openUrl(BuildContext context, String url) async {
  if (url.isEmpty) return;
  final messenger = ScaffoldMessenger.of(context);
  var ok = false;
  try {
    ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
  } catch (_) {
    ok = false;
  }
  if (!ok) {
    messenger.showSnackBar(const SnackBar(content: Text('Could not open the link')));
  }
}

Future<void> copyText(BuildContext context, String text, String message) async {
  final messenger = ScaffoldMessenger.of(context);
  await Clipboard.setData(ClipboardData(text: text));
  messenger.showSnackBar(SnackBar(content: Text(message)));
}

// ------------------------------------------------------------------ pieces
class Avatar extends StatelessWidget {
  const Avatar({super.key, this.url, this.size = 72});
  final String? url;
  final double size;

  Widget _mono() => Container(
        color: const Color(0xFF1A1F3A),
        alignment: Alignment.center,
        child: Text('AE',
            style: TextStyle(
                fontSize: size * 0.34, fontWeight: FontWeight.w800, color: Pal.text)),
      );

  @override
  Widget build(BuildContext context) {
    final u = url;
    return Container(
      width: size,
      height: size,
      padding: const EdgeInsets.all(3),
      decoration: const BoxDecoration(
        shape: BoxShape.circle,
        gradient: LinearGradient(colors: <Color>[Pal.accent, Pal.violet]),
      ),
      child: ClipOval(
        child: u == null
            ? _mono()
            : Image.network(u,
                fit: BoxFit.cover, errorBuilder: (_, __, ___) => _mono()),
      ),
    );
  }
}

class VideoThumb extends StatelessWidget {
  const VideoThumb(this.url, {super.key, this.radius = 16, this.aspect = 16 / 9});
  final String url;
  final double radius, aspect;

  Widget _ph() => Container(
        color: const Color(0x22FFFFFF),
        alignment: Alignment.center,
        child: const Icon(Icons.play_circle_outline, color: Pal.dim, size: 36),
      );

  @override
  Widget build(BuildContext context) => ClipRRect(
        borderRadius: BorderRadius.circular(radius),
        child: AspectRatio(
          aspectRatio: aspect,
          child: Image.network(
            url,
            fit: BoxFit.cover,
            cacheWidth: 560,
            errorBuilder: (_, __, ___) => _ph(),
            loadingBuilder: (c, child, p) => p == null ? child : _ph(),
          ),
        ),
      );
}

class Tag extends StatelessWidget {
  const Tag(this.text, {super.key, this.color = const Color(0xCC000000)});
  final String text;
  final Color color;
  @override
  Widget build(BuildContext context) => Container(
        padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 3),
        decoration: BoxDecoration(color: color, borderRadius: BorderRadius.circular(8)),
        child: Text(text,
            style: const TextStyle(
                fontSize: 11, fontWeight: FontWeight.w700, color: Colors.white)),
      );
}

String viewsLine(Video v) {
  final parts = <String>[];
  if (v.views > 0) parts.add('${compactNumber(v.views)} views');
  parts.add(timeAgo(v.published));
  return parts.join('  ·  ');
}

class VideoCard extends StatelessWidget {
  const VideoCard({super.key, required this.video, required this.onTap, this.width});
  final Video video;
  final VoidCallback onTap;
  final double? width;

  @override
  Widget build(BuildContext context) {
    final card = GlassTap(
      radius: 22,
      padding: const EdgeInsets.all(8),
      focusScale: 1.0,
      onTap: onTap,
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisSize: MainAxisSize.min,
        children: <Widget>[
          Stack(
            children: <Widget>[
              VideoThumb(video.thumb, radius: 16),
              if (video.durationText.isNotEmpty)
                Positioned(right: 8, bottom: 8, child: Tag(video.durationText)),
              if (video.isShort)
                const Positioned(left: 8, top: 8, child: Tag('SHORT', color: Pal.accent)),
            ],
          ),
          const SizedBox(height: 10),
          Padding(
            padding: const EdgeInsets.symmetric(horizontal: 4),
            child: Text(video.title,
                maxLines: 2,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(
                    fontSize: 15, height: 1.25, fontWeight: FontWeight.w600, color: Pal.text)),
          ),
          const SizedBox(height: 4),
          Padding(
            padding: const EdgeInsets.fromLTRB(4, 0, 4, 4),
            child: Text(viewsLine(video),
                maxLines: 1,
                overflow: TextOverflow.ellipsis,
                style: const TextStyle(fontSize: 12.5, color: Pal.dim)),
          ),
        ],
      ),
    );
    return width == null ? card : SizedBox(width: width, child: card);
  }
}

class FeaturedCard extends StatelessWidget {
  const FeaturedCard({super.key, required this.video, required this.onTap});
  final Video video;
  final VoidCallback onTap;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: ClipRRect(
        borderRadius: BorderRadius.circular(26),
        child: AspectRatio(
          aspectRatio: 16 / 10,
          child: Stack(
            fit: StackFit.expand,
            children: <Widget>[
              Image.network(video.thumb,
                  fit: BoxFit.cover,
                  errorBuilder: (_, __, ___) => Container(color: const Color(0x22FFFFFF))),
              const DecoratedBox(
                decoration: BoxDecoration(
                  gradient: LinearGradient(
                    begin: Alignment.topCenter,
                    end: Alignment.bottomCenter,
                    colors: <Color>[Color(0x00000000), Color(0xE6070A16)],
                    stops: <double>[0.35, 1.0],
                  ),
                ),
              ),
              const Positioned(left: 14, top: 14, child: Tag('LATEST', color: Pal.accent)),
              Center(
                child: Glass(
                  radius: 34,
                  blur: 12,
                  tint: Colors.black,
                  tintStrength: 0.25,
                  child: const SizedBox(
                    width: 68,
                    height: 68,
                    child: Icon(Icons.play_arrow_rounded, color: Colors.white, size: 44),
                  ),
                ),
              ),
              Positioned(
                left: 16,
                right: 16,
                bottom: 14,
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  mainAxisSize: MainAxisSize.min,
                  children: <Widget>[
                    Text(video.title,
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 18,
                            height: 1.25,
                            fontWeight: FontWeight.w700,
                            color: Colors.white)),
                    const SizedBox(height: 4),
                    Text(viewsLine(video),
                        style: const TextStyle(fontSize: 12.5, color: Color(0xFFD4DBEE))),
                  ],
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}

class SubscribeButton extends StatelessWidget {
  const SubscribeButton({super.key, this.expand = false});
  final bool expand;

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: () => openUrl(context, kSubscribeUrl),
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 22, vertical: 13),
        decoration: BoxDecoration(
          borderRadius: BorderRadius.circular(30),
          gradient: const LinearGradient(colors: <Color>[Pal.accent, Pal.accent2]),
          boxShadow: const <BoxShadow>[
            BoxShadow(color: Color(0x55FF4D5A), blurRadius: 18, offset: Offset(0, 6)),
          ],
        ),
        child: Row(
          mainAxisSize: expand ? MainAxisSize.max : MainAxisSize.min,
          mainAxisAlignment: MainAxisAlignment.center,
          children: const <Widget>[
            Icon(Icons.notifications_active_rounded, size: 20, color: Colors.white),
            SizedBox(width: 8),
            Text('Subscribe',
                style: TextStyle(
                    fontSize: 16, fontWeight: FontWeight.w700, color: Colors.white)),
          ],
        ),
      ),
    );
  }
}

class SocialBadge extends StatelessWidget {
  const SocialBadge(this.link, {super.key, this.size = 46});
  final SocialLink link;
  final double size;
  @override
  Widget build(BuildContext context) => Container(
        width: size,
        height: size,
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: Color(link.color),
          borderRadius: BorderRadius.circular(size * 0.3),
        ),
        child: Text(link.badge,
            style: TextStyle(
                fontSize: size * (link.badge.length > 2 ? 0.28 : 0.36),
                fontWeight: FontWeight.w800,
                color: Colors.white)),
      );
}

class SocialTile extends StatelessWidget {
  const SocialTile({super.key, required this.link});
  final SocialLink link;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(bottom: 10),
        child: GlassTap(
          radius: 24,
          focusScale: 1.0,
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 12),
          onTap: () => openUrl(context, link.url),
          child: Row(
            children: <Widget>[
              SocialBadge(link),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(link.name,
                        style: const TextStyle(
                            fontSize: 16, fontWeight: FontWeight.w600, color: Pal.text)),
                    if (link.subtitle.isNotEmpty)
                      Text(link.subtitle,
                          style: const TextStyle(fontSize: 13, color: Pal.dim)),
                  ],
                ),
              ),
              const Icon(Icons.open_in_new_rounded, size: 20, color: Pal.dim),
            ],
          ),
        ),
      );
}

class SectionTitle extends StatelessWidget {
  const SectionTitle(this.title, {super.key, this.action, this.onAction});
  final String title;
  final String? action;
  final VoidCallback? onAction;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.fromLTRB(4, 22, 4, 10),
        child: Row(
          children: <Widget>[
            Expanded(
              child: Text(title,
                  style: const TextStyle(
                      fontSize: 19, fontWeight: FontWeight.w700, color: Pal.text)),
            ),
            if (action != null)
              GestureDetector(
                onTap: onAction,
                child: Text(action!,
                    style: const TextStyle(
                        fontSize: 14, fontWeight: FontWeight.w600, color: Pal.accent2)),
              ),
          ],
        ),
      );
}

class Pill extends StatelessWidget {
  const Pill(this.label, {super.key, required this.selected, required this.onTap});
  final String label;
  final bool selected;
  final VoidCallback onTap;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.only(right: 8),
        child: GlassTap(
          radius: 22,
          selected: selected,
          tint: selected ? Pal.accent : null,
          tintStrength: 0.6,
          focusScale: 1.0,
          padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
          onTap: onTap,
          child: Text(label,
              style: const TextStyle(
                  fontSize: 14, fontWeight: FontWeight.w600, color: Pal.text)),
        ),
      );
}

class SkeletonBox extends StatelessWidget {
  const SkeletonBox({super.key, required this.height, this.radius = 22});
  final double height, radius;
  @override
  Widget build(BuildContext context) => Container(
        height: height,
        margin: const EdgeInsets.only(bottom: 14),
        decoration: BoxDecoration(
          color: const Color(0x14FFFFFF),
          borderRadius: BorderRadius.circular(radius),
        ),
      );
}

class ErrorBox extends StatelessWidget {
  const ErrorBox({super.key, required this.message, required this.onRetry});
  final String message;
  final VoidCallback onRetry;
  @override
  Widget build(BuildContext context) => Padding(
        padding: const EdgeInsets.symmetric(vertical: 24),
        child: Glass(
          radius: 26,
          blur: kBlur,
          padding: const EdgeInsets.all(20),
          child: Column(
            children: <Widget>[
              const Icon(Icons.wifi_off_rounded, color: Pal.dim, size: 36),
              const SizedBox(height: 10),
              Text(message,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Pal.dim, fontSize: 15)),
              const SizedBox(height: 14),
              Pill('Try again', selected: true, onTap: onRetry),
            ],
          ),
        ),
      );
}
