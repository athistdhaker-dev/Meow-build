import 'package:flutter/foundation.dart';
import 'config.dart';
import 'yt.dart';

/// App-wide data holder (channel, videos, links).
class AppData extends ChangeNotifier {
  AppData._();
  static final AppData i = AppData._();

  final YtRepo _repo = YtRepo();
  ChannelInfo channel = const ChannelInfo(
      name: kChannelName, handle: kHandle, description: kDescription);
  List<Video> videos = <Video>[];
  List<SocialLink> socials = kSocials;
  String announcement = '';
  bool loading = false;
  bool loadedOnce = false;
  String? error;

  List<SocialLink> get activeSocials =>
      socials.where((s) => s.url.isNotEmpty).toList();
  Video? get latest => videos.isEmpty ? null : videos.first;
  List<Video> get popular {
    final l = List<Video>.of(videos)..sort((a, b) => b.views.compareTo(a.views));
    return l.where((v) => v.views > 0).take(8).toList();
  }

  bool get hasDurations => videos.any((v) => v.seconds != null);

  Future<void> load() async {
    if (loading) return;
    loading = true;
    error = null;
    notifyListeners();
    _loadExtras();
    try {
      final v = await _repo.loadVideos();
      v.sort((a, b) => b.published.compareTo(a.published));
      videos = v;
    } catch (_) {
      error = 'Could not load videos. Check your internet connection and try again.';
    }
    loading = false;
    loadedOnce = true;
    notifyListeners();
  }

  Future<void> _loadExtras() async {
    try {
      channel = await _repo.loadChannel();
      notifyListeners();
    } catch (_) {}
    try {
      final r = await _repo.loadRemote();
      if (r != null) {
        if (r.socials.isNotEmpty) socials = r.socials;
        announcement = r.announcement;
        notifyListeners();
      }
    } catch (_) {}
  }
}
