import 'package:flutter/material.dart';

import 'config.dart';
import 'glass.dart';
import 'pages.dart';
import 'store.dart';
import 'widgets.dart';
import 'yt.dart';

typedef OpenVideo = void Function(Video v);

// -------------------------------------------------------------------- home
class HomeScreen extends StatelessWidget {
  const HomeScreen({super.key, required this.goTab, required this.open});
  final void Function(int) goTab;
  final OpenVideo open;

  Widget _header(ChannelInfo ch, BuildContext context) {
    return Glass(
      radius: 30,
      blur: kBlur,
      padding: const EdgeInsets.all(14),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: <Widget>[
          if (ch.bannerUrl != null)
            Padding(
              padding: const EdgeInsets.only(bottom: 12),
              child: ClipRRect(
                borderRadius: BorderRadius.circular(18),
                child: AspectRatio(
                  aspectRatio: 16 / 5,
                  child: Image.network(ch.bannerUrl!,
                      fit: BoxFit.cover,
                      errorBuilder: (_, __, ___) => const SizedBox.shrink()),
                ),
              ),
            ),
          Row(
            children: <Widget>[
              Avatar(url: ch.avatarUrl, size: 76),
              const SizedBox(width: 14),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: <Widget>[
                    Text(ch.name,
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                            fontSize: 24, fontWeight: FontWeight.w800, color: Pal.text)),
                    const SizedBox(height: 2),
                    Text(
                      ch.subscribers == null
                          ? ch.handle
                          : '${ch.handle}  ·  ${compactNumber(ch.subscribers!)} subscribers',
                      style: const TextStyle(fontSize: 13.5, color: Pal.dim),
                    ),
                    const SizedBox(height: 4),
                    const Text(kTagline,
                        style: TextStyle(
                            fontSize: 13.5,
                            fontWeight: FontWeight.w600,
                            color: Pal.accent2)),
                  ],
                ),
              ),
            ],
          ),
          const SizedBox(height: 12),
          Text(ch.description,
              maxLines: 4,
              overflow: TextOverflow.ellipsis,
              style: const TextStyle(fontSize: 14, height: 1.4, color: Pal.dim)),
          const SizedBox(height: 14),
          Row(
            children: <Widget>[
              const Expanded(child: SubscribeButton(expand: true)),
              const SizedBox(width: 10),
              GlassTap(
                radius: 26,
                focusScale: 1.0,
                padding: const EdgeInsets.all(12),
                onTap: () => copyText(context, kChannelUrl, 'Channel link copied'),
                child: const Icon(Icons.share_rounded, size: 22, color: Pal.text),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _hList(List<Video> list) => SizedBox(
        height: 262,
        child: ListView.separated(
          scrollDirection: Axis.horizontal,
          itemCount: list.length,
          separatorBuilder: (_, __) => const SizedBox(width: 12),
          itemBuilder: (_, i) =>
              VideoCard(video: list[i], width: 250, onTap: () => open(list[i])),
        ),
      );

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppData.i,
      builder: (context, _) {
        final d = AppData.i;
        final children = <Widget>[_header(d.channel, context)];
        if (d.announcement.isNotEmpty) {
          children.add(Padding(
            padding: const EdgeInsets.only(top: 14),
            child: Glass(
              radius: 22,
              tint: Pal.violet,
              tintStrength: 0.45,
              padding: const EdgeInsets.all(14),
              child: Row(
                children: <Widget>[
                  const Icon(Icons.campaign_rounded, color: Pal.text),
                  const SizedBox(width: 10),
                  Expanded(
                      child: Text(d.announcement,
                          style: const TextStyle(fontSize: 14, color: Pal.text))),
                ],
              ),
            ),
          ));
        }
        if (d.videos.isEmpty && (d.loading || !d.loadedOnce)) {
          children
            ..add(const SectionTitle('Latest video'))
            ..add(const SkeletonBox(height: 210, radius: 26))
            ..add(const SkeletonBox(height: 120))
            ..add(const SkeletonBox(height: 120));
        } else if (d.videos.isEmpty) {
          children.add(ErrorBox(
              message: d.error ?? 'No videos found.', onRetry: AppData.i.load));
        } else {
          children
            ..add(const SectionTitle('Latest video'))
            ..add(FeaturedCard(video: d.latest!, onTap: () => open(d.latest!)));
          final recent = d.videos.skip(1).take(8).toList();
          if (recent.isNotEmpty) {
            children
              ..add(SectionTitle('Recent uploads',
                  action: 'See all', onAction: () => goTab(1)))
              ..add(_hList(recent));
          }
          final pop = d.popular;
          if (pop.length >= 3) {
            children
              ..add(const SectionTitle('Most watched'))
              ..add(_hList(pop));
          }
        }
        final socials = d.activeSocials;
        if (socials.isNotEmpty) {
          children
            ..add(SectionTitle('Follow & connect',
                action: 'See all', onAction: () => goTab(2)))
            ..add(SizedBox(
              height: 74,
              child: ListView.separated(
                scrollDirection: Axis.horizontal,
                itemCount: socials.length,
                separatorBuilder: (_, __) => const SizedBox(width: 12),
                itemBuilder: (context, i) => GestureDetector(
                  onTap: () => openUrl(context, socials[i].url),
                  child: Column(
                    children: <Widget>[
                      SocialBadge(socials[i], size: 52),
                      const SizedBox(height: 4),
                      Text(socials[i].badge,
                          style: const TextStyle(fontSize: 11, color: Pal.dim)),
                    ],
                  ),
                ),
              ),
            ));
        }
        return RefreshIndicator(
          onRefresh: AppData.i.load,
          child: ListView(
            physics: const AlwaysScrollableScrollPhysics(),
            padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
            children: children,
          ),
        );
      },
    );
  }
}

// ------------------------------------------------------------------ videos
class VideosScreen extends StatefulWidget {
  const VideosScreen({super.key, required this.open});
  final OpenVideo open;
  @override
  State<VideosScreen> createState() => _VideosScreenState();
}

class _VideosScreenState extends State<VideosScreen> {
  String _q = '';
  int _filter = 0; // 0 all, 1 videos, 2 shorts
  int _sort = 0; // 0 latest, 1 popular

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppData.i,
      builder: (context, _) {
        final d = AppData.i;
        var list = d.videos.where((v) {
          if (_q.isNotEmpty && !v.title.toLowerCase().contains(_q)) return false;
          if (_filter == 1) return !v.isShort;
          if (_filter == 2) return v.isShort;
          return true;
        }).toList();
        if (_sort == 1) list.sort((a, b) => b.views.compareTo(a.views));
        return Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(20, 12, 20, 10),
              child: Row(
                children: <Widget>[
                  const Expanded(
                    child: Text('Videos',
                        style: TextStyle(
                            fontSize: 26, fontWeight: FontWeight.w800, color: Pal.text)),
                  ),
                  Text('${d.videos.length} videos',
                      style: const TextStyle(fontSize: 13, color: Pal.dim)),
                ],
              ),
            ),
            Padding(
              padding: const EdgeInsets.symmetric(horizontal: 16),
              child: Glass(
                radius: 24,
                blur: kBlur,
                padding: const EdgeInsets.symmetric(horizontal: 14),
                child: TextField(
                  onChanged: (v) => setState(() => _q = v.trim().toLowerCase()),
                  style: const TextStyle(color: Pal.text, fontSize: 16),
                  cursorColor: Pal.accent,
                  decoration: const InputDecoration(
                    border: InputBorder.none,
                    hintText: 'Search videos',
                    hintStyle: TextStyle(color: Pal.dim),
                    icon: Icon(Icons.search_rounded, color: Pal.dim),
                  ),
                ),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 4),
              child: SingleChildScrollView(
                scrollDirection: Axis.horizontal,
                child: Row(
                  children: <Widget>[
                    Pill('Latest', selected: _sort == 0, onTap: () => setState(() => _sort = 0)),
                    Pill('Popular', selected: _sort == 1, onTap: () => setState(() => _sort = 1)),
                    if (d.hasDurations) ...<Widget>[
                      const SizedBox(width: 8),
                      Pill('All', selected: _filter == 0, onTap: () => setState(() => _filter = 0)),
                      Pill('Videos', selected: _filter == 1, onTap: () => setState(() => _filter = 1)),
                      Pill('Shorts', selected: _filter == 2, onTap: () => setState(() => _filter = 2)),
                    ],
                  ],
                ),
              ),
            ),
            Expanded(
              child: RefreshIndicator(
                onRefresh: AppData.i.load,
                child: list.isEmpty
                    ? ListView(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.all(16),
                        children: <Widget>[
                          if (d.videos.isEmpty && d.error != null)
                            ErrorBox(message: d.error!, onRetry: AppData.i.load)
                          else if (d.videos.isEmpty && !d.loadedOnce)
                            const SkeletonBox(height: 260)
                          else
                            const Padding(
                              padding: EdgeInsets.all(40),
                              child: Center(
                                child: Text('No videos match your search',
                                    style: TextStyle(color: Pal.dim)),
                              ),
                            ),
                        ],
                      )
                    : ListView.separated(
                        physics: const AlwaysScrollableScrollPhysics(),
                        padding: const EdgeInsets.fromLTRB(16, 8, 16, 24),
                        itemCount: list.length,
                        separatorBuilder: (_, __) => const SizedBox(height: 12),
                        itemBuilder: (_, i) =>
                            VideoCard(video: list[i], onTap: () => widget.open(list[i])),
                      ),
              ),
            ),
          ],
        );
      },
    );
  }
}

// ----------------------------------------------------------------- connect
class ConnectScreen extends StatelessWidget {
  const ConnectScreen({super.key});

  @override
  Widget build(BuildContext context) {
    return ListenableBuilder(
      listenable: AppData.i,
      builder: (context, _) {
        final socials = AppData.i.activeSocials;
        return ListView(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
          children: <Widget>[
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 0, 4, 4),
              child: Text('Connect',
                  style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Pal.text)),
            ),
            const Padding(
              padding: EdgeInsets.fromLTRB(4, 0, 4, 16),
              child: Text('Follow Arpit Explains everywhere',
                  style: TextStyle(fontSize: 14, color: Pal.dim)),
            ),
            const SubscribeButton(expand: true),
            const SizedBox(height: 18),
            for (final s in socials) SocialTile(link: s),
            Padding(
              padding: const EdgeInsets.only(bottom: 10),
              child: GlassTap(
                radius: 24,
                focusScale: 1.0,
                padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 14),
                onTap: () => copyText(context, kChannelUrl, 'Channel link copied'),
                child: const Row(
                  children: <Widget>[
                    Icon(Icons.share_rounded, color: Pal.text),
                    SizedBox(width: 14),
                    Expanded(
                      child: Text('Share channel (copy link)',
                          style: TextStyle(
                              fontSize: 16, fontWeight: FontWeight.w600, color: Pal.text)),
                    ),
                  ],
                ),
              ),
            ),
          ],
        );
      },
    );
  }
}

// ------------------------------------------------------------------- about
class AboutScreen extends StatelessWidget {
  const AboutScreen({super.key});

  @override
  Widget build(BuildContext context) {
    void doc(String t, Future<List<String>> b) => Navigator.push(
        context, MaterialPageRoute<void>(builder: (_) => DocPage(title: t, blocks: b)));
    Widget row(IconData i, String t, VoidCallback f) => Padding(
          padding: const EdgeInsets.only(bottom: 10),
          child: GlassTap(
            radius: 24,
            focusScale: 1.0,
            padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 14),
            onTap: f,
            child: Row(children: <Widget>[
              Icon(i, color: Pal.accent2),
              const SizedBox(width: 14),
              Expanded(
                child: Text(t,
                    style: const TextStyle(
                        fontSize: 16, fontWeight: FontWeight.w600, color: Pal.text)),
              ),
              const Icon(Icons.chevron_right_rounded, color: Pal.dim),
            ]),
          ),
        );
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: <Widget>[
        const Padding(
          padding: EdgeInsets.fromLTRB(4, 0, 4, 12),
          child: Text('About',
              style: TextStyle(fontSize: 26, fontWeight: FontWeight.w800, color: Pal.text)),
        ),
        Glass(
          radius: 28,
          blur: kBlur,
          padding: const EdgeInsets.all(18),
          child: Column(
            children: <Widget>[
              ListenableBuilder(
                listenable: AppData.i,
                builder: (_, __) => Avatar(url: AppData.i.channel.avatarUrl, size: 84),
              ),
              const SizedBox(height: 12),
              const Text(kChannelName,
                  style: TextStyle(fontSize: 22, fontWeight: FontWeight.w800, color: Pal.text)),
              const SizedBox(height: 6),
              const Text(kDescription,
                  textAlign: TextAlign.center,
                  style: TextStyle(fontSize: 14, height: 1.45, color: Pal.dim)),
              const SizedBox(height: 14),
              const Text('Version $kAppVersion',
                  style: TextStyle(fontSize: 12.5, color: Pal.dim)),
            ],
          ),
        ),
        const SizedBox(height: 16),
        row(Icons.privacy_tip_outlined, 'Privacy Policy',
            () => doc('Privacy Policy', Future.value(blocks(kPrivacy)))),
        row(Icons.description_outlined, 'Terms & Conditions',
            () => doc('Terms & Conditions', Future.value(blocks(kTerms)))),
        row(Icons.code_rounded, 'Open-source licenses', () => doc('Open-source licenses', licenses())),
        row(Icons.ondemand_video_rounded, 'YouTube Terms of Service',
            () => openUrl(context, 'https://www.youtube.com/t/terms')),
        row(Icons.policy_outlined, 'Google Privacy Policy',
            () => openUrl(context, 'https://policies.google.com/privacy')),
        row(Icons.mail_outline_rounded, 'Contact',
            () => openUrl(context, 'mailto:$kContactEmail')),
      ],
    );
  }
}
