import 'package:flutter/material.dart';
import 'package:flutter/services.dart';

import 'glass.dart';
import 'player.dart';
import 'screens.dart';
import 'store.dart';
import 'widgets.dart';
import 'yt.dart';

void main() {
  WidgetsFlutterBinding.ensureInitialized();
  SystemChrome.setSystemUIOverlayStyle(const SystemUiOverlayStyle(
    statusBarColor: Colors.transparent,
    statusBarIconBrightness: Brightness.light,
    systemNavigationBarColor: Color(0xFF0B0E1C),
    systemNavigationBarIconBrightness: Brightness.light,
  ));
  AppData.i.load();
  runApp(const ChannelApp());
}

class ChannelApp extends StatelessWidget {
  const ChannelApp({super.key});

  @override
  Widget build(BuildContext context) => MaterialApp(
        title: 'Arpit Explains',
        debugShowCheckedModeBanner: false,
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          colorScheme: ColorScheme.fromSeed(
              seedColor: Pal.accent, brightness: Brightness.dark),
          scaffoldBackgroundColor: Colors.transparent,
          snackBarTheme: const SnackBarThemeData(behavior: SnackBarBehavior.floating),
        ),
        builder: (context, child) => GlassBackdrop(child: child!),
        home: const Shell(),
      );
}

class Shell extends StatefulWidget {
  const Shell({super.key});
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  int tab = 0;

  void _open(Video v) {
    Navigator.push(
        context, MaterialPageRoute<void>(builder: (_) => PlayerPage(video: v)));
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: SafeArea(
        bottom: false,
        child: IndexedStack(
          index: tab,
          children: <Widget>[
            HomeScreen(goTab: (i) => setState(() => tab = i), open: _open),
            VideosScreen(open: _open),
            const ConnectScreen(),
            const AboutScreen(),
          ],
        ),
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 8),
          child: Glass(
            radius: 30,
            blur: kBlur,
            child: NavigationBar(
              selectedIndex: tab,
              height: 64,
              backgroundColor: Colors.transparent,
              surfaceTintColor: Colors.transparent,
              shadowColor: Colors.transparent,
              elevation: 0,
              indicatorColor: const Color(0x44FF4D5A),
              labelBehavior: NavigationDestinationLabelBehavior.alwaysShow,
              onDestinationSelected: (i) => setState(() => tab = i),
              destinations: const <NavigationDestination>[
                NavigationDestination(
                    icon: Icon(Icons.home_outlined),
                    selectedIcon: Icon(Icons.home_rounded),
                    label: 'Home'),
                NavigationDestination(
                    icon: Icon(Icons.play_circle_outline),
                    selectedIcon: Icon(Icons.play_circle_rounded),
                    label: 'Videos'),
                NavigationDestination(
                    icon: Icon(Icons.hub_outlined),
                    selectedIcon: Icon(Icons.hub_rounded),
                    label: 'Connect'),
                NavigationDestination(
                    icon: Icon(Icons.info_outline_rounded),
                    selectedIcon: Icon(Icons.info_rounded),
                    label: 'About'),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
