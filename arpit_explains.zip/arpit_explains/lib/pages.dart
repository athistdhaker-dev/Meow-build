import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';

import 'config.dart';
import 'glass.dart';
import 'widgets.dart';

const kAppVersion = '1.0.0'; // keep in sync with pubspec.yaml
const kLastUpdated = '08/10/2026';

const kPrivacy = 'Arpit Explains - Privacy Policy\n'
    'Last updated on $kLastUpdated.\n\n'
    '1. What this app does\n'
    'This app shows the videos of the "Arpit Explains" YouTube channel and links to its '
    'social media pages. It has no accounts and no sign-in.\n\n'
    '2. Data we collect\n'
    'We do not collect, store or sell your name, phone number, email, contacts, location '
    'or any other personal data. The app has no analytics, advertising or tracking SDKs of its own.\n\n'
    '3. Network and YouTube\n'
    'The app uses the internet to fetch the channel\'s public video list from YouTube. Videos '
    'play inside the app through the official YouTube embedded player. YouTube / Google may '
    'collect data (for example your IP address, device information and watch activity) and '
    'may show ads or use cookies according to the Google Privacy Policy '
    '(https://policies.google.com/privacy) and the YouTube Terms of Service '
    '(https://www.youtube.com/t/terms). By playing a video you agree to those terms.\n\n'
    '4. Permissions\n'
    'The app only requests the INTERNET permission.\n\n'
    '5. Links\n'
    'Links to social media and websites open in your browser or the related app; their own '
    'privacy policies apply there.\n\n'
    '6. Children\n'
    'The app is intended for a general audience.\n\n'
    '7. Changes\n'
    'We may update this policy; the date above shows the latest version.\n\n'
    '8. Contact\n'
    'Email: $kContactEmail';

const kTerms = 'Arpit Explains - Terms & Conditions\n'
    'Last updated on $kLastUpdated.\n\n'
    '1. Use of the app\n'
    'This app is a companion app for the Arpit Explains YouTube channel, provided free for '
    'personal, non-commercial use.\n\n'
    '2. Content\n'
    'All videos, thumbnails and channel content belong to their owner and are streamed from '
    'YouTube. You may not download, copy, redistribute or re-upload them from this app.\n\n'
    '3. YouTube\n'
    'Video playback uses YouTube API Services. By using the app you also agree to the '
    'YouTube Terms of Service (https://www.youtube.com/t/terms).\n\n'
    '4. Information only\n'
    'The channel explains topics for education and information. It is not professional '
    'legal, medical or financial advice.\n\n'
    '5. No warranty\n'
    'The app is provided "as is" without warranties. Availability depends on YouTube and your '
    'internet connection. To the extent permitted by law we are not liable for any loss '
    'arising from the use of the app.\n\n'
    '6. Governing law\n'
    'These terms are governed by the laws of India.\n\n'
    '7. Contact\n'
    'Email: $kContactEmail';

List<String> blocks(String body) =>
    body.split('\n\n').where((s) => s.trim().isNotEmpty).toList();

Future<List<String>> licenses() async {
  final out = <String>[
    'This app is built with Flutter and the Dart SDK (BSD-3-Clause) and uses open-source '
        'packages (http, url_launcher, youtube_player_iframe, webview_flutter). Their licenses are listed below.',
  ];
  await for (final e in LicenseRegistry.licenses) {
    final b = StringBuffer(e.packages.join(', '));
    for (final p in e.paragraphs) {
      b.write('\n${p.text}');
    }
    out.add(b.toString());
  }
  return out;
}

class DocPage extends StatelessWidget {
  const DocPage({super.key, required this.title, required this.blocks});
  final String title;
  final Future<List<String>> blocks;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(title),
        backgroundColor: Colors.transparent,
        elevation: 0,
        scrolledUnderElevation: 0,
      ),
      body: SafeArea(
        child: Padding(
          padding: const EdgeInsets.fromLTRB(12, 4, 12, 12),
          child: Glass(
            radius: 28,
            blur: kBlur,
            child: FutureBuilder<List<String>>(
              future: blocks,
              builder: (context, snap) {
                final data = snap.data;
                if (data == null) {
                  return const Center(child: CircularProgressIndicator());
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(20),
                  itemCount: data.length,
                  itemBuilder: (context, i) => Padding(
                    padding: const EdgeInsets.only(bottom: 14),
                    child: Text(data[i],
                        style: const TextStyle(fontSize: 15.5, height: 1.45, color: Pal.text)),
                  ),
                );
              },
            ),
          ),
        ),
      ),
    );
  }
}
