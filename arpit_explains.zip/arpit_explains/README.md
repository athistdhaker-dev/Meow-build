# Arpit Explains - channel app (Android)
Native Flutter app for the YouTube channel https://youtube.com/@arpit_explains
Home (latest video, recent, most watched), Videos (search, Latest/Popular, Shorts filter with API key),
Connect (social links menu), About (privacy, terms, licenses). Videos play inside the app with the
official YouTube player (ads stay on, as YouTube requires).

## Make it yours (all in `lib/config.dart`)
- Social links: fill the empty `url` values (Instagram, Telegram, WhatsApp, X, Facebook, Website). Empty ones stay hidden.
- Tagline / description / email.

## Optional upgrades (GitHub > Settings > Secrets and variables > Actions)
| Secret | What it gives |
|---|---|
| `YT_API_KEY` | YouTube Data API v3 key: ALL videos (not only latest 15), durations, Shorts filter, subscriber count, channel photo/banner. Restrict the key to the YouTube Data API in Google Cloud. |
| `REMOTE_CONFIG_URL` | Link to a small JSON file you host (e.g. GitHub raw). Change social links / show an announcement WITHOUT building a new APK. Format is in `lib/config.dart`. |
| `KEYSTORE_BASE64`, `KEYSTORE_PASSWORD`, `KEY_ALIAS` | Your own private signing key (needed for Play Store). |

## Build
1. New GitHub repo. Put `build-apk.yml` at `.github/workflows/build-apk.yml`.
2. Upload `arpit_explains.zip` to the repo root.
3. Actions builds 4 APKs and publishes them under Releases (`arm64-v8a` is right for almost every phone).

Without Flutter locally you do not need anything else. Local build: `flutter create --platforms=android --org com.arpitexplains --project-name arpit_explains .`,
`rm -f test/widget_test.dart`, `python3 tools/patch_manifest.py`, `flutter build apk --release`.

## Notes
- Only the INTERNET permission is used. No ads of our own, no analytics.
- Do not add ad-blocking or download features: they violate the YouTube API Terms and can get the channel/app banned.
- The bundled `tools/arpit-sideload.jks` key is public: fine for sideloading, use your own key for Play Store.
