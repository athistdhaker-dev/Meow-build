import 'package:flutter_test/flutter_test.dart';
import 'package:arpit_explains/yt.dart';

const _feed = '''<?xml version="1.0" encoding="UTF-8"?>
<feed xmlns:yt="http://www.youtube.com/xml/schemas/2015">
 <title>Arpit Explains</title>
 <entry>
  <id>yt:video:abc123XYZ_-</id>
  <yt:videoId>abc123XYZ_-</yt:videoId>
  <title>Science &amp; Myths: &quot;Is it true?&quot;</title>
  <published>2026-09-01T10:00:00+00:00</published>
  <media:group>
   <media:title>x</media:title>
   <media:description>Line one
Line two &#39;quoted&#39;</media:description>
   <media:community><media:statistics views="12345"/></media:community>
  </media:group>
 </entry>
 <entry>
  <yt:videoId>second00001</yt:videoId>
  <title>Second video</title>
  <published>2026-08-01T10:00:00+00:00</published>
 </entry>
</feed>''';

void main() {
  test('parseFeed reads entries', () {
    final v = parseFeed(_feed);
    expect(v.length, 2);
    expect(v[0].id, 'abc123XYZ_-');
    expect(v[0].title, 'Science & Myths: "Is it true?"');
    expect(v[0].views, 12345);
    expect(v[0].description.contains("'quoted'"), true);
    expect(v[0].published.year, 2026);
    expect(v[1].views, 0);
    expect(v[0].thumb, 'https://i.ytimg.com/vi/abc123XYZ_-/hqdefault.jpg');
  });

  test('durations', () {
    expect(parseIsoDuration('PT1H2M3S'), 3723);
    expect(parseIsoDuration('PT45S'), 45);
    expect(parseIsoDuration('PT10M'), 600);
    expect(formatDuration(3723), '1:02:03');
    expect(formatDuration(75), '1:15');
    expect(Video(id: 'a', title: 't', published: _d, seconds: 40).isShort, true);
    expect(Video(id: 'a', title: 't', published: _d, seconds: 400).isShort, false);
    expect(Video(id: 'a', title: 't', published: _d).isShort, false);
  });

  test('number and time formatting', () {
    expect(compactNumber(999), '999');
    expect(compactNumber(1000), '1K');
    expect(compactNumber(1234), '1.2K');
    expect(compactNumber(2500000), '2.5M');
    final now = DateTime(2026, 10, 8, 12);
    expect(timeAgo(DateTime(2026, 10, 8, 11), now: now), '1 hr ago');
    expect(timeAgo(DateTime(2026, 10, 7, 11), now: now), 'Yesterday');
    expect(timeAgo(DateTime(2026, 10, 1, 11), now: now), '1 week ago');
    expect(timeAgo(DateTime(2026, 7, 1, 11), now: now), '3 months ago');
    expect(timeAgo(DateTime(2024, 7, 1, 11), now: now), '2 years ago');
  });

  test('remote config', () {
    final r = parseRemoteConfig(
        '{"announcement":"Hi","socials":[{"name":"Instagram","badge":"IG","url":"https://i.com/x","color":"#E1306C"},{"name":"Skip","url":""}]}');
    expect(r.announcement, 'Hi');
    expect(r.socials.length, 1);
    expect(r.socials[0].color, 0xFFE1306C);
  });
}

final DateTime _d = DateTime(2026, 1, 1);
