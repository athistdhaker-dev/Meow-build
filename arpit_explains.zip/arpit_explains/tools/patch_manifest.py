"""Usage: python3 tools/patch_manifest.py   (run after `flutter create`)
Safe to run repeatedly: it always starts from the original generated manifest."""
import re, shutil, pathlib

p = pathlib.Path("android/app/src/main/AndroidManifest.xml")
orig = p.with_name("AndroidManifest.xml.orig")
if orig.exists():
    shutil.copy(orig, p)
else:
    shutil.copy(p, orig)

s = p.read_text(encoding="utf-8")
extra = [
    '<uses-permission android:name="android.permission.INTERNET"/>',
    # lets url_launcher open YouTube / Instagram / Telegram / mail apps on Android 11+
    '<queries>\n'
    '        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="https"/></intent>\n'
    '        <intent><action android:name="android.intent.action.VIEW"/><data android:scheme="mailto"/></intent>\n'
    '    </queries>',
]
s = s.replace("<application", "\n    ".join(extra) + "\n    <application", 1)
s = re.sub(r'android:label="[^"]*"', 'android:label="Arpit Explains"', s, 1)
p.write_text(s, encoding="utf-8")

shutil.copytree("assets/android_icons", "android/app/src/main/res", dirs_exist_ok=True)
print("patched manifest + icons")
