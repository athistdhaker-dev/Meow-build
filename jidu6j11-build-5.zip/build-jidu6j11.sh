#!/bin/bash
# ============================================================
# JioRouter AX6000 JIDU6J11 family build script
# Firmware: OpenWrt only
# Devices:  jidu6j11-6111 / 6411 / 6611 / 6811 / 6911
# Chipset:  Qualcomm IPQ9554 (qualcommbe/ipq95xx target)
# Base:     OpenWrt MASTER / snapshot branch — REQUIRED.
#           openwrt-25.12 stable only carries kernel 6.12 under
#           target/linux/generic/ — this device's PR (#25869)
#           ships patches-6.18, which stable has no kernel
#           version/hash entry for at all, so it CANNOT be
#           built from the stable branch. Master is the only
#           option until OpenWrt itself backports kernel 6.18
#           to a future stable release.
#
# This script uses a BUNDLED STATIC SNAPSHOT of PR #25869's files
# (pr-files/) and copies them directly into a fresh OpenWrt main
# checkout — no live "git fetch" + cherry-pick onto the PR. This
# avoids the whole class of bugs that live-fetching hit (upstream
# default-branch rename master->main, missing git commit identity
# on CI runners, commits silently skipped on conflict). A plain
# file copy cannot "skip" or "conflict" — it always lands.
#
# TRADEOFF: pr-files/ is a snapshot taken on 2026-10-15. If the PR
# author pushes new commits after that (new device variant, bug
# fix, etc.), this script will NOT pick them up automatically —
# pr-files/ must be refreshed manually. It also means that if
# OpenWrt's own main branch changes any of these same files for
# unrelated reasons after this snapshot, those unrelated upstream
# changes get silently overwritten rather than merged. For a
# fast-moving PR, re-fetch pr-files/ periodically; for build
# reliability right now, this static approach is used.
#
# Usage:
#   ./build-jidu6j11.sh <6111|6411|6611|6811|6911|all>
# ============================================================

set -e

DEVICE_ARG="$1"
VALID_DEVICES="6111 6411 6611 6811 6911"

if [ -z "$DEVICE_ARG" ]; then
    echo "Usage: $0 <6111|6411|6611|6811|6911|all>"
    exit 1
fi

if [ "$DEVICE_ARG" = "all" ]; then
    DEVICES="$VALID_DEVICES"
else
    DEVICES="$DEVICE_ARG"
    case " $VALID_DEVICES " in
        *" $DEVICE_ARG "*) ;;
        *) echo "Invalid device: $DEVICE_ARG (valid: $VALID_DEVICES or all)"; exit 1 ;;
    esac
fi

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
PKG_LIST_FILE="$SCRIPT_DIR/packages.txt"
REPO_URL="https://github.com/openwrt/openwrt.git"
PR_NUMBER="25869"

if [ ! -f "$PKG_LIST_FILE" ]; then
    echo "ERROR: packages.txt not found next to this script."
    exit 1
fi

build_one() {
    local DEV="$1"
    local SRC_DIR="$SCRIPT_DIR/build-jidu6j11-$DEV"

    echo "============================================================"
    echo " Building OpenWrt — JIDU6J11-$DEV"
    echo "============================================================"

    if [ ! -d "$SRC_DIR" ]; then
        echo "[*] Cloning OpenWrt main ..."
        git clone --depth 1 https://github.com/openwrt/openwrt.git "$SRC_DIR"
    else
        echo "[*] Resetting existing checkout to latest main ..."
        (cd "$SRC_DIR" && git fetch origin main --depth 1 && git reset --hard origin/main && git clean -fd)
    fi

    cd "$SRC_DIR"

    echo "[*] Overlaying PR #$PR_NUMBER files (static snapshot, pr-files/) onto the tree ..."
    cp -a "$SCRIPT_DIR/pr-files/." ./
    echo "[*] Verifying jidu6j11 device landed in the tree ..."
    grep -rl "jidu6j11" target/linux/qualcommbe/ >/dev/null || {
        echo "ERROR: jidu6j11 not found in tree after overlay — pr-files/ missing or incomplete."
        exit 1
    }

    # NOTE: no custom model-name script needed. Each JIDU6J11 variant's
    # own .dts already sets "model = ..." directly (e.g. "JioRouter
    # AX6000 JIDU6J11-6411"), unlike JIDU6J01 where one DTS covers 4
    # physical SKUs and needs a runtime MFG-partition scan. OpenWrt
    # shows the DTS model string automatically, no script required.
    echo "[*] Baking uci-defaults script + Aurora theme into files/ ..."
    mkdir -p files/etc/uci-defaults files/etc/custom-pkgs
    cp "$SCRIPT_DIR/99-jiorouter-jidu6j11-setup.txt" files/etc/uci-defaults/99-custom-config
    chmod +x files/etc/uci-defaults/99-custom-config
    cp "$SCRIPT_DIR/custom-pkgs/"*.apk files/etc/custom-pkgs/

    echo "[*] Updating feeds ..."
    ./scripts/feeds update -a
    ./scripts/feeds install -a

    echo "[*] Writing .config for jidu6j11-$DEV (target + full package list) ..."
    {
        echo "CONFIG_TARGET_qualcommbe=y"
        echo "CONFIG_TARGET_qualcommbe_ipq95xx=y"
        echo "CONFIG_TARGET_qualcommbe_ipq95xx_DEVICE_jiorouter_ax6000-jidu6j11-${DEV}=y"
        echo "# CONFIG_PACKAGE_luci-app-attendedsysupgrade is not set"
        echo "# CONFIG_PACKAGE_attendedsysupgrade-common is not set"
        for pkg in $(cat "$PKG_LIST_FILE"); do
            echo "CONFIG_PACKAGE_${pkg}=y"
        done
    } > .config

    make defconfig

    echo "[*] Downloading sources ..."
    make download -j$(nproc)

    echo "[*] Building (this will take a while) ..."
    make -j$(nproc) || make -j1 V=s

    cd "$SCRIPT_DIR"
    echo "[*] Build finished: jidu6j11-$DEV"
}

for D in $DEVICES; do
    build_one "$D"
done

echo "============================================================"
echo " ALL REQUESTED BUILDS COMPLETE"
echo "============================================================"
for D in $DEVICES; do
    echo " - build-jidu6j11-$D/bin/targets/qualcommbe/ipq95xx/"
done
